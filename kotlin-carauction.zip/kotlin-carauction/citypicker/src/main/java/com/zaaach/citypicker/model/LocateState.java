package com.zaaach.citypicker.model;

/**
 * author zaaach on 2016/1/26.
 */
public class LocateState {
    public static final int LOCATING    = 111;
    public static final int FAILED      = 666;
    public static final int SUCCESS     = 888;
}
