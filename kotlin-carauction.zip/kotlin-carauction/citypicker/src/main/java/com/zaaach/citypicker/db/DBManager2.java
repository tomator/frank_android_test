package com.zaaach.citypicker.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;

import com.zaaach.citypicker.model.City;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static com.zaaach.citypicker.model.City.ID;
import static com.zaaach.citypicker.model.City.NAME;
import static com.zaaach.citypicker.model.City.PARENT_ID;
import static com.zaaach.citypicker.model.City.PINYIN;
import static com.zaaach.citypicker.model.City.TABLE_NAME;
import static com.zaaach.citypicker.model.City.TYPE;

/**
 * author Bro0cL on 2016/1/26.
 */
public class DBManager2 {
    private Context mContext;
    DBOpenHelper dbOpenHelper;

    public DBManager2(Context context) {
        this.mContext = context;
        dbOpenHelper = new DBOpenHelper(context);
    }

    public boolean saveCitys(List<City> cityList) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE_NAME, null, null);
            for (City city : cityList) {
                ContentValues values = new ContentValues();
                values.put(ID, city.getId());
                values.put(NAME, city.getName());
                values.put(PARENT_ID, city.getParentId());
                values.put(PINYIN, city.getPinyin());
                values.put(TYPE, city.getType());
                db.insert(TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public boolean setEvaHotCitys(List<City> cityList) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE_NAME, "type = ?", new String[]{"15"});
            for (City city : cityList) {
                ContentValues values = new ContentValues();
                values.put(ID, city.getId());
                values.put(NAME, city.getName());
                values.put(PARENT_ID, city.getParentId());
                values.put(PINYIN, city.getPinyin());
                values.put(TYPE, city.getType());
                db.insert(TABLE_NAME, null, values);
            }
            db.setTransactionSuccessful();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
            db.close();
        }
    }

    public City getLocalCity(String cityName) {
        if (TextUtils.isEmpty(cityName)) {
            return null;
        }
        for (City city : getAllCitys()) {
            if (cityName.contains(city.getName())) {
                city.setType(City.TYPE_LOCATION);
                return city;
            }
        }
        return null;
    }

    public List<City> getAllIndex() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where type = 3", null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
        Collections.sort(result, new CityComparator());
        return result;
    }

    public List<City> getAllCitys() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where type = 3", null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
        Collections.sort(result, new CityComparator());
        return result;
    }

    public List<City> getHotCitys() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where type = 5", null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
//        Collections.sort(result, new CityComparator());
        return result;
    }

    public List<City> getEvaHotCitys() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where type = 15", null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
//        Collections.sort(result, new CityComparator());
        return result;
    }

    public List<City> getProvinces() {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where type = 2", null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
        Collections.sort(result, new CityComparator());
        return result;
    }

    public List<City> getCitys(String parentId) {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where parent_id = " + parentId, null);
        List<City> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor));
        }
        cursor.close();
        db.close();
        Collections.sort(result, new CityComparator());
        return result;
    }

    public void setParentName(City city) {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from " + TABLE_NAME + " where _id = " + city.getParentId(), null);
        if(cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex(NAME));
            city.setParentName(name);
        }
        cursor.close();
    }

    private City buildCity(Cursor cursor) {
        City city = new City();
        String id = cursor.getString(cursor.getColumnIndex(ID));
        String name = cursor.getString(cursor.getColumnIndex(NAME));
        String pinyin = cursor.getString(cursor.getColumnIndex(PINYIN));
        String parentId = cursor.getString(cursor.getColumnIndex(PARENT_ID));
        int type = cursor.getInt(cursor.getColumnIndex(TYPE));
        city.setId(id);
        city.setName(name);
        city.setPinyin(pinyin);
        city.setParentId(parentId);
        city.setType(type);
        setParentName(city);
        return city;
    }

    /**
     * sort by a-z
     */
    private class CityComparator implements Comparator<City> {
        @Override
        public int compare(City lhs, City rhs) {
            String a = lhs.getPinyin().substring(0, 1);
            String b = rhs.getPinyin().substring(0, 1);
            return a.compareTo(b);
        }
    }
}
