package com.zaaach.citypicker.model;

/**
 * author zaaach on 2016/1/26.
 */
public class City implements Cloneable {

    public static final String TABLE_NAME = "City";
    public static final String ID = "_id";
    public static final String NAME = "name";
    public static final String PINYIN = "pinyin";
    public static final String PARENT_ID = "parent_id";
    public static final String TYPE = "type";
    public static final String CREATE_TABLE = ""
            + "CREATE TABLE City(\n"
            + "    _id TEXT NOT NULL,\n"
            + "    name TEXT NOT NULL,\n"
            + "    pinyin TEXT NOT NULL,\n"
            + "    parent_id TEXT NOT NULL,\n"
            + "    type Integer NOT NULL\n"
            + ")";

    public static final int TYPE_PROVINCE = 2;
    public static final int TYPE_CITY = 3;
    public static final int TYPE_HOT = 5;
    public static final int TYPE_HOT_EVALUATE = 15;
    public static final int TYPE_CITY_ALL = 6;
    public static final int TYPE_LOCATION = 10;

    public static final String ID_NULL = "-1";

    private String id = ID_NULL;
    private String name;
    private String pinyin;
    private String parentId;
    private String parentName;
    private int type;   // 2 省 3 市

    public City() {
    }

    public City(String name, String pinyin) {
        this.name = name;
        this.pinyin = pinyin;
    }

    public City(String name, int type) {
        this.name = name;
        this.type = type;
    }

    @Override
    public String toString() {
        return "city: _id = " + id
                + " , name = " + name
                + " , parentName = " + parentName
                + " , pinyin = " + pinyin
                + " , parentId = " + parentId
                + " , type = " + type;
    }

    @Override
    public City clone() throws CloneNotSupportedException {
        return (City) super.clone();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof City) {
            return obj.hashCode() == hashCode();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return (id + name).hashCode();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }
}
