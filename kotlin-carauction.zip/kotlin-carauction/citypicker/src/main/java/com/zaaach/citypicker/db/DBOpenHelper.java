package com.zaaach.citypicker.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.zaaach.citypicker.model.City;

class DBOpenHelper extends SQLiteOpenHelper {
    static final String DB_NAME = "weidai_city.db";
    private static final int DB_VERSION = 1;

    DBOpenHelper(Context context) {
        this(context, DB_NAME, null, DB_VERSION);
    }

    DBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i("database", "onCreate : " + City.CREATE_TABLE);
        db.execSQL(City.CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}
