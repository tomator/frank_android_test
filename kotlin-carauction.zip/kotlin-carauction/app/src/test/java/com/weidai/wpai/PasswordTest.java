package com.weidai.wpai;

import com.weidai.wpai.util.secret.Base64Util;
import com.weidai.wpai.util.secret.PasswordUtil;

import org.junit.Test;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class PasswordTest {

    @Test
    public void encodeTest() {
        System.out.println(PasswordUtil.getRandomString(10));
        System.out.println(PasswordUtil.getRamdom("123456"));
        String encode = PasswordUtil.encode("123456");
        System.out.println(encode);
        System.out.println(Base64Util.decode(encode));
    }
    
}
