package com.weidai.wpai;

import com.weidai.wpai.util.FormatUtil;

import org.junit.Test;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/17
 */
public class FormatTest {

    @Test
    public void getDisplayMobile(){
        System.out.println(FormatUtil.getDisplayMobile("18512101234"));
    }

    @Test
    public void getFormatMoney(){
        System.out.println(FormatUtil.getFormateMoney(13500));
    }
}
