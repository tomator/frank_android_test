package com.weidai.wpai;

import com.google.gson.Gson;
import com.weidai.wpai.http.base.Result;

import org.junit.Test;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class GsonTest {

    @Test
    public void testBool() {
        String str = "{\"code\":0,\"data\":true,\"message\":\"注册成功\"}";
        System.out.println(str);

        Gson gson = new Gson();
        Result result = gson.fromJson(str, Result.class);
        System.out.println(result.getData() + " " + result.getMessage());
    }
}
