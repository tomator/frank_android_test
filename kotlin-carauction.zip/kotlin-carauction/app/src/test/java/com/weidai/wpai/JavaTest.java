package com.weidai.wpai;

import org.junit.Test;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/17
 */
public class JavaTest {

    @Test
    public void typeTest(){
        intTest(123);
    }

    private void intTest(Object obj){
        if(obj instanceof Integer){
            System.out.println(obj);
        }
    }

    public void testAdd(int a, int b){
        int c = a + b;
        System.out.println("a + b = "+c);
    }

    @Test
    public void testAdd0(){
        int a = 1, b = 2;
        testAdd(a, b);
    }
}
