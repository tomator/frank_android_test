package com.weidai.wpai

import org.junit.Test

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/31
 */

class KotlinTest{

    @Test
    fun testNull(){
        len("abc")
        len(null)
    }

    fun len(str: String?){
        var len = str?.length
        str?.forEach {
            println(it)
        }
        str.let {

        }
        println("len = $len")
    }
}