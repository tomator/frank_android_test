package com.wpai.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.tencent.mm.opensdk.modelbase.BaseReq;
import com.tencent.mm.opensdk.modelbase.BaseResp;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.weidai.wpai.BuildConfig;
import com.weidai.wpai.R;

/**
 * ------------------- WXEntryActivity.java -------------------
 * Author: wujinyuan Date: 2014/8/29 Time: 14:12
 */
public class WXEntryActivity extends Activity implements IWXAPIEventHandler {

    private IWXAPI mIWXAPI;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("WXEntryActivity", "onCreate ===== ");
        mIWXAPI = WXAPIFactory.createWXAPI(this, BuildConfig.WECHAT_APPID, true);
        mIWXAPI.registerApp(BuildConfig.WECHAT_APPID);
        mIWXAPI.handleIntent(getIntent(), this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Log.d("WXEntryActivity", "onNewIntent ===== ");
        setIntent(intent);
        mIWXAPI.handleIntent(intent, this);
    }

    @Override
    public void onReq(BaseReq baseReq) {
        Log.d("WXEntryActivity", "onReq : "+baseReq.transaction);
    }

    @Override
    public void onResp(BaseResp baseResp) {
        int result;
        Log.d("WXEntryActivity", "onResp : "+baseResp.errCode);
        switch (baseResp.errCode) {
            case BaseResp.ErrCode.ERR_OK:
                result = R.string.share_success;
                break;
            case BaseResp.ErrCode.ERR_USER_CANCEL:
                result = R.string.share_cancel;
                break;
            case BaseResp.ErrCode.ERR_AUTH_DENIED:
                result = R.string.share_failed;
                break;
            default:
                result = R.string.share_exception;
                break;
        }
        Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
        finish();
    }
}