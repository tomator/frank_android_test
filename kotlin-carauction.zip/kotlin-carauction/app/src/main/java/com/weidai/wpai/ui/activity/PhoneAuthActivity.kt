package com.weidai.wpai.ui.activity

import android.os.Bundle
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.BankCardVQO
import com.weidai.wpai.http.param.SendMsgVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ValidityUtils
import kotlinx.android.synthetic.main.activity_phone_auth.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class PhoneAuthActivity : BaseActivity() {

    lateinit var bankCardVQO: BankCardVQO
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_auth)
        var data = intent.getSerializableExtra("BankCardVQO")
        if (data == null) {
            finish()
            return
        }
        bankCardVQO = data as BankCardVQO
        tipsTV.text = getString(R.string.tips_bind_card_auth,
                FormatUtil.getDisplayMobile(bankCardVQO.mobile))
        authcodeView.setPhoneNumber(bankCardVQO.mobile)
        authcodeView.setType(SendMsgVQO.TYPE_BIND_CARD)
        authcodeView.getAuthcodeAET().setTextSize(13)
        authcodeView.getAuthcodeAET().setOnTextChange {
            val authcode = authcodeView.text.toString()
            if (ValidityUtils.checkAuthcode(authcode)) {
                nextStepTV.isSelected = true
            }
        }
        nextStepTV.setOnClickListener {
            if (nextStepTV.isSelected) {
                submit()
            }
        }
    }

    private fun submit() {
        val authcode = authcodeView.text.toString()
        bankCardVQO.smsCode = authcode
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("正在绑定银行卡...")
        progressDialog.show()
        Client.getService().bindCard(bankCardVQO)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                    override fun onSuccess(result: Result<Boolean>) {
                        super.onSuccess(result)
                        UserManager.instance.saveBindCrad(bankCardVQO.bankAccountNo)
                        RxBus.get().post(EventKey.KEY_USER_BIND_CARD_SUCCESS, true)
                        finish()
                        UserManager.instance.toSetPayPwd(this@PhoneAuthActivity)
                    }
                })
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_BIND_CARD_SUCCESS)))
    fun onBindCard(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onBindCard " + success)
        finish()
    }
}
