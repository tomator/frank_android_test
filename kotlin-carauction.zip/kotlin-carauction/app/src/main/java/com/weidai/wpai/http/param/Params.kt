package com.weidai.wpai.http.param

import com.weidai.wpai.http.base.Bean
import java.io.Serializable

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/12
 */

class BaseSearchObject(val page: Int = Bean.PAGE_INDEX, val pageSize: Int = Bean.PAGE_SIZE)

class AuctionRecommendVQO(val page: Int = Bean.PAGE_INDEX, val pageSize: Int = Bean.PAGE_SIZE)

class SendMsgVQO(val type: Int,
                 val mobile: String,
                 val imgCode: String? = null) {
    companion object {
        /**
         * 业务场景，1 注册，2 忘记登录密码 ,3 绑定银行卡，4 忘记支付密码，5 充值
         */
        const val TYPE_REGISTER = 1
        const val TYPE_FORGET_LOGIN_PWD = 2
        const val TYPE_BIND_CARD = 3
        const val TYPE_FORGET_PAY_PWD = 4
        const val TYPE_RECHARGE = 5
    }
}

class BankCardVQO : Serializable {
    var idNo: String? = null            //		N	持卡人身份证
    var imgCode: String? = null         //		N	图片验证码
    var smsCode: String? = null         //	N	短信验证码
    var bankAccountNo: String? = null    //		N	银行卡号
    var bankAccountName: String? = null    //		N	持卡人姓名
    var bankCode: String? = null            //		N	银行编码
    var mobile: String? = null              //		N	银行预留手机号
}

class ForgetPayPwdVQO(
        val pwd: String, //	    string	N	密码,前端Base64 加密
        val code: String, //	    string	N	短信验证码
        val mobile: String,
        val imgCode: String? = null //	string	N	图片验证码
)

class LoginVQO(val mobile: String, val pwd: String)

class PayOperateVQO(val fee: String, val pwd: String)

class PwdModfiyVQO(val newpwd: String, val oldpwd: String)

class PwdResetVQO(val pwd: String,
                  val mobile: String,
                  val code: String,
                  val imgCode: String? = null)

class RegisterVQO(val pwd: String,
                  val mobile: String,
                  val code: String,
                  val invitationCode: String? = null,
                  val imgCode: String? = null)

class SearchAuctionNewsVQO(val auctionNo: String,
                           val page: Int = Bean.PAGE_INDEX,
                           val pageSize: Int = Bean.PAGE_SIZE)

class SearchAuctionVQO {
    var regionCode: String? = CAR_REGION_CODE_ALL//	string	N	车辆所在地,不传或0=全部
    var carAgeMin: String? = "0"//    最低车龄要求，比如2表示2年及以上，若为0或不传表示不限制最低车龄
    var carAgeMax: String? = "0"//   最高车龄要求，比如10表示10年以内包括10年，若为0或不传表示不限制最高车龄
    var status: String? = CAR_STATUS_ALL//	    string	N	状态 1竞拍中、2即将开始、3结束'
    var page: Int = Bean.PAGE_INDEX//	        number	N	分页数,开始页1
    var pageSize: Int = Bean.PAGE_SIZE//	    number	N	每页数

    companion object {
        /**
         * 竞拍状态 状态 1竞拍中、2即将开始、3结束'
         */
        const val CAR_STATUS_ALL = "0"
        const val CAR_STATUS_AUCTION = "1"
        const val CAR_STATUS_ABOUT_TO = "2"
        const val CAR_STATUS_FINISH = "3"
        const val CAR_REGION_CODE_ALL = "0"
    }
}

class SearchCodeVQO(val code: String)

class SearchTradeVQO(val status: Int,
                     val page: Int = Bean.PAGE_INDEX,
                     val pageSize: Int = Bean.PAGE_SIZE) {
    companion object {
        /**
         * status	number	Y	状态：0 已报名 1 竞拍中 2 已成交 3 交易完成 5：已结束 6：交易失败
         */
        const val STATUS_ENTRY = 0
        const val STATUS_AUCTION = 1
        const val STATUS_DEAL = 2
        const val STATUS_COMPLETE = 3
        const val STATUS_OVER = 5
        const val STATUS_FAILED = 6
    }
}

class SetPayPwdVQO(val pwd: String)

class SignUpVQO(val pwd: String, val auctionNo: String)

class UpfeeVQO(val fee: String, val orderNo: String)

class DateNoticeVQO(val sysReadTime: String?, val userReadTime: String?, val couponReadTime: String?)

class BuildeOrderVQO(val channel: String, val vin: String)

class MyCouponVQO(val articleId: Int)

class SendVerifyCodeVQO(val outBillNo: String,
                        val channelCode: String,
                        val instCode: String)




