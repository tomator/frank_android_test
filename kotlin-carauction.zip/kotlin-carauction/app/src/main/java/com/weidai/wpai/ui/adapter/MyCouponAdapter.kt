package com.weidai.wpai.ui.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.Coupon
import kotlinx.android.synthetic.main.view_my_coupon_item.view.*
import java.util.*


class MyCouponAdapter(val context: Context, private val type: Int) : RecyclerView.Adapter<MyCouponAdapter.ViewHolder>() {
    private val dataList = ArrayList<Coupon>()

    fun refreshDatas(datas: List<Coupon>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<Coupon>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_my_coupon_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var auctionNo: String? = null

        fun bindData(position: Int) {
            var data = dataList[position]
            itemView.couponView.setData(type, data)
        }
    }

}
