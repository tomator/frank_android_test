package com.weidai.wpai.ui.activity

import android.content.Intent
import android.os.Bundle
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.base.ResultException
import com.weidai.wpai.http.bean.UserInfoBean
import com.weidai.wpai.http.param.LoginVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.model.RegisterInfo
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.preferences.SpfUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_login.*
import rx.Observable
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import com.igexin.sdk.PushManager
import com.weidai.wpai.util.LogUtil


class LoginActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        navigationView.setTitle("登录")
        phoneAET.hideLable()
        passwordAET.hideLable()
        contactBtn.text = "联系客服: " + SpfUtils.getInstance().serviceNo
        phoneAET.setOnTextChange { checkCommitEnable() }
        passwordAET.setOnTextChange { checkCommitEnable() }
        loginBtn.setOnClickListener {
            if (loginBtn.isSelected) {
                userLogin()
            }
        }
        registerBtn.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
        findPasswordBtn.setOnClickListener { startActivity(Intent(this, ForgetPasswordActivity::class.java)) }
    }

    private fun checkCommitEnable() {
        val phone = phoneAET.text.toString()
        val password = passwordAET.text.toString()
        loginBtn.isSelected = ValidityUtils.checkPhone(phone)
                && ValidityUtils.checkPassword(password)
    }

    private fun userLogin() {
        val phone = phoneAET.text.toString()
        var password = passwordAET.text.toString()
        password = PasswordUtil.encode(password)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("正在登陆...")
        progressDialog.show()
        Client.getService().login(LoginVQO(phone, password))
                .flatMap { booleanResult ->
                    if (booleanResult.code == Result.CODE_SUCEESS) {
                        Client.getService().getUserInfo()
                    } else {
                        Observable.error<Result<UserInfoBean>>(ResultException(booleanResult.code,
                                booleanResult.message))
                    }
                }.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<UserInfoBean>>(progressDialog) {
                    override fun onSuccess(result: Result<UserInfoBean>) {
                        super.onSuccess(result)
                        ToastUtil.show("登陆成功")
                        val userInfo = result.data!!
                        UserManager.instance.saveUserInfo(userInfo)
                        val bindResult = PushManager.getInstance().bindAlias(applicationContext, userInfo.mobileNo)
                        LogUtil.d("getui bindResult : " + bindResult)
                        RxBus.get().post(EventKey.KEY_USER_LOGIN_SUCCESS, true)
                        finish()
                        UserManager.instance.reqeustBindCardInfo()
                    }
                })
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_REGISTER_SUCCESS)))
    fun onUserRegister(registerInfo: RegisterInfo) {
        phoneAET.text = registerInfo.phoneNo
        passwordAET.setText(registerInfo.password)
        userLogin()
    }

}
