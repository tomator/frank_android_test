package com.weidai.wpai.http;

/**
 * Created by 魏旭方 on 2016/6/15.
 */
public class HttpConstant {

    public static class DevicesType {
        public static final String ANDROID_PHONE = "0";
        public static final String IPHONE = "1";
        public static final String ANDROID_PAD = "2";
        public static final String IPAD = "3";
        public static final String WAP = "4";
        public static final String WEB = "5";
        public static final String OPEN = "6";
    }

    public static class ResponseCode {

    }

    public static class Header {
        public final static String ACCEPT = "accept";
        public final static String ACCEPT_CONTENT = "application/json";
        public final static String DEVICE = "Device";
        public final static String DEVICE_VERSION = "Device-Version";
        public final static String DEVICE_MAC = "Device-Mac";
        public final static String COOKIE = "Cookie";
        public final static String CHANNEL = "Channel";
        public final static String AUTHORIZATION = "authId";
    }
}
