package com.weidai.wpai.http.bean

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/22
 */
data class HotCity(var carHotCitys: List<CarHotCitys>,
                   var hotCitys: List<HotCitys>) {
    data class CarHotCitys(var id: String,
                           var name: String)

    data class HotCitys(var id: String,
                        var name: String)
}