package com.weidai.wpai.ui.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.NewRecordBean
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.view_all_record_item.view.*
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/21
 */
class AllRecordAdapter(private val context: Context) : RecyclerView.Adapter<AllRecordAdapter.ViewHolder>() {
    private val dataList = ArrayList<NewRecordBean>()

    fun refreshDatas(datas: List<NewRecordBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<NewRecordBean>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_all_record_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(data: NewRecordBean) {
            itemView.phoneTV.text = FormatUtil.getDisplayMobile(data.userName)
            itemView.dateTV.text = data.time
            itemView.priceTV.text = data.priceString
            if (data.status == NewRecordBean.STATUS_COMPLETE) {
                itemView.flagTV.visibility = View.VISIBLE
            } else {
                itemView.flagTV.visibility = View.INVISIBLE
            }
        }
    }
}
