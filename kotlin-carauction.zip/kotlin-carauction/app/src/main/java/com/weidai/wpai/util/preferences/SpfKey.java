package com.weidai.wpai.util.preferences;

/**
 * Describe: 保存到sharePreface数据的key值类
 * User: LiYajun
 * Date: 2016-06-06
 */

public class SpfKey {

    public static final String AUTHORIZATION = "Authorization";//sid
    public static final String API_HOST = "API_HOST";
    public static final String STATIC_HOST = "STATIC_HOST";

    public static final String USER_HAS_PAY_PWD = "HAS_PAY_PWD";
    public static final String USER_NAME = "USER_NAME";
    public static final String USER_MOBILE_NO = "MOBILE_NO";
    public static final String USER_AVATAR = "USER_AVATAR";
    public static final String USER_BIND_CARD_NO = "USER_BIND_CARD_NO";

    public static final String COOKIE_WPAI_TOKEN = "wpai_token";
    public static final String COOKIE_WPAI_CODE = "wpai_code";

    public static final String LAST_APP_VERSION = "LAST_APP_VERSION";

    public static final String SERVICE_CONTACT_NO = "SERVICE_CONTACT_NO";

    public static final String APP_CHANNEL_KEY = "APP_CHANNEL_KEY";
    public static final String LAST_TIME_NOTICE_SYS = "LAST_TIME_NOTICE_SYS";
    public static final String LAST_TIME_NOTICE_USER = "LAST_TIME_NOTICE_USER";
    public static final String LAST_TIME_NOTICE_COUPON = "LAST_TIME_NOTICE_COUPON";
    public static final String MAINTENANCE_HAS_READED = "MAINTENANCE_HAS_READED";
    public static final String EVALUATE_HAS_READED = "EVALUATE_HAS_READED";

    public static final String SEARCH_HISTROY_CAR = "SEARCH_HISTROY_CAR";
    public static final String SEARCH_HISTROY_CITY = "SEARCH_HISTROY_CITY";

    public static final String HOT_CITY_COMMON = "HOT_CITY_COMMON";
    public static final String HOT_CITY_EVALUATE = "HOT_CITY_EVALUATE";
}
