package com.weidai.wpai.ui.evaluate.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.adapter.ProvinceListAdapter
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.component.cityPick.db.DBManager
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.evaluate.dialog.CityChildDialog
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import com.zaaach.citypicker.model.LocateState
import kotlinx.android.synthetic.main.activity_city_picker.*
import java.util.*

class CityPickerActivity : BaseActivity() {
    lateinit var mCityAdapter: ProvinceListAdapter
    private var mAllCities: List<City> = ArrayList()
    private var mHotCities: List<City> = ArrayList()
    lateinit var dbManager: DBManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_city_picker)
        navigationView.hideBack()
        navigationView.setTitle("所在城市")
        navigationView.setNextRes(R.mipmap.ic_nav_search)
        navigationView.setOnNextClickListener(View.OnClickListener {
            startActivity(Intent(this, CitySearchActivity::class.java))
        })
        refresh()
        if (App.instance.locationCity == null) {
            App.instance.startLocation()
        } else {
            mCityAdapter.updateLocateState(LocateState.SUCCESS, App.instance.locationCity)
        }
    }

    private fun refresh() {
        initData()
        initList()
    }

    private fun initList() {
        listview_all_city.adapter = mCityAdapter
        val overlay = findViewById(R.id.tv_letter_overlay) as TextView
        side_letter_bar.setOverlay(overlay)
        side_letter_bar.setOnLetterChangedListener({ letter ->
            val position = mCityAdapter.getLetterPosition(letter)
            listview_all_city.setSelection(position)
        })
        findViewById(R.id.cancel_btn).setOnClickListener { finish() }
    }

    private fun initData() {
        dbManager = DBManager(this)
        mAllCities = dbManager.getProvinces()
        var hotCityIds = SpfUtils.getInstance().getStringList(SpfKey.HOT_CITY_EVALUATE)
        mHotCities = dbManager.getCitys(hotCityIds)
        mCityAdapter = ProvinceListAdapter(this, mAllCities, mHotCities)
        mCityAdapter.setOnCityClickListener(object : ProvinceListAdapter.OnCityClickListener {
            override fun onCityClick(city: City) {
                when (city.type) {
                    City.TYPE_PROVINCE -> {
                        var top = lineView.bottom + StatusBarCompat.getStatusBarHeight(this@CityPickerActivity)
                        CityChildDialog(this@CityPickerActivity, top, city).show()
                    }
                    City.TYPE_CITY, City.TYPE_HOT, City.TYPE_LOCATION -> {
                        RxBus.get().post(EventKey.KEY_CHOOSE_CITY, city)
                        finish()
                    }
                }
            }

            override fun onLocateClick() {
                mCityAdapter.updateLocateState(LocateState.LOCATING, null)
                App.instance.startLocation()
            }
        })
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_GET_CITYS_RESULT)))
    fun onGetCitys(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onGetCitys " + success!!)
        if (success) {
            refresh()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_LOCATION_CITY)))
    fun onGetLocationCity(city: City?) {
        LogUtil.d(EventKey.TAG, "onGetLocationCity " + city!!)
        if (city == null || City.ID_NULL == city.id) {
            mCityAdapter.updateLocateState(LocateState.FAILED, null)
        } else {
            mCityAdapter.updateLocateState(LocateState.SUCCESS, city)
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CITY)))
    fun onCityChoose(city: City) {
        LogUtil.d(EventKey.TAG, "onCityChoose " + city)
        finish()
    }
}
