package com.weidai.wpai.ui.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.bean.Coupon
import com.weidai.wpai.ui.view.CouponView
import kotlinx.android.synthetic.main.view_my_coupon_item.view.*


class EnableCouponAdapter(val context: Context, val type: Int) : RecyclerView.Adapter<EnableCouponAdapter.ViewHolder>() {

    private val dataList = ArrayList<Coupon>()
    val viewList = ArrayList<CouponView>()
    var selectPosition = -1

    fun refreshDatas(datas: List<Coupon>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun getCoupon(): Coupon? {
        return dataList[selectPosition]
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_my_coupon_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var auctionNo: String? = null

        fun bindData(position: Int) {
            if (!viewList.contains(itemView.couponView)) {
                viewList.add(itemView.couponView)
            }
            var data = dataList[position]
            itemView.couponView.setData(type, data)
            itemView.couponView.onSelectListener = object : CouponView.OnSelectListener {
                override fun onSelect(isSelect: Boolean) {
                    if (isSelect) {
                        selectPosition = position
                        viewList.forEach {
                            it.setTopSelect(false)
                        }
                        itemView.couponView.setTopSelect(true)
                    } else {
                        selectPosition = -1
                    }
                    RxBus.get().post(EventKey.KEY_COUPON_SELECT, isSelect)
                }
            }
        }
    }

}
