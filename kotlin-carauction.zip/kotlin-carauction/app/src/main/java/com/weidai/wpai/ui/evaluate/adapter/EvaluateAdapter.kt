package com.weidai.wpai.ui.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.gson.Gson
import com.weidai.wpai.R
import com.weidai.wpai.db.EvaluateParam
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.http.bean.EvaluateResult
import com.weidai.wpai.ui.evaluate.activity.EvaluateResultActivity
import kotlinx.android.synthetic.main.view_evaluate_history_item.view.*

class EvaluateAdapter(val context: Context, val dataList: List<EvaluateParam>) : RecyclerView.Adapter<EvaluateAdapter.ViewHolder>() {

    val gson = Gson()

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_evaluate_history_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            var data = dataList[position]
            var evaluateCar = gson.fromJson(data.carInfo, EvaluateCar::class.java)
            var registerDate = evaluateCar.ppDate!!.substring(0, 4)
            var carInfo = "${evaluateCar.carCity}/${registerDate}年上牌/${evaluateCar.mileage}万公里"
            itemView.infoTV.text = carInfo
            if (evaluateCar.modelName!!.contains(evaluateCar.brandName!!)) {
                itemView.modelTV.text = "${evaluateCar.modelName} ${evaluateCar.modelDetail}"
            } else {
                itemView.modelTV.text = "${evaluateCar.brandName}${evaluateCar.modelName} ${evaluateCar.modelDetail}"
            }
            var result = gson.fromJson(data.evaluateResult, EvaluateResult::class.java)
            var evalPrice = ""
            when (result.status) {
                EvaluateResultActivity.NORMAL -> evalPrice = result.normalEvalPrice
                EvaluateResultActivity.GOOD -> evalPrice = result.goodEvalPrice
                EvaluateResultActivity.EXC -> evalPrice = result.excEvalPrice
            }
            itemView.priceTV.text = "${evalPrice}万"
            itemView.containerView.setOnClickListener {
                context.startActivity(Intent(context, EvaluateResultActivity::class.java)
                        .putExtra("evaluateResult", result)
                        .putExtra("carInfo", evaluateCar)
                        .putExtra("vinCode", data.vinCode)
                        .putExtra("enableVinCode", data.enableVinCode))
            }
        }
    }
}
