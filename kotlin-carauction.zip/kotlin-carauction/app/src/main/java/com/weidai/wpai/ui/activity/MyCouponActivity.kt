package com.weidai.wpai.ui.activity

import android.support.v4.app.Fragment
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.Coupon
import com.weidai.wpai.ui.fragment.MyCouponFragment
import kotlinx.android.synthetic.main.activity_base_tab.*


class MyCouponActivity : SimpleTabActivity() {

    override val tabContents: Array<String>
        get() = resources.getStringArray(R.array.tabMyCoupon)

    override val fragments: Array<Fragment>
        get() {
            navigationView.setTitle("我的优惠券")
            val notUse = MyCouponFragment.newInstance(Coupon.STATUS_NOT_USE)
            val alreadyUsed = MyCouponFragment.newInstance(Coupon.STATUS_ALREADY_USED)
            val overdue = MyCouponFragment.newInstance(Coupon.STATUS_OVERDUE)
            return arrayOf(notUse, alreadyUsed, overdue)
        }
}
