package com.weidai.wpai.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Selection;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.text.method.NumberKeyListener;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.weidai.wpai.R;

public class AccountEditText extends LinearLayout {

    private static final String TAG = "AccountEditText";
    private static final int PHONE_LENGTH = 11;
    private static final int TRANS_PASSWROD_LENGTH = 6;
    public static final int TYPE_DEFAULT = 0;
    public static final int TYPE_USER = 1;
    public static final int TYPE_PASSWORD = 2;
    public static final int TYPE_CARD = 3;
    public static final int TYPE_MONEY = 4;
    public static final int TYPE_INVITECODE = 5;
    public static final int TYPE_PHONE = 6;
    public static final int TYPE_TRANS_PASSWORD = 7;
    private static final char[] MONEY_NUMBER_KEYS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    private static final char[] MONEY_NUMBER_KEYS_POINT = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'};
    private static final char[] CARD_NUMBER_KEYS = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ' '};
    private static final char[] PASSWORD_KEYS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();


    private boolean mClearEnable;
    private int mType;
    private String mHint;
    private CharSequence mSequence = "";
    private int maxLength;
    private OnTextChangeListener mChangeListener;
    private String mLabelContent;
    private String mDigits = null;
    private boolean mIsShow = false;
    private Drawable mLabelIcon = null;
    private float textSize = 0;
    private int textColor = 0;
    private int textColorHinit = 0;
    private boolean allowPoint = false;
    private boolean showTopLine = false;

    private View top_line;
    private TextView tv_label;
    private EditText edt_content;
    private ImageView iv_clear;
    private ImageView iv_hide_show;


    public AccountEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        initAttr(context, attrs);
        setContextView(context);
    }


    private void initAttr(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.AccountEditText);
        mClearEnable = typedArray.getBoolean(R.styleable.AccountEditText_clear_enable, true);
        mLabelIcon = typedArray.getDrawable(R.styleable.AccountEditText_label_icon);
        mType = typedArray.getInteger(R.styleable.AccountEditText_type, TYPE_DEFAULT);
        mHint = typedArray.getString(R.styleable.AccountEditText_hint);
        maxLength = typedArray.getInt(R.styleable.AccountEditText_maxLength, 0);
        mLabelContent = typedArray.getString(R.styleable.AccountEditText_label_text);
        mDigits = typedArray.getString(R.styleable.AccountEditText_digits);
        textSize = typedArray.getDimensionPixelSize(R.styleable.AccountEditText_textSize, 0);
        textColor = typedArray.getColor(R.styleable.AccountEditText_textColor, 0);
        textColorHinit = typedArray.getColor(R.styleable.AccountEditText_textColorHint, 0);
        allowPoint = typedArray.getBoolean(R.styleable.AccountEditText_allowPoint, false);
        showTopLine = typedArray.getBoolean(R.styleable.AccountEditText_showTopLine, false);
        typedArray.recycle();
    }

    // 获取Editext
    public EditText getEdit() {
        return (EditText) findViewById(R.id.edt_content);
    }

    private void setContextView(Context context) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.view_account_edit_text, this);
        tv_label = (TextView) view.findViewById(R.id.tv_label);
        iv_clear = (ImageView) view.findViewById(R.id.iv_clear);
        edt_content = (EditText) view.findViewById(R.id.edt_content);
        iv_hide_show = (ImageView) view.findViewById(R.id.iv_hide_show);
        top_line = view.findViewById(R.id.top_line);

        if (showTopLine) {
            top_line.setVisibility(VISIBLE);
        } else {
            top_line.setVisibility(GONE);
        }
        if (TextUtils.isEmpty(mLabelContent)) {
            tv_label.setVisibility(GONE);
        } else {
            tv_label.setVisibility(VISIBLE);
            tv_label.setText(mLabelContent);
        }

        if (!mClearEnable) {
            iv_clear.setEnabled(false);
            iv_clear.setVisibility(View.GONE);
        }
        if (!TextUtils.isEmpty(mHint)) {
            edt_content.setHint(mHint);
        }
        if (maxLength > 0) {
            edt_content.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        }
        setType(mType);
        edt_content.setOnFocusChangeListener(mFocusChangeListener);
        edt_content.addTextChangedListener(mTextWatcher);
        iv_clear.setOnClickListener(mClickListener);
        edt_content.setOnKeyListener(mOnKeyListener);
        iv_hide_show.setOnClickListener(mClickListener);
        if (!TextUtils.isEmpty(mDigits)) {
            edt_content.setKeyListener(DigitsKeyListener.getInstance(mDigits));
            edt_content.setRawInputType(EditorInfo.TYPE_CLASS_TEXT);
        }
        if (textSize > 0) {
            edt_content.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
            tv_label.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
        }
        if (textColor != 0) {
            edt_content.setTextColor(textColor);
        }
        if (textColorHinit != 0) {
            edt_content.setHintTextColor(textColorHinit);
        }
    }


    public CharSequence getText() {
        if (mType == TYPE_CARD) {
            return mSequence;
        }
        return edt_content.getText();
    }

    public void setText(CharSequence content) {
        edt_content.setText(content);
    }

    public void setTextSize(int dip) {
        edt_content.setTextSize(TypedValue.COMPLEX_UNIT_DIP, dip);
        tv_label.setTextSize(TypedValue.COMPLEX_UNIT_DIP, dip);
    }

    public void setTextHint(CharSequence content) {
        edt_content.setHint(content);
    }

    public void setTextHint(int resId) {
        edt_content.setHint(resId);
    }

    public void setTextGravity(int gravity) {
        edt_content.setGravity(gravity);
    }

    public void setType(int type) {
        switch (type) {
            case TYPE_USER:
                edt_content.setInputType(InputType.TYPE_CLASS_TEXT);
                break;
            case TYPE_PASSWORD:
                mType = TYPE_PASSWORD;
//                iv_hide_show.setVisibility(View.VISIBLE);
                edt_content.setTransformationMethod(PasswordTransformationMethod.getInstance());
                edt_content.setRawInputType(InputType.TYPE_CLASS_TEXT);
                edt_content.setKeyListener(passwordListener);

                break;
            case TYPE_CARD:
                edt_content.setRawInputType(InputType.TYPE_CLASS_NUMBER);
                edt_content.setKeyListener(cardListener);
                break;
            case TYPE_MONEY:
                edt_content.setRawInputType(InputType.TYPE_CLASS_NUMBER);
                edt_content.setKeyListener(mMoneyKeyListener);
                break;
            case TYPE_INVITECODE:
//                edt_content.setKeyListener(mKeyListener);
                edt_content.setRawInputType(InputType.TYPE_CLASS_NUMBER);
                break;
            case TYPE_PHONE:
                edt_content.setRawInputType(InputType.TYPE_CLASS_NUMBER);
                edt_content.setInputType(InputType.TYPE_CLASS_NUMBER);
                edt_content
                        .setFilters(new InputFilter[]{new InputFilter.LengthFilter(PHONE_LENGTH)});
                break;
            case TYPE_TRANS_PASSWORD:
                mType = TYPE_TRANS_PASSWORD;
                edt_content
                        .setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                edt_content
                        .setFilters(new InputFilter[]{new InputFilter.LengthFilter(TRANS_PASSWROD_LENGTH)});
                edt_content
                        .setTransformationMethod(PasswordTransformationMethod.getInstance());
                break;
            default:
                edt_content.setInputType(InputType.TYPE_CLASS_TEXT);
                break;
        }
    }

    private OnFocusChangeListener mFocusChangeListener = new OnFocusChangeListener() {

        @Override
        public void onFocusChange(View view, boolean flag) {
            if (flag) {
                if (edt_content.getText().length() > 0) {
                    iv_clear.setVisibility(View.VISIBLE);
                }
            } else {
                iv_clear.setVisibility(View.GONE);
            }
        }
    };


    public TextWatcher mTextWatcher = new HouBankTextWatcher() {
        private String beforeStr = "";

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            beforeStr = s.toString();
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (mType == TYPE_MONEY && allowPoint && !TextUtils.isEmpty(s)) {
                try {
                    Double value = Double.parseDouble(s.toString());
                } catch (NumberFormatException e) {
                    setText(beforeStr);
                    edt_content.setSelection(start);
                }
            }
        }

        public void afterTextChanged(Editable editable) {
            if (mChangeListener != null) {
                mChangeListener.afterTextChanged(editable);
            }
            int length = editable.length();
            if (length > 0) {
                if (mType == TYPE_PASSWORD) {
                    if (edt_content.isFocused()) {
//                        iv_hide_show.setVisibility(View.VISIBLE);
                        iv_clear.setVisibility(View.VISIBLE);
                    }
                } else {
                    if (edt_content.isFocused()) {
                        iv_clear.setVisibility(View.VISIBLE);
                    }
                }
                if (mType == TYPE_CARD) {
                    int pos = editable.length() - 1;
                    char c = editable.charAt(pos);
                    mSequence = editable.toString().replaceAll(" ", "");
                    if ((c == ' ') && mSequence.length() % 4 != 0) {
                        editable.delete(pos, pos + 1);
                    }
                    if (mSequence.length() <= 19) {
                        if (mSequence.length() % 4 == 0 && editable.charAt(editable.length() - 1) != ' ') {
                            editable.append(" ");
                        }
                    } else {
                        editable.delete(pos, pos + 1);
                    }
                }
            } else {
                mSequence = "";
                iv_clear.setVisibility(View.GONE);
            }

        }
    };

    private OnClickListener mClickListener = new OnClickListener() {

        @Override
        public void onClick(View arg0) {
            if (arg0.getId() == R.id.iv_hide_show) {
                edt_content.postInvalidate();
                //切换后将EditText光标置于末尾
                CharSequence charSequence = edt_content.getText();
                if (charSequence instanceof Spannable) {
                    Spannable spanText = (Spannable) charSequence;
                    Selection.setSelection(spanText, charSequence.length());
                }
            } else {
                edt_content.setText("");
            }
        }
    };


    private OnKeyListener mOnKeyListener = new OnKeyListener() {
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_DEL && event.getAction() == KeyEvent.ACTION_DOWN) {
                if (mType == TYPE_CARD) {
                    int index = edt_content.getSelectionStart();
                    if (index > 0) {
                        if (' ' == (edt_content.getText().charAt(index - 1))) {
                            edt_content.getText().delete(index - 2, index);
                        } else {
                            edt_content.getText().delete(index - 1, index);
                        }
                    }
                    return true;
                }
            }
            return false;
        }
    };

    private class HouBankTextWatcher implements TextWatcher {

        @Override
        public void afterTextChanged(Editable arg0) {

        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

        }

    }

    public void setText(String content) {
        edt_content.setText(content);
        iv_clear.setVisibility(GONE);
    }

    private NumberKeyListener mKeyListener = new NumberKeyListener() {

        @Override
        public int getInputType() {
            return InputType.TYPE_CLASS_TEXT;
        }

        @Override
        protected char[] getAcceptedChars() {
            char[] numberChars = {'a', 'b', 'c', 'd', 'e', 'f', 'A', 'B', 'C', 'D', 'E', 'F', '0', '1', '2', '3', '4',
                    '5', '6', '7', '8', '9'};
            return numberChars;
        }
    };
    private NumberKeyListener mMoneyKeyListener = new NumberKeyListener() {

        @Override
        public int getInputType() {
            return InputType.TYPE_CLASS_NUMBER;
        }

        @Override
        protected char[] getAcceptedChars() {
            if (allowPoint) {
                return MONEY_NUMBER_KEYS_POINT;
            } else {
                return MONEY_NUMBER_KEYS;
            }
        }
    };

    private NumberKeyListener cardListener = new NumberKeyListener() {

        @Override
        public int getInputType() {
            return InputType.TYPE_CLASS_NUMBER;
        }

        @Override
        protected char[] getAcceptedChars() {
            return CARD_NUMBER_KEYS;
        }
    };


    public void setOnTextChange(OnTextChangeListener l) {
        mChangeListener = l;
    }

    private NumberKeyListener passwordListener = new NumberKeyListener() {

        @Override
        public int getInputType() {
            return InputType.TYPE_CLASS_TEXT;
        }

        @Override
        protected char[] getAcceptedChars() {
            return PASSWORD_KEYS;
        }
    };

    public interface OnTextChangeListener {
        public void afterTextChanged(Editable input);
    }

    public void setEditEnable(boolean flag) {
        edt_content.setEnabled(flag);
    }

    public void setLabel(String label) {
        tv_label.setText(label);
    }

    public void hideLable() {
        tv_label.setVisibility(View.GONE);
    }

    public void setInputMethodPassword() {
        edt_content.setTransformationMethod(PasswordTransformationMethod.getInstance());
    }

    public void setInputMethodText() {
        edt_content.setInputType(InputType.TYPE_CLASS_TEXT);
    }

    public void setMaxLength(int length) {

        InputFilter[] filters = {new InputFilter.LengthFilter(length)};
        edt_content.setFilters(filters);
    }

}
