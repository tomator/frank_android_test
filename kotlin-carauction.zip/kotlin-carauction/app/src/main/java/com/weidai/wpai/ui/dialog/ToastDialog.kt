package com.weidai.wpai.ui.dialog

import android.app.Dialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import com.weidai.wpai.R
import com.weidai.wpai.util.DensityUtil
import kotlinx.android.synthetic.main.dialog_toast.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/22
 */
class ToastDialog(context: Context) : Dialog(context, R.style.Dialog_Alert) {

    init {
        init()
    }

    private fun init() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_toast, null)
        setContentView(view)
        val windowWidth = window.windowManager.defaultDisplay.width
        val layoutParams = view.layoutParams
        layoutParams.width = windowWidth - 2 * DensityUtil.dip2px(24f)
        view.layoutParams = layoutParams
        titleTV.visibility = View.GONE
        contentTV.visibility = View.GONE
        lineHorizontal.visibility = View.GONE
        negativeBtn.visibility = View.GONE
        lineVertical.visibility = View.GONE
        positiveBtn.visibility = View.GONE
        setCanceledOnTouchOutside(false)
    }

    fun setTitleString(title: String): ToastDialog {
        titleTV.visibility = View.VISIBLE
        titleTV.text = title
        return this
    }

    fun setContent(content: String): ToastDialog {
        contentTV.visibility = View.VISIBLE
        contentTV.text = content
        return this
    }

    fun setNegative(text: String, onClickListener: View.OnClickListener?): ToastDialog {
        negativeBtn.visibility = View.VISIBLE
        lineHorizontal.visibility = View.VISIBLE
        if (positiveBtn.visibility == View.VISIBLE) {
            lineVertical.visibility = View.VISIBLE
        }
        negativeBtn.text = text
        negativeBtn.setOnClickListener { v ->
            cancel()
            onClickListener?.onClick(v)
        }
        return this
    }

    fun setPositive(text: String, onClickListener: View.OnClickListener?): ToastDialog {
        positiveBtn.visibility = View.VISIBLE
        lineHorizontal.visibility = View.VISIBLE
        if (negativeBtn.visibility == View.VISIBLE) {
            lineVertical.visibility = View.VISIBLE
        }
        positiveBtn.text = text
        positiveBtn.setOnClickListener { v ->
            cancel()
            onClickListener?.onClick(v)
        }
        return this
    }
}
