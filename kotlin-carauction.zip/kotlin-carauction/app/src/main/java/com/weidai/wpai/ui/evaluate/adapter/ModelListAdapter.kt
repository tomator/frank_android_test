package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.weidai.wpai.R
import com.weidai.wpai.extensions.findViewOften
import com.weidai.wpai.http.bean.ModelBean
import java.util.*

/**
 * author zaaach on 2016/1/26.
 */
class ModelListAdapter(context: Context) : BaseAdapter() {
    var datas: MutableList<ModelBean> = ArrayList()
    var inflater: LayoutInflater = LayoutInflater.from(context)
    private var itemClickListener: BrandListAdapter.ItemClickListener? = null

    fun refreshDatas(datas: List<ModelBean>?) {
        this.datas.clear()
        if (datas != null && datas.size > 0) {
            this.datas.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemViewType(position: Int): Int {
        return datas[position].type
    }

    override fun getCount(): Int {
        return datas.size
    }

    override fun getItem(position: Int): ModelBean {
        return datas[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view: View? = null
        var type = getItemViewType(position)
        if (convertView == null) {
            if (type == 0) {
                view = inflater.inflate(R.layout.car_view_model_title_item, parent, false)
            } else {
                view = inflater.inflate(R.layout.car_view_model_item, parent, false)
            }
        } else {
            view = convertView
        }
        if (type == 0) {
            val modelTV: TextView = view!!.findViewOften(R.id.modelTV)
            val groupTV: TextView = view!!.findViewOften(R.id.groupTV)
            groupTV.visibility = View.GONE
            modelTV.text = datas[position].name
            modelTV.setOnClickListener {
                itemClickListener.let {
                    itemClickListener!!.onItemClick(datas[position].name)
                }
            }
        } else {
            val groupTV: TextView = view!!.findViewOften(R.id.groupTV)
            groupTV.text = datas[position].name
        }

        return view!!
    }

    fun setItemClickListener(listener: BrandListAdapter.ItemClickListener) {
        this.itemClickListener = listener
    }
}
