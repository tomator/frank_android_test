package com.weidai.wpai.component.appLink;

import android.text.TextUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by bici on 16/11/21.
 */

public class Route {
    public static final String NOTICE = "notice";
    public static final String MY_COUPON = "myCoupon";
    public static final String AUCTION_DETAIL = "auctionDetail";

    private List<String> paramList;
    private Map<String, String> paramMap = new HashMap<>();

    public Route(String route) {
        paramList = Arrays.asList(route.split("/"));
    }

    public String getParam(String key) {
        return paramMap.get(key);
    }

    public boolean match(String url) {
        int start = url.indexOf("://") + 3;
        int end = url.indexOf("?");
        String route = null;
        if (end <= 0) {
            route = url.substring(start);
        } else {
            route = url.substring(start, end);
        }
        List<String> receiveList = Arrays.asList(route.split("/"));
        if (paramList.size() != receiveList.size()) {
            return false;
        }
        for (int i = 0; i < paramList.size(); i++) {
            String param = paramList.get(i);
            String receive = receiveList.get(i);
            if (param.startsWith(":")) {
                paramMap.put(param.substring(1), receive);
            } else {
                if (!TextUtils.equals(param, receive)) {
                    paramMap.clear();
                    return false;
                }
            }
        }
        return true;
    }
}
