package com.weidai.wpai.ui.adapter

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.MaintenanceBean
import com.weidai.wpai.http.param.SearchCodeVQO
import com.weidai.wpai.ui.activity.WPWebActivty
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.DateUtil
import kotlinx.android.synthetic.main.view_maintenance_item.view.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*

class MaintenanceAdapter(private val context: Context) : RecyclerView.Adapter<MaintenanceAdapter.ViewHolder>() {

    private val dataList = ArrayList<MaintenanceBean>()

    fun refreshDatas(datas: List<MaintenanceBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<MaintenanceBean>?) {
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_maintenance_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    private fun checkout(orderId: String) {
        val progressDialog = ProgressDialog(context)
        progressDialog.show()
        Client.getService().findCode(SearchCodeVQO(orderId))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<String>>(progressDialog) {
                    override fun onSuccess(result: Result<String>) {
                        WPWebActivty.open(context, result.data!!, "报告详情!!")
                    }
                })
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(data: MaintenanceBean) {
            itemView.dateTV.text = DateUtil.format(data.gmtCreate, 6)
            when (data.state) {
                MaintenanceBean.STATE_FINDING -> {
                    itemView.statusTV.setTextColor(Color.parseColor("#999999"))
                    itemView.statusTV.text = "查询中"
                    itemView.checkTV.visibility = View.GONE
                    itemView.descriptionTV.visibility = View.VISIBLE
                    itemView.descriptionTV.text = data.failDesc
                }
                MaintenanceBean.STATE_SUCCESS -> {
                    itemView.statusTV.setTextColor(Color.parseColor("#2196FE"))
                    itemView.statusTV.text = "查询成功"
                    itemView.checkTV.visibility = View.VISIBLE
                    itemView.descriptionTV.visibility = View.GONE
                    itemView.checkTV.setOnClickListener{ checkout(data.orderId) }
                }
                MaintenanceBean.STATE_FAILED -> {
                    itemView.statusTV.setTextColor(Color.parseColor("#F8433D"))
                    itemView.statusTV.text = "查询失败"
                    itemView.checkTV.visibility = View.GONE
                    itemView.descriptionTV.visibility = View.VISIBLE
                    itemView.descriptionTV.text = data.failDesc
                }
            }
            itemView.carInfoTV.text = "${data.carname} ${data.modelName}"
            itemView.vinCodeTV.text = "VIN：${data.vin}"
            val path = "car_logo/${data.carname}.png"
            ImageLoader.instance.displayRoundAssets(path, itemView.carLogoIV, R.mipmap.ic_car_logo)
        }
    }
}
