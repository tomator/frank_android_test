package com.weidai.wpai.ui.view.ptr;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.weidai.wpai.R;
import com.weidai.wpai.util.LogUtil;

import in.srain.cube.views.ptr.PtrFrameLayout;
import in.srain.cube.views.ptr.PtrUIHandler;
import in.srain.cube.views.ptr.indicator.PtrIndicator;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/13
 */
public class CarRefreshHeader extends FrameLayout implements PtrUIHandler {
    private static final String TAG = "CarRefreshHeader";
    private View contentView;
    private ImageView imageView;
    private ImageView shadowView;
    private TextView textView;
    private float lastPercent;
    private AnimatorSet animatorSet;
    ObjectAnimator rotate;
    ObjectAnimator jumpWheel;
    ObjectAnimator jumpShadow;

    public CarRefreshHeader(@NonNull Context context) {
        super(context);
        initView();
    }

    private void initView() {
        contentView = LayoutInflater.from(getContext()).inflate(R.layout.view_refresh_header_car, this);
        imageView = (ImageView) findViewById(R.id.imageView);
        shadowView = (ImageView) findViewById(R.id.shadowView);
        textView = (TextView) findViewById(R.id.textView);
    }

    @Override
    public void onUIReset(PtrFrameLayout frame) {

    }

    @Override
    public void onUIRefreshPrepare(PtrFrameLayout frame) {
        if (animatorSet == null) {
            animatorSet = new AnimatorSet();
            rotate = ObjectAnimator.ofFloat(imageView, "rotation", 0f, 360f);
            rotate.setRepeatCount(Animation.INFINITE);
            rotate.setRepeatMode(ValueAnimator.RESTART);
            rotate.setInterpolator(new LinearInterpolator());
            jumpWheel = ObjectAnimator.ofFloat(imageView, "translationY", -8f, 8f, -8f);
            jumpWheel.setRepeatCount(Animation.INFINITE);
            jumpWheel.setRepeatMode(ValueAnimator.RESTART);
            jumpWheel.setInterpolator(new LinearInterpolator());
            jumpShadow = ObjectAnimator.ofFloat(shadowView, "translationY", -3f, 3f, -3f);
            jumpShadow.setRepeatCount(Animation.INFINITE);
            jumpShadow.setRepeatMode(ValueAnimator.RESTART);
            jumpShadow.setInterpolator(new LinearInterpolator());
            animatorSet.playTogether(rotate, jumpWheel, jumpShadow);
            animatorSet.setDuration(500);
        }
    }

    @Override
    public void onUIRefreshBegin(PtrFrameLayout frame) {
        LogUtil.d(TAG, " onUIRefreshBegin >>> ");
        animatorSet.start();
    }

    @Override
    public void onUIRefreshComplete(PtrFrameLayout frame, boolean isHeader) {
        LogUtil.d(TAG, " onUIRefreshComplete <<<" + isHeader);
        if (animatorSet != null) {
            animatorSet.end();
        }
        textView.setText("下拉可以刷新");
    }

    @Override
    public void onUIPositionChange(PtrFrameLayout frame, boolean isUnderTouch, byte status, PtrIndicator ptrIndicator) {
        float percent = ptrIndicator.getCurrentPercent();
//        LogUtil.d(TAG, " onUIPositionChange: " + isUnderTouch + " , " + status + " , " + percent);
        if (status == 2) {
            if (lastPercent < 1 && percent >= 1) {
                refreshView(1);
            }
            if (lastPercent > 1 && percent <= 1) {
                refreshView(2);
            }
        }
        if (status == 3) {
            refreshView(3);
        }
        lastPercent = percent;
    }

    private void refreshView(int state) {

        switch (state) {
            case 1:
                textView.setText("松开立即刷新");
                break;
            case 2:
                textView.setText("下拉可以刷新");
                break;
            case 3:
                textView.setText("正在刷新...");
                break;
        }
    }
}
