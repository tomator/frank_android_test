package com.weidai.wpai.ui.evaluate.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.text.TextUtils
import android.view.View
import com.weidai.wpai.R
import com.weidai.wpai.extensions.displayRoundAssets
import com.weidai.wpai.extensions.show
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.http.bean.EvaluateResult
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.activity.MaintenanceActivity
import com.weidai.wpai.ui.evaluate.adapter.SaleRecordAdapter
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.activity_evaluate_result.*
import java.util.*

class EvaluateResultActivity : BaseActivity() {

    lateinit var data: EvaluateResult
    lateinit var carInfo: EvaluateCar
    var vinCode: String? = null
    lateinit var evalPrice: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_evaluate_result)
        navigationView.setTitle("估值报告")
        navigationView.setThemeColor(R.color.main_blue)
        data = intent.getSerializableExtra("evaluateResult") as EvaluateResult
        carInfo = intent.getSerializableExtra("carInfo") as EvaluateCar
        vinCode = intent.getStringExtra("vinCode")
        var enableVinCode = intent.getStringExtra("enableVinCode")
        if (!TextUtils.isEmpty(vinCode) && vinCode.equals(enableVinCode)) {
            maintenanceView.visibility = View.VISIBLE
            maintenanceTV.setOnClickListener {
                startActivity(Intent(this, MaintenanceActivity::class.java)
                        .putExtra("vinCode", vinCode))
            }
        }
//        initData()
        when (data.status) {
            NORMAL -> evalPrice = data.normalEvalPrice
            GOOD -> evalPrice = data.goodEvalPrice
            EXC -> evalPrice = data.excEvalPrice
        }
        initView()
    }

    override fun onResume() {
        super.onResume()
    }

    fun initView() {
        statusChanged(data.status)
        statusExcTV.setOnClickListener { statusChanged(EXC) }
        statusGoodTV.setOnClickListener { statusChanged(GOOD) }
        statusNormalTV.setOnClickListener { statusChanged(NORMAL) }
        newPriceTV.text = carInfo.guidePrice + "万"
        if (TextUtils.isEmpty(data.gpjEvalPrice)) {
            gpjPriceTV.text = "-"
        } else {
            gpjPriceTV.text = data.gpjEvalPrice + "万"
        }
        if (TextUtils.isEmpty(data.car300EvalPrice)) {
            car300PriceTV.text = "-"
        } else {
            car300PriceTV.text = data.car300EvalPrice + "万"
        }
        carLogoIV.displayRoundAssets(carInfo.brandName!!)
        modelTV.text = "${carInfo.modelName} ${carInfo.modelDetail}"
        cityTV.text = carInfo.carCity
        registerTV.text = DateUtil.format(DateUtil.parse(carInfo.ppDate, 19), 20)
        mileageTV.text = FormatUtil.getDouble2(carInfo.mileage!!.toDouble()) + "万公里"
        if (TextUtils.isEmpty(vinCode)) {
            vinCodeTV.visibility = View.GONE
        } else {
            vinCodeTV.visibility = View.VISIBLE
        }
        vinCodeTV.text = "车辆VIN码：${vinCode.show()}"
        standardTV.text = "排放标准：${carInfo.emissionStandard}"
        outputTV.text = "车辆排量：${carInfo.output}${carInfo.outputTye.show()}"
        initNextView()
        initRecyclerView()
        initAroundView()
    }

    fun statusChanged(status: String) {
        statusNormalTV.isSelected = false
        statusGoodTV.isSelected = false
        statusExcTV.isSelected = false
        when (status) {
            NORMAL -> {
                statusNormalTV.isSelected = true
                weiPriceTV.text = data.normalEvalPrice
                priceDescTV.text = DESC_NORMAL
            }
            GOOD -> {
                statusGoodTV.isSelected = true
                weiPriceTV.text = data.goodEvalPrice
                priceDescTV.text = DESC_GOOD
            }
            EXC -> {
                statusExcTV.isSelected = true
                weiPriceTV.text = data.excEvalPrice
                priceDescTV.text = DESC_EXC
            }
        }
        circleView.startAnimation()
    }

    fun initRecyclerView() {
        if (data.transactionRecords != null && data.transactionRecords.size > 0) {
            dataNullView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
            var dataList = data.transactionRecords
            if (data.transactionRecords.size > 5) {
                dataList = data.transactionRecords.subList(0, 5)
            }
            recyclerView.adapter = SaleRecordAdapter(this, dataList)
            recyclerView.layoutManager = LinearLayoutManager(this)
        } else {
            dataNullView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        }
    }

    fun initNextView() {
        if (data.carPriceNext == null) {
            return
        }
        nextTV0.text = evalPrice
        nextTV1.text = data.carPriceNext.carPriceNext1
        nextTV2.text = data.carPriceNext.carPriceNext2
        nextTV3.text = data.carPriceNext.carPriceNext3
        nextTV4.text = data.carPriceNext.carPriceNext4
        nextView1.layoutParams.height = getViewHeight(evalPrice, data.carPriceNext.carPriceNext1)
        nextView2.layoutParams.height = getViewHeight(evalPrice, data.carPriceNext.carPriceNext2)
        nextView3.layoutParams.height = getViewHeight(evalPrice, data.carPriceNext.carPriceNext3)
        nextView4.layoutParams.height = getViewHeight(evalPrice, data.carPriceNext.carPriceNext4)
        var year = Calendar.getInstance().get(Calendar.YEAR)
        yearTV0.text = "${year}年"
        yearTV1.text = "${year + 1}年"
        yearTV2.text = "${year + 2}年"
        yearTV3.text = "${year + 3}年"
        yearTV4.text = "${year + 4}年"
    }

    fun initAroundView() {
        if (data.vicinalProvincesPrice == null) {
            return
        }
        var maxValue = 0f
        var minValue = Float.MAX_VALUE
        for ((k, v) in data.vicinalProvincesPrice) {
            if (v.toFloat() > maxValue) {
                maxValue = v.toFloat()
            }
            if (v.toFloat() < minValue) {
                minValue = v.toFloat()
            }
        }
        data.vicinalProvincesPrice.keys.forEachIndexed { index, s ->
            var price = data.vicinalProvincesPrice[s]
            when (index) {
                0 -> {
                    aroundRL0.visibility = View.VISIBLE
                    cityTV0.visibility = View.VISIBLE
                    cityTV0.text = s
                    aroundTV0.text = price
                    aroundView0.layoutParams.height = getViewHeight(minValue, maxValue, price!!)
                }
                1 -> {
                    aroundRL1.visibility = View.VISIBLE
                    cityTV1.visibility = View.VISIBLE
                    cityTV1.text = s
                    aroundTV1.text = price
                    aroundView1.layoutParams.height = getViewHeight(minValue, maxValue, price!!)
                }
                2 -> {
                    aroundRL2.visibility = View.VISIBLE
                    cityTV2.visibility = View.VISIBLE
                    cityTV2.text = s
                    aroundTV2.text = price
                    aroundView2.layoutParams.height = getViewHeight(minValue, maxValue, price!!)
                }
                3 -> {
                    aroundRL3.visibility = View.VISIBLE
                    cityTV3.visibility = View.VISIBLE
                    cityTV3.text = s
                    aroundTV3.text = price
                    aroundView3.layoutParams.height = getViewHeight(minValue, maxValue, price!!)
                }
                4 -> {
                    aroundRL4.visibility = View.VISIBLE
                    cityTV4.visibility = View.VISIBLE
                    cityTV4.text = s
                    aroundTV4.text = price
                    aroundView4.layoutParams.height = getViewHeight(minValue, maxValue, price!!)
                }
            }
        }
    }

    fun getViewHeight(min: Float, max: Float, value: String): Int {
        var range = max - min
        var height = 100f
        if (range != 0f) {
            height = (value.toFloat() - min) / range * 40 + 60
        }
        return DensityUtil.dip2px(height)
    }

    fun getViewHeight(base: String, value: String): Int {
        return DensityUtil.dip2px(value.toFloat() / base.toFloat() * 100)
    }

    companion object {
        val NORMAL = "一般"
        val GOOD = "良好"
        val EXC = "优秀"

        val DESC_EXC = "外观无刮痕，无补漆；内饰及座椅无磨损，无污渍；机械设备状态极好。"
        val DESC_GOOD = "外观有轻微刮痕或补漆；内饰及座椅有轻微磨损；机械设备工作正常。"
        val DESC_NORMAL = "外观有多处刮痕或补漆；内饰及座椅磨损严重；机械设备有部分故障。"
    }
}
