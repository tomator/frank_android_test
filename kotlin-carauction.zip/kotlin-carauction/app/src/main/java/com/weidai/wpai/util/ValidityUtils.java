package com.weidai.wpai.util;

import android.text.TextUtils;

public class ValidityUtils {

    private static final String PHONE_CHECK = "^((13[0-9])|(14[0-9])|(15[0-9])|(17[0-9])|(18[0-9]))\\d{8}$";
    private static final String EMAIL_CHECK = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
    public static final String ALL_NUMBER = "^[0-9]{6,20}$";
    public static final String ALL_LETTER = "^[a-zA-Z]{6,20}$";

    public static boolean checkEmail(String email) {

        if (!TextUtils.isEmpty(email) && email.matches(EMAIL_CHECK)) {
            return true;
        }
        return false;
    }

    public static boolean checkPhone(String phone) {
        if (!TextUtils.isEmpty(phone) && phone.matches(PHONE_CHECK)) {
            return true;
        }
        return false;
    }

    /**
     * 密码6-16位
     *
     * @param password
     * @return
     */
    public static boolean checkPassword(String password) {
        if (!TextUtils.isEmpty(password)
                && password.length() >= 6
                && password.length() <= 16) {
            return true;
        }
        return false;
    }

    public static boolean checkAuthcode(String authcode) {
        if (!TextUtils.isEmpty(authcode)) {
            return true;
        }
        return false;
    }

    public static boolean checkRealname(String realname) {
        if (!TextUtils.isEmpty(realname)) {
            return true;
        }
        return false;
    }

    public static boolean checkIdCard(String icCard) {
        if (!TextUtils.isEmpty(icCard) && icCard.length() >= 15) {
            return true;
        }
        return false;
    }

    public static boolean checkBankCard(String bankCard) {
        if (!TextUtils.isEmpty(bankCard) && bankCard.length() >= 16) {
            return true;
        }
        return false;
    }

    public static boolean checkPayPwd(String payPwd) {
        if (!TextUtils.isEmpty(payPwd) && payPwd.length() == 6) {
            return true;
        }
        return false;
    }

    public static boolean checkVinCode(String vinCode) {
        if (!TextUtils.isEmpty(vinCode) && vinCode.length() == 17) {
            return true;
        }
        return false;
    }

    /**
     * 判断密码是否全是数字
     *
     * @param password 密码
     */
    public static boolean checkPasswordNumber(String password) {
        if (!TextUtils.isEmpty(password) && password.matches(ALL_NUMBER)) {
            return true;
        }
        return false;
    }


    /**
     * 判断密码是否是必须含有字母，可以包含数字
     *
     * @param password 密码
     */
    public static boolean checkPasswordLetter(String password) {
        if (!TextUtils.isEmpty(password) && password.matches(ALL_LETTER)) {
            return true;
        }
        return false;
    }

}
