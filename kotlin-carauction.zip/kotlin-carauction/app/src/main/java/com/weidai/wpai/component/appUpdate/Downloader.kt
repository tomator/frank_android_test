package com.weidai.wpai.component.appUpdate

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import rx.Observable
import rx.functions.Func1
import java.io.File
import java.io.FileOutputStream

object Downloader {

    fun downLoadFile(fileUrl: String, fileName: String, progressListener: ProgressListener): Observable<File> {
        Log.d("Downloader", fileUrl + " " + fileName)
        return Observable.create(Observable.OnSubscribe<Response> { subscriber ->
            val client = OkHttpClient.Builder().build()
            val request = Request.Builder().url(fileUrl).build()
            try {
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    subscriber.onNext(response)
                    subscriber.onCompleted()
                }
            } catch (e: Exception) {
                subscriber.onError(e)
            }
        }).flatMap(Func1<Response, Observable<File>> { response ->
            try {
                val file = File(fileName)
                val total = response.body().contentLength()
                if (file.exists()) {
                    if (file.length() == total) {
                        progressListener.update(total, total)
                        return@Func1 Observable.just(file)
                    } else {
                        file.delete()
                    }
                }
                val inputStream = response.body().byteStream()
                val fileOutputStream = FileOutputStream(file)
                val buffer = ByteArray(4096)
                var readSize = inputStream.read(buffer)
                var readCount: Long = 0
                while (readSize != -1) {
                    readCount += readSize.toLong()
                    fileOutputStream.write(buffer, 0, readSize)
                    progressListener.update(readCount, total)
                    readSize = inputStream.read(buffer)
                }
                inputStream.close()
                fileOutputStream.close()
                return@Func1 Observable.just(file)
            } catch (e: Exception) {
                return@Func1 Observable.error<File>(e)
            }
        })
    }

    interface ProgressListener {
        fun update(bytesRead: Long, contentLength: Long)
    }
}
