package com.weidai.wpai.ui.model;

import com.weidai.wpai.http.base.Bean;
import com.weidai.wpai.util.preferences.SpfKey;
import com.weidai.wpai.util.preferences.SpfUtils;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/14
 */
public class User implements Bean {

    public static String PAY_PWD_SETTED = "1";

    private String hasPayPwd;
    private String userName;
    private String mobileNo;
    private String avatar;
    private String bindCardNo;

    /**
     * 持久化到SecurePreferences
     */
    public void save() {
        SpfUtils.getInstance().saveData(SpfKey.USER_NAME, userName);
        SpfUtils.getInstance().saveData(SpfKey.USER_MOBILE_NO, mobileNo);
        SpfUtils.getInstance().saveData(SpfKey.USER_HAS_PAY_PWD, hasPayPwd);
        SpfUtils.getInstance().saveData(SpfKey.USER_AVATAR, avatar);
        SpfUtils.getInstance().saveData(SpfKey.USER_BIND_CARD_NO, bindCardNo);
    }

    public User setBindCardNo(String bindCardNo) {
        this.bindCardNo = bindCardNo;
        return this;
    }

    public User setHasPayPwd(String hasPayPwd) {
        this.hasPayPwd = hasPayPwd;
        return this;
    }

    public User setUserName(String userName) {
        this.userName = userName;
        return this;
    }

    public User setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
        return this;
    }

    public User setAvatar(String avatar) {
        this.avatar = avatar;
        return this;
    }

    public boolean hasPayPwd() {
        return PAY_PWD_SETTED.equals(hasPayPwd);
    }

    public String getUserName() {
        return userName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public String getAvatar() {
        return avatar;
    }

    public String getHasPayPwd() {
        return hasPayPwd;
    }

    public String getBindCardNo() {
        return bindCardNo;
    }
}
