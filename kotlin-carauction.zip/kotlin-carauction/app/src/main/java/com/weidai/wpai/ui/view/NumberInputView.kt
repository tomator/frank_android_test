package com.weidai.wpai.ui.view

import android.content.Context
import android.text.TextUtils
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.view_number_input.view.*
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/28
 */
class NumberInputView : FrameLayout, View.OnClickListener {

    private var lastString = ""
    private var inputString = ""
    private val listenerList = ArrayList<OnInputListener>()

    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)

    init {
        init()
    }

    private fun init() {
        LayoutInflater.from(context).inflate(R.layout.view_number_input, this)
        number1.setOnClickListener(this)
        number2.setOnClickListener(this)
        number3.setOnClickListener(this)
        number4.setOnClickListener(this)
        number5.setOnClickListener(this)
        number6.setOnClickListener(this)
        number7.setOnClickListener(this)
        number8.setOnClickListener(this)
        number9.setOnClickListener(this)
        number0.setOnClickListener(this)
        delete.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.number1 -> inputString += 1
            R.id.number2 -> inputString += 2
            R.id.number3 -> inputString += 3
            R.id.number4 -> inputString += 4
            R.id.number5 -> inputString += 5
            R.id.number6 -> inputString += 6
            R.id.number7 -> inputString += 7
            R.id.number8 -> inputString += 8
            R.id.number9 -> inputString += 9
            R.id.number0 -> inputString += 0
            R.id.delete -> if (!TextUtils.isEmpty(inputString)) {
                inputString = inputString.substring(0, inputString.length - 1)
            }
        }
        for (onInputListener in listenerList) {
            onInputListener.onInput(inputString, lastString)
        }
        lastString = inputString
    }

    fun initValue(initValue: String) {
        inputString = initValue
    }

    fun reset() {
        inputString = ""
        lastString = ""
    }

    fun addInputListener(onInputListener: OnInputListener) {
        listenerList.add(onInputListener)
    }

    interface OnInputListener {
        fun onInput(input: String, last: String)
    }
}
