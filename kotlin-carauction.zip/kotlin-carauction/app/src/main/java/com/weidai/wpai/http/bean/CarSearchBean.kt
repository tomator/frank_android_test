package com.weidai.wpai.http.bean

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/21
 */
data class CarSearchBean(var carBrands: List<CarBrands>,
                         var carModels: List<CarModels>) {
    data class CarBrands(var brandName: String)
    data class CarModels(var brandName: String,
                         var modelName: String,
                         var modelType: String)
}