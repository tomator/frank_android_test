package com.weidai.wpai.component.appLink;

import android.app.Activity;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/9/27
 */
public class SimpleCallback implements LinkCallBack {

    @Override
    public void onLink(Activity activity, Link link) {
    }
}
