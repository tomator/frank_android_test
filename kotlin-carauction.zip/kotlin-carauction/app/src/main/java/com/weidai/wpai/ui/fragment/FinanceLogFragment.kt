package com.weidai.wpai.ui.fragment

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.FunLogBean
import com.weidai.wpai.http.param.BaseSearchObject
import com.weidai.wpai.ui.adapter.FinanceLogAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import kotlinx.android.synthetic.main.fragment_finance_log.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/27
 */
class FinanceLogFragment : BaseFragment() {

    lateinit var adapter: FinanceLogAdapter
    private var type = TYPE_FINANCE
    private var index = Bean.PAGE_INDEX
    private val PAGE_SIZE = 15

    companion object {
        private val ARG_TYPE = "ARG_TYPE"
        val TYPE_FINANCE = 1
        val TYPE_FREEZE = 2

        fun newInstance(type: Int): FinanceLogFragment {
            val fragment = FinanceLogFragment()
            val args = Bundle()
            args.putInt(ARG_TYPE, type)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            type = arguments.getInt(ARG_TYPE)
        }
    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_finance_log, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        initRefresh()
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(context)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(context))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200)
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = FinanceLogAdapter(context, type)
        recyclerView.adapter = adapter
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        val simpleSubscriber = object : SimpleSubscriber<Result<ListData<FunLogBean>>>(ptrFrame) {
            override fun onSuccess(result: Result<ListData<FunLogBean>>) {
                super.onSuccess(result)
                val dataList = result.data!!.data!!
                if (refresh) {
                    adapter.refreshDatas(dataList)
                } else {
                    adapter.addDatas(dataList)
                }
                if (dataList.size >= Bean.PAGE_SIZE) {
                    ptrFrame.mode = PtrFrameLayout.Mode.BOTH
                    index++
                } else {
                    ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
                }
            }
        }
        if (type == TYPE_FINANCE) {
            Client.getService().financeLog(BaseSearchObject(index, PAGE_SIZE))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(simpleSubscriber)
        } else {
            Client.getService().freezeLog(BaseSearchObject(index, PAGE_SIZE))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(simpleSubscriber)
        }
    }
}
