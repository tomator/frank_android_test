package com.weidai.wpai.ui.fragment

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.MessageBean
import com.weidai.wpai.http.param.BaseSearchObject
import com.weidai.wpai.ui.adapter.MessageAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.fragment_message.*
import kotlinx.android.synthetic.main.view_message_null.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/24
 */
class MessageFragment : BaseFragment() {

    private var type = TYPE_NOTICE
    lateinit var adapter: MessageAdapter
    private var index = Bean.PAGE_INDEX
    private val PAGE_SIZE = Bean.PAGE_SIZE

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_message, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        if (arguments != null) {
            type = arguments.getInt(ARG_TYPE)
        }
        nullImageView.setImageResource(R.mipmap.ic_message_null)
        nullTextView.text = "暂无消息"
        loginTV.visibility = View.GONE
        loginTV.setOnClickListener { UserManager.instance.turn2Login() }
        initRefresh()
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isVisibleToUser && type == TYPE_USER) {
            if (UserManager.instance.isUserLogin) {
                SpfUtils.getInstance().saveUserNotice()
                RefreshHelper.autoRefresh(ptrFrame)
            } else {
                auctionNullView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
                ptrFrame.mode = PtrFrameLayout.Mode.NONE
                nullTextView.text = "您尚未登录，登陆后查看系统消息"
                loginTV.visibility = View.VISIBLE
            }

        }
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(context)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(context))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }
        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200)
        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = MessageAdapter(context, type)
        recyclerView.adapter = adapter
        if (type == TYPE_NOTICE) {
            RefreshHelper.autoRefresh(ptrFrame)
        }
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        val simpleSubscriber = object : SimpleSubscriber<Result<ListData<MessageBean>>>(ptrFrame) {
            override fun onSuccess(result: Result<ListData<MessageBean>>) {
                super.onSuccess(result)
                val dataList = result.data!!.data!!
                if (refresh && dataList.size == 0) {
                    auctionNullView.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    return
                }
                recyclerView.visibility = View.VISIBLE
                auctionNullView.visibility = View.GONE
                if (refresh) {
                    adapter.refreshDatas(dataList)
                } else {
                    adapter.addDatas(dataList)
                }
                if (dataList.size >= Bean.PAGE_SIZE) {
                    ptrFrame.mode = PtrFrameLayout.Mode.BOTH
                    index++
                } else {
                    ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
                }
            }

            override fun onFailed() {
                auctionNullView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            }
        }
        if (type == TYPE_NOTICE) {
            Client.getService().getMessageNotice(BaseSearchObject(index, PAGE_SIZE))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(simpleSubscriber)
        } else {
            Client.getService().getMessageUser(BaseSearchObject(index, PAGE_SIZE))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(simpleSubscriber)
        }
    }

    companion object {

        private val ARG_TYPE = "ARG_TYPE"
        val TYPE_NOTICE = 1
        val TYPE_USER = 2

        fun newInstance(type: Int): MessageFragment {
            val fragment = MessageFragment()
            val args = Bundle()
            args.putInt(ARG_TYPE, type)
            fragment.arguments = args
            return fragment
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_LOGIN_SUCCESS)))
    fun onUserLogin(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onUserLogin " + success!!)
        loginTV.visibility = View.GONE
        nullTextView.text = "暂无消息"
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        refresh()
    }

}
