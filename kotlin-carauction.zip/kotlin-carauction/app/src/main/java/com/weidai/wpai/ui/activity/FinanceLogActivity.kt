package com.weidai.wpai.ui.activity

import android.support.v4.app.Fragment
import com.weidai.wpai.R
import com.weidai.wpai.ui.fragment.FinanceLogFragment
import kotlinx.android.synthetic.main.activity_base_tab.*

class FinanceLogActivity : SimpleTabActivity() {

    override val tabContents: Array<String>
        get() = resources.getStringArray(R.array.tabFinancials)

    override val fragments: Array<Fragment>
        get() {
            navigationView.setTitle("资金明细")
            val financeLogFragment = FinanceLogFragment.newInstance(FinanceLogFragment.TYPE_FINANCE)
            val freezeLogFragment = FinanceLogFragment.newInstance(FinanceLogFragment.TYPE_FREEZE)
            return arrayOf(financeLogFragment, freezeLogFragment)
        }
}
