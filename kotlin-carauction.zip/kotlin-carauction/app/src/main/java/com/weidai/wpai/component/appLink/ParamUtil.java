package com.weidai.wpai.component.appLink;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by bici on 16/11/21.
 */

public class ParamUtil {

    public static Map<String, String> toMap(String url) {
        return toMap(url, "&", "=");
    }

    public static Map<String, String> toMap(String url, String seg1, String seg2) {
        Map<String, String> paramMap = new HashMap<>();
        int index = url.indexOf("?");
        if (index > 0) {
            String queryString = url.substring(index + 1, url.length());
            try {
                queryString = URLDecoder.decode(queryString, "utf-8");
                String[] queryArray = queryString.split(seg1);
                for (String queryItem : queryArray) {
                    String[] itemArray = queryItem.split(seg2);
                    if (itemArray.length == 2) {
                        paramMap.put(itemArray[0], itemArray[1]);
                    }
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        return paramMap;
    }
}
