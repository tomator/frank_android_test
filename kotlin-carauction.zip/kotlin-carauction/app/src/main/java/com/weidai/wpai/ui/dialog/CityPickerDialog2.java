package com.weidai.wpai.ui.dialog;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.hwangjr.rxbus.RxBus;
import com.weidai.wpai.R;
import com.weidai.wpai.common.EventKey;
import com.weidai.wpai.component.cityPick.adapter.SecondCityListAdapter;
import com.weidai.wpai.component.cityPick.db.City;
import com.weidai.wpai.component.cityPick.db.DBManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/10
 */
public class CityPickerDialog2 extends BaseFilterDialog {
    private ListView listView;
    private TextView notLimitTV;
    private TextView provinceTV;
    private View leftShadowView;
    private SecondCityListAdapter mCityAdapter;
    private List<City> mAllCities = new ArrayList<>();
    private DBManager dbManager = new DBManager(getContext());
    private City province;

    public CityPickerDialog2(@NonNull Context context, View baseView, City province) {
        super(context, baseView);
        getWindow().getAttributes().windowAnimations = R.style.DialogAnimRightIn;
        this.province = province;
        initData();
    }

    @Override
    protected int getLayoutRes() {
        return R.layout.cp_dialog_city_list2;
    }

    @Override
    protected void initView() {
        listView = (ListView) findViewById(R.id.listview_all_city);
        notLimitTV = (TextView) findViewById(R.id.not_limit_city);
        provinceTV = (TextView) findViewById(R.id.letter_province);
        leftShadowView = findViewById(R.id.leftShadowView);
    }

    protected void initData() {
        provinceTV.setText(province.getName());
        mAllCities = dbManager.getCitys(province.getId());
        mCityAdapter = new SecondCityListAdapter(getContext(), mAllCities);
        listView.setAdapter(mCityAdapter);
        mCityAdapter.setOnCityClickListener(new SecondCityListAdapter.OnCityClickListener() {
            @Override
            public void onCityClick(City city) {
                RxBus.get().post(EventKey.KEY_CHOOSE_CITY, city);
                dismiss();
            }
        });
        notLimitTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    City city = province.clone();
                    city.setType(City.Companion.getTYPE_CITY_ALL());
                    RxBus.get().post(EventKey.KEY_CHOOSE_CITY, city);
                } catch (CloneNotSupportedException e) {
                    e.printStackTrace();
                }
                dismiss();
            }
        });
        leftShadowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }
}
