package com.weidai.wpai.ui.evaluate.dialog

import android.app.Dialog
import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.ui.evaluate.adapter.CarChooseAdapter
import com.weidai.wpai.util.DensityUtil
import kotlinx.android.synthetic.main.dialog_list_choose.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/24
 */
class CarChooseDialog(context: Context, dataList: List<EvaluateCar>) : Dialog(context, R.style.Dialog_Alert) {

    var adapter: CarChooseAdapter

    init {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_list_choose, null)
        setContentView(view)
        val windowWidth = window.windowManager.defaultDisplay.width
        val layoutParams = view.layoutParams
        layoutParams.width = windowWidth - 2 * DensityUtil.dip2px(24f)
        view.layoutParams = layoutParams
        setCanceledOnTouchOutside(false)
        adapter = CarChooseAdapter(context)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(context)
        adapter.refreshDatas(dataList)

        negativeBtn.setOnClickListener { cancel() }
        positiveBtn.setOnClickListener {
            var data = adapter.getSelectData()
            if (data != null) {
                RxBus.get().post(EventKey.KEY_CHOOSE_CAR_EVALUATE, data)
                cancel()
            }
        }
    }


}