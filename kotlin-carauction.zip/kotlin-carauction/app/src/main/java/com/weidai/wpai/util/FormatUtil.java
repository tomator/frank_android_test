package com.weidai.wpai.util;

import android.text.TextUtils;

import com.robinhood.ticker.TickerUtils;

import java.text.DecimalFormat;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/17
 */
public class FormatUtil {

    public static final String MONEY_UNIT_SYMBOL = "￥";
    public static final String FORMAT_WAN_0 = "#######0.0";
    public static final String FORMAT_WAN_00 = "#######0.00";
    public static final String MONEY_FORMAT = "#,##0.00";
    public static final String MONEY_FORMAT_INT = "#,##0";

    public static String getDisplayString(String str) {
        if (TextUtils.isEmpty(str)) {
            return "";
        } else {
            return str;
        }
    }

    public static String getDisplayMobile(String mobile) {
        if (mobile == null || mobile.length() < 8) {
            return mobile;
        } else {
            return mobile.substring(0, mobile.length() - 8)
                    + "****" + mobile.substring(mobile.length() - 4, mobile.length());
        }
    }

    public static String getDouble2(double value) {
        DecimalFormat format = new DecimalFormat(FORMAT_WAN_00);
        return checkEnd0(format.format(value));
    }

    public static String getDouble2(String value) {
        double doubleValue = 0;
        try {
            doubleValue = Double.parseDouble(value);
        } catch (Exception e) {
        }
        DecimalFormat format = new DecimalFormat(FORMAT_WAN_00);
        return checkEnd0(format.format(doubleValue));
    }

    public static String getWan00(double value) {
        if (value < 10000) {
            return checkEnd0(value + "");
        } else {
            DecimalFormat formater = new DecimalFormat(FORMAT_WAN_00);
            return checkEnd0(formater.format(value / 10000.0)) + "万";
        }
    }

    public static String getWan00(String value) {
        return getWan00(Double.parseDouble(value));
    }

    public static String getWan0(double value) {
        if (value < 10000) {
            return checkEnd0(value + "");
        } else {
            DecimalFormat formater = new DecimalFormat(FORMAT_WAN_0);
            return checkEnd0(formater.format(value / 10000.0)) + "万";
        }
    }

    /**
     * 货币格式转化(特定格式 123,456,789.00)
     * 例如：格式：#,###.00 货币值 123456789.00
     * 输出 123,456,789.00
     *
     * @return 返回格式后的货币值
     */
    public static String getFormateMoney(int money) {
        return getFormateMoney(String.valueOf(money), MONEY_FORMAT_INT);
    }

    public static String getFormateMoney(String money) {
        return getFormateMoney(money, MONEY_FORMAT);
    }

    public static String getFormateMoney(double money) {
        return getFormateMoney(String.valueOf(money), MONEY_FORMAT);
    }

    public static String getChineseMoney(double money) {
        return FormatUtil.MONEY_UNIT_SYMBOL + getFormateMoney(String.valueOf(money));
    }

    public static String getChineseMoney(String money) {
        return FormatUtil.MONEY_UNIT_SYMBOL + getFormateMoney(String.valueOf(money));
    }

    public static String getFormateMoney(String money, String format) {
        try {
            DecimalFormat formater = new DecimalFormat(format);
            double tempDoubleValue = Double.parseDouble(money);
            tempDoubleValue = Arith.div(Math.floor(Arith.mul(tempDoubleValue, 100)), 100);
            String formatMoney = formater.format(tempDoubleValue);
            return checkEnd0(formatMoney);
        } catch (Exception e) {
            LogUtil.e(e.getMessage());
        }
        return "0";
    }

    public static String getFormateMoney00(String money) {
        return getFormateMoney00(money, MONEY_FORMAT);
    }

    public static String getFormateMoney00(double money) {
        return getFormateMoney00(String.valueOf(money), MONEY_FORMAT);
    }

    public static String getFormateMoney00(String money, String format) {
        try {
            DecimalFormat formater = new DecimalFormat(format);
            double tempDoubleValue = Double.parseDouble(money);
            tempDoubleValue = Arith.div(Math.floor(Arith.mul(tempDoubleValue, 100)), 100);
            String formatMoney = formater.format(tempDoubleValue);
            return formatMoney;
        } catch (Exception e) {
            LogUtil.e(e.getMessage());
        }
        return "0.00";
    }

    public static String getFormateMoney00Wan(double money) {
        DecimalFormat formater = new DecimalFormat(MONEY_FORMAT);
        double moneyWan = Arith.div(money, 10000);
        moneyWan = Arith.div(Math.floor(Arith.mul(moneyWan, 100)), 100);
        String formatMoney = formater.format(moneyWan);
        return formatMoney;
    }

    public static String checkEnd0(String formatMoney) {
        if (formatMoney.endsWith("0") && formatMoney.contains(".") || formatMoney.endsWith(".")) {
            formatMoney = formatMoney.substring(0, formatMoney.length() - 1);
            return checkEnd0(formatMoney);
        }
        return formatMoney;
    }

    public static String checkEnd0(double formatMoney) {
        return checkEnd0(String.valueOf(formatMoney));
    }

    public static double getDoubleMoney(String money) {
        double doubleValue = 0;
        try {
            doubleValue = Double.parseDouble(money);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return doubleValue;
    }

    public static int getIntValue(String money) {
        return (int) getDoubleMoney(money);
    }

    public static char[] getMoneyChars() {
        String str = "（当前价 万）";
        char[] current = str.toCharArray();
        char[] currency = TickerUtils.getDefaultListForUSCurrency();
        int len = current.length + currency.length;
        char[] result = new char[len];
        System.arraycopy(current, 0, result, 0, current.length);
        System.arraycopy(currency, 0, result, current.length, currency.length);
        return result;
    }
}
