package com.weidai.wpai.ui.view;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import com.weidai.wpai.R;
import com.weidai.wpai.util.DensityUtil;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/20
 */
public class AuctionToast {
    private Toast toast;

    public AuctionToast(Context context, String text) {
        toast = new Toast(context);
        TextView textView = new TextView(context);
        textView.setBackgroundResource(R.mipmap.bg_auciton_toast);
        textView.setTextSize(13);
        textView.setTextColor(Color.WHITE);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setPadding(0, 0, 0, DensityUtil.dip2px(2));
        toast.setView(textView);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP, 0, DensityUtil.dip2px(110f));
    }

    public void show() {
        toast.show();
    }
}
