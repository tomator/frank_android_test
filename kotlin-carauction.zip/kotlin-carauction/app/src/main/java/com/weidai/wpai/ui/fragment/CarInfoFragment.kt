package com.weidai.wpai.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.AuctionBean
import com.weidai.wpai.http.bean.CarInfoBean
import com.weidai.wpai.http.bean.VinResultBean
import com.weidai.wpai.http.param.SearchCodeVQO
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.ui.activity.MaintenanceActivity
import com.weidai.wpai.ui.activity.WPWebActivty
import com.weidai.wpai.ui.view.TabView
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.fragment_car_info.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/21
 */
class CarInfoFragment : BaseFragment() {

    lateinit var activity: AuctionActivity
    lateinit var auctionNo: String
    lateinit var tabView: TabView

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_car_info, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        activity = context as AuctionActivity
        auctionNo = activity.auctionNo
        tabView = activity.getNavigationTabView().getTabView()
        requestCarInfo()
        tabView.setOnCheckedLinstener { v, index ->
            if (index == 0) {
                scrollView.scrollTo(0, 0)
            } else if (index == 1) {
                scrollView.scrollTo(0, descriptionLL.top)
            } else {
                scrollView.scrollTo(0, auctionExplainLL.top)
            }
        }
        scrollView.setScrollChangeListener { scrollView, x, y, oldx, oldy ->
            val first = containerView.getChildAt(0)
            val second = containerView.getChildAt(1)
            val third = containerView.getChildAt(2)
            if (y > oldy && y >= second.bottom
                    && second.bottom >= oldy) {
                tabView.setCheckViewByIndex(1)
            }
            if (y > oldy && y >= third.bottom
                    && third.bottom >= oldy) {
                tabView.setCheckViewByIndex(2)
            }
            if (y < oldy && y <= 20) {
                tabView.setCheckViewByIndex(0)
            }
            if (y < oldy && y <= first.top + DensityUtil.dip2px(44f)
                    && first.top + DensityUtil.dip2px(44f) <= oldy) {
                tabView.setCheckViewByIndex(0)
            }
            if (y < oldy && y <= third.top + DensityUtil.dip2px(44f)
                    && third.top + DensityUtil.dip2px(44f) <= oldy) {
                tabView.setCheckViewByIndex(1)
            }
        }
        needKnowTV.setOnClickListener {
            WPWebActivty.openStaticPage(context, StaticPage.deal_mustKnow)
        }
    }

    private fun requestCarInfo() {
        Client.getService().auctionCarInfo(SearchCodeVQO(auctionNo))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<CarInfoBean>>() {
                    override fun onSuccess(result: Result<CarInfoBean>) {
                        super.onSuccess(result)
                        refreshView(result.data!!)
                        RxBus.get().post(EventKey.KEY_CAR_DETAIL_INFO, result.data)
                    }
                })
    }

    private fun refreshView(carInfo: CarInfoBean) {
        var builder = StringBuilder()
        val model = "${show(carInfo.brand)} ${show(carInfo.model)} ${show(carInfo.style)}" + " "
        builder.append(show(model))
        builder.append("\n").append(show(carInfo.volume))
        builder.append("\n").append(show(carInfo.gearbox))
        builder.append("\n").append(carInfo.mileage).append("公里")
        builder.append("\n").append(showYearMonth(carInfo.produceTime))
        builder.append("\n").append(showYearMonth(carInfo.registerTime))
        builder.append("\n").append(show(carInfo.color))
        builder.append("\n").append(show(carInfo.emission))
        builder.append("\n").append(show(carInfo.fuelType))
        baseInfoTV.text = builder.toString()
        builder = StringBuilder()
        if (carInfo.regionName != null) {
            for (region in carInfo.regionName) {
                builder.append(region)
            }
        }
        builder.append("\n").append(show(carInfo.carNumber))
        if (carInfo.transferable == 1) {
            builder.append("\n").append("可过户")
        } else {
            builder.append("\n").append("不可过户")
        }
        if (carInfo.withCarNumber == 1) {
            builder.append("\n").append("带牌")
        } else {
            builder.append("\n").append("不带牌")
        }
        builder.append("\n").append(showYearMonth(carInfo.asendTime))
        builder.append("\n").append(showYearMonth(carInfo.insuranceExpireTime))
        if (carInfo.bizInsurance === 1) {
            builder.append("\n").append("有")
        } else {
            builder.append("\n").append("无")
        }
        builder.append("\n").append(carInfo.illegalTotal).append("条 ")
                .append(FormatUtil.getDouble2(carInfo.illegalPoint)).append("分 ")
                .append(FormatUtil.getDouble2(carInfo.illegalFee)).append("元")
        builder.append("\n").append(show(carInfo.licenseDescribe))
        serviceInfoTV.text = builder.toString()
        descriptionTV.text = carInfo.note
        if (!TextUtils.isEmpty(carInfo.vin)) {
            requestVin(carInfo.vin)
        }
    }

    fun requestVin(vinCode: String) {
        Client.getService().checkvin(SearchCodeVQO(vinCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<VinResultBean>>() {
                    override fun onSuccess(result: Result<VinResultBean>) {
                        if (result.data != null) {
                            maintenanceLL.visibility = View.VISIBLE
                            maintenanceLL.setOnClickListener {
                                toMaintenance(vinCode)
                            }
                        }
                    }

                    override fun onFailed(result: Result<*>) {

                    }

                })
    }

    fun toMaintenance(vinCode: String) {
        startActivity(Intent(context, MaintenanceActivity::class.java)
                .putExtra("vinCode", vinCode))
    }

    private fun showYearMonth(date: String): String {
        val timestamp = DateUtil.parse(date, 1)
        if (timestamp == 0L) {
            return ""
        } else {
            return DateUtil.format(timestamp, 18)
        }
    }

    private fun show(str: String): String {
        var result = FormatUtil.getDisplayString(str)
        if (result.length > 20) {
            result = result.substring(0, 20) + "..."
        }
        return result
    }

    private fun refreshOtherInfo(auctionBean: AuctionBean) {
        val instructions = auctionBean.instruction
        if (instructions != null) {
            val builder = StringBuilder()
            for (i in instructions!!.indices) {
                if (i > 0) {
                    builder.append("\n")
                }
                builder.append(instructions!!.get(i))
            }
            auctionExplainTV.text = builder.toString()
        }
    }

    fun setAuctionBean(auctionBean: AuctionBean) {
        refreshOtherInfo(auctionBean)
    }

}
