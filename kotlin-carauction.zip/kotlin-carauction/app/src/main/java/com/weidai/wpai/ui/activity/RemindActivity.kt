package com.weidai.wpai.ui.activity

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.SimpleAuctionBean
import com.weidai.wpai.http.param.BaseSearchObject
import com.weidai.wpai.ui.adapter.RemindAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import kotlinx.android.synthetic.main.activity_remind.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class RemindActivity : BaseActivity() {
    private var index = Bean.PAGE_INDEX
    lateinit var adapter: RemindAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remind)
        navigationView.setTitle("我的提醒")
        initRefresh()

        Thread{
            kotlin.run {

            }
        }.start()
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(this)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(this))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200)
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(this,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = RemindAdapter(this)
        recyclerView.adapter = adapter
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        Client.getService().remindList(BaseSearchObject(index))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<ListData<SimpleAuctionBean>>>(ptrFrame) {
                    override fun onSuccess(result: Result<ListData<SimpleAuctionBean>>) {
                        super.onSuccess(result)
                        if (result.data != null && result.data!!.data != null) {
                            val dataList = result.data!!.data!!
                            if (refresh) {
                                adapter.refreshDatas(dataList)
                            } else {
                                adapter.addDatas(dataList)
                            }
                            if (dataList.size >= Bean.PAGE_SIZE) {
                                ptrFrame.mode = PtrFrameLayout.Mode.BOTH
                                index++
                            } else {
                                ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
                            }
                        }
                    }
                })
    }
}
