package com.weidai.wpai.ui.evaluate.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager

import com.weidai.wpai.R
import com.weidai.wpai.db.DBManager
import com.weidai.wpai.ui.adapter.EvaluateAdapter
import kotlinx.android.synthetic.main.activity_evaluate_history.*

class EvaluateHistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_evaluate_history)
        navigationView.setTitle("估价记录")
        val dbMdManager = DBManager(this)
        var dataList = dbMdManager.getEvaluateParams()
        recyclerView.layoutManager = LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.adapter = EvaluateAdapter(this, dataList)
    }

}
