package com.weidai.wpai.util.secret;

/**
 * @author jiafengshen
 * @Type Base64Util
 * @Desc
 * @date 2017年5月8日
 * @Version V1.0
 */
public class Base64Util {

    private Base64Util() {

    }

    /**
     * <code>encode</code>
     *
     * @return
     * @throws Exception
     * @description: TODO(把字节数据变成字符)
     * @since 2012-2-9 liaoyp
     */
    public static String encode(String str) {
        try {
            return Base64.encode(str, "Unicode");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * <code>decode</code>
     *
     * @param str
     * @return
     * @description: TODO(把字符变成字节数组)
     * @since 2012-2-9 liaoyp
     */
    public static String decode(String str) {
        str = str.substring(10, str.length() - 10);
        try {
            return Base64.decode(str, "Unicode");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) throws Exception {
        String ss = encode("12345678");
        System.out.println(ss);
        System.out.print(decode("1234567890" + ss + "1234567890"));
    }
}