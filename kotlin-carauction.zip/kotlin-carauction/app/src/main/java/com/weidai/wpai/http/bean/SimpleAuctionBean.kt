package com.weidai.wpai.http.bean

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/9
 */

/**
 * startTime	string	N	竞拍开始时间,格式 yyyy-MM-dd HH:mm:ss
 * picPath	string	N	竞拍主图
 * title	string	N	竞拍title
 * remainingStartTime	number	N	距离开始 ，单位秒
 * mileage	number	N	里程，单位万公里
 * status	number	N	竞拍状态，1竞拍中、2即将开始、3结束
 * regionName	string[]	N	车辆所在地，数组 省市，地市，区
 * remainingTime	number	N	剩余时间 ，单位秒
 * auctionNo	string	N	竞拍auctionNo
 * endTime	string	N	竞拍结束时间,格式 yyyy-MM-dd HH:mm:ss
 * startPrice	number	N	竞拍起拍价
 * registerTime	string	N	上牌时间
 * curPrice	number	N	竞拍当前价
 */
/**
 * 三期新增字段
 * auctionMode	number	Y	竞拍类型 0：升价拍 1：暗拍
 */
/**
 * 四期新增字段
 * canUseCoupon	boolean	Y	是否能用券，用于前端判断是否显示 使用优惠券 按钮
 * couponInfo	string	Y	优惠券信息，有则展示，无则不展示
 */

class SimpleAuctionBean {
    var remindStatus: Int = 0
    var auctionDetailStatus: Int = 0
    var canUseCoupon: Boolean = false
    var couponInfo: String? = null
    var auctionMode: Int = 0
    var tradeStatus: Int = 0
    var tradeStatusName: String? = null
    var auctionNo: String? = null
    var createTime: String? = null
    var curPrice: Double = 0.0
    var curTime: String? = null
    var endTime: String? = null
    var orderNo: String? = null
    var picPath: String? = null
    var remainingStartTime: Long = 0
    var remainingTime: Long = 0
    var startPrice: Double = 0.0
    var startTime: String? = null
    var status: Int = 0
    var statusName: String? = null
    var title: String? = null
    var mileage: Double = 0.0
    var registerTime: String? = null
    var regionName: List<String>? = null
}