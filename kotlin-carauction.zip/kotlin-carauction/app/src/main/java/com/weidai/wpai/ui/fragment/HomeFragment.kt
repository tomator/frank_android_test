package com.weidai.wpai.ui.fragment

import `in`.srain.cube.views.ptr.PtrDefaultHandler
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Build
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.BannerBean
import com.weidai.wpai.http.bean.SimpleAuctionBean
import com.weidai.wpai.http.param.AuctionRecommendVQO
import com.weidai.wpai.ui.activity.MainActivity
import com.weidai.wpai.ui.adapter.BannerViewAdapter
import com.weidai.wpai.ui.adapter.ProductListAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.fragment_home.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/8
 */
class HomeFragment : BaseFragment() {

    lateinit var carListAdapter: ProductListAdapter

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val height = StatusBarCompat.getStatusBarHeight(context)
            statusBar.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, height)
            statusBar.visibility = View.VISIBLE
        }
        initRefresh()
        allAuctionTV.setOnClickListener { (context as MainActivity).setCurrentItem(1) }
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(context)
        ptrFrame.headerView = refreshHeader
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler() {
            override fun onRefreshBegin(frame: PtrFrameLayout) {
                requestDatas()
            }
        })
        ptrFrame.isPullToRefresh = false
        ptrFrame.disableWhenHorizontalMove(true)
        RefreshHelper.autoRefresh(ptrFrame)

        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        carListAdapter = ProductListAdapter(this)
        recyclerView.adapter = carListAdapter
    }

    private fun requestDatas() {
        requestBanner()
        getRecommendList()
    }

    private fun requestBanner() {
        Client.getService().getBannerList("1")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<List<BannerBean>>>(ptrFrame) {
                    override fun onSuccess(result: Result<List<BannerBean>>) {
                        super.onSuccess(result)
                        updateBanners(result.data)
                    }
                })
    }

    private fun getRecommendList() {
        Client.getService().getRecommendList(AuctionRecommendVQO())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<ListData<SimpleAuctionBean>>>(ptrFrame) {
                    override fun onSuccess(result: Result<ListData<SimpleAuctionBean>>) {
                        var productSimples = result.data!!.data!!
                        if (productSimples.size == 0) {
                            emptyView.visibility = View.VISIBLE
                            recyclerView.visibility = View.GONE
                        } else {
                            emptyView.visibility = View.GONE
                            recyclerView.visibility = View.VISIBLE
                            carListAdapter.refreshDatas(productSimples)
                        }
                    }
                })
    }

    private fun updateBanners(list: List<BannerBean>?) {
        if (list != null && list.size > 0) {
            val adapter = BannerViewAdapter(context, list)
            bannerView.setAdapter(adapter, rgSplash)
            if (list.size > 1) {
                bannerView.startAutoSwitch(3000)
                bannerView.setCanChangePage(true)
            } else {
                bannerView.stopAutoSwitch()
                bannerView.setCanChangePage(false)
            }
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_AUCTION_COUNTDOWN_END)))
    fun onCountDownEnd(bool: Boolean?) {
        LogUtil.d(EventKey.TAG, "onCountDownEnd " + bool!!)
        getRecommendList()
    }

}
