package com.weidai.wpai.component.appUpdate

import com.facebook.stetho.okhttp3.StethoInterceptor
import com.weidai.wpai.BuildConfig
import okhttp3.*
import okhttp3.logging.HttpLoggingInterceptor
import rx.Observable
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.io.IOException
import java.util.concurrent.TimeUnit


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/20
 */
object HttpUtil {

    val JSON = MediaType.parse("application/json; charset=utf-8")!!
    val commonClient = createClient()

    fun createClient(): OkHttpClient {
        val okHttpBuilder = OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
        if (BuildConfig.DEBUG) {
            val logging = HttpLoggingInterceptor()
            logging.level = HttpLoggingInterceptor.Level.BODY
            okHttpBuilder.addInterceptor(logging)
            okHttpBuilder.addNetworkInterceptor(StethoInterceptor())
        }
        return okHttpBuilder.build()
    }

    fun requestGet(url: String, subscriber: Subscriber<Response>) {
        Observable.create(Observable.OnSubscribe<Response> { subscriber ->
            val okHttpClient = createClient()
            val request = Request.Builder()
                    .url(url)
                    .build()
            try {
                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    subscriber.onNext(response)
                    subscriber.onCompleted()
                } else {
                    subscriber.onError(Exception("request error " + response.code()))
                }
            } catch (e: IOException) {
                subscriber.onError(e)
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber)
    }

    fun requestPost(url: String, json: String, subscriber: Subscriber<Response>) {
        Observable.create(Observable.OnSubscribe<Response> { subscriber ->
            val okHttpClient = createClient()
            val body = RequestBody.create(JSON, json)
            val request = Request.Builder()
                    .url(url)
                    .post(body)
                    .build()
            try {
                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    subscriber.onNext(response)
                    subscriber.onCompleted()
                } else {
                    subscriber.onError(Exception("request error " + response.code()))
                }
            } catch (e: IOException) {
                subscriber.onError(e)
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber)
    }
}
