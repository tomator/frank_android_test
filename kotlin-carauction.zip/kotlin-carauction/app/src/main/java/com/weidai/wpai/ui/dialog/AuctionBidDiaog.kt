package com.weidai.wpai.ui.dialog

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import com.weidai.wpai.R
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.util.Arith
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.dialog_auction_bid.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/22
 */
class AuctionBidDiaog(context: Context, basePrice: Double, internal var increment: Double) : Dialog(context, R.style.Dialog_Fullscreen) {

    internal var basePrice: Double = 0.toDouble()
    internal var price: Double = 0.toDouble()
    internal var onCommitLister: OnCommitLister? = null

    init {
        init()
        setBasePrice(basePrice)
    }

    private fun init() {
        val window = window
        window.attributes.windowAnimations = R.style.DialogAnimFadeIn
        val windowHeight = window.windowManager.defaultDisplay.height
        val statusBarHeight = StatusBarCompat.getStatusBarHeight(context)
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - statusBarHeight
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_auction_bid, null)
        setContentView(view)
        onViewClicked()
    }

    fun setBasePrice(basePrice: Double) {
        this.basePrice = basePrice
        if (price < basePrice) {
            price = basePrice
        }
        refreshReduce()
        refreshPrice()
    }

    private fun refreshPrice() {
        commitBtn.isSelected = price > basePrice
        bidMoneyTV.text = FormatUtil.MONEY_UNIT_SYMBOL + FormatUtil.getFormateMoney(price)
        currentPriceTV.text = FormatUtil.getFormateMoney(basePrice)
    }

    private fun refreshReduce() {
        reduceBtn.isSelected = price > Arith.add(basePrice, increment)
    }

    fun onViewClicked() {
        reduceBtn.setOnClickListener {
            if (reduceBtn.isSelected) {
                price = Arith.sub(price, increment)
                refreshPrice()
                refreshReduce()
            }
        }
        addBtn.setOnClickListener {
            price = Arith.add(price, increment)
            refreshPrice()
            refreshReduce()
        }
        commitBtn.setOnClickListener {
            if (commitBtn.isSelected && onCommitLister != null) {
                onCommitLister!!.onCommit(price)
            }
        }
        shadowView.setOnClickListener { cancel() }
    }

    fun setOnCommitLister(onCommitLister: OnCommitLister) {
        this.onCommitLister = onCommitLister
    }

    interface OnCommitLister {
        fun onCommit(price: Double)
    }

}
