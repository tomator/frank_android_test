package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.db.City
import kotlinx.android.synthetic.main.car_view_item_search_result.view.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/21
 */
class SearchCityAdapter(val context: Context) : RecyclerView.Adapter<SearchCityAdapter.ViewHolder>() {
    var dataList: MutableList<City> = ArrayList()
    var inflater: LayoutInflater = LayoutInflater.from(context)

    fun refreshDatas(datas: List<City>?) {
        this.dataList.clear()
        if (datas != null && datas.size > 0) {
            this.dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = inflater.inflate(R.layout.car_view_item_search_result, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            var data = dataList[position]
            itemView.textView.text = data.name
            itemView.textView.setOnClickListener {
                RxBus.get().post(EventKey.KEY_CHOOSE_CITY, data)
            }
        }
    }
}

