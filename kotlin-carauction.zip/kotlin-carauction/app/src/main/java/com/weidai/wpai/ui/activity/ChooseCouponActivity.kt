package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.os.Handler
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.Coupon
import com.weidai.wpai.ui.adapter.EnableCouponAdapter
import com.weidai.wpai.ui.adapter.MyCouponAdapter
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.dialog.ToastDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.activity_choose_coupon.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class ChooseCouponActivity : BaseActivity() {
    lateinit var usableAdapter: EnableCouponAdapter
    lateinit var disableAdapter: MyCouponAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choose_coupon)
        navigationView.setTitle("选择优惠券")
        initRecyclerView()
        Handler().postDelayed({ requestCoupons() }, 300)
        commitTV.setOnClickListener {
            if (commitTV.isSelected) {
                showConfigDialog()
            }
        }
    }

    fun initRecyclerView() {
        usableAdapter = EnableCouponAdapter(this, Coupon.STATUS_CHOOSE_USABLE)
        disableAdapter = MyCouponAdapter(this, Coupon.STATUS_CHOOSE_DISABLE)
        usableRecyclerView.adapter = usableAdapter
        usableRecyclerView.layoutManager = LinearLayoutManager(this)
        disableRecyclerView.adapter = disableAdapter
        disableRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    fun requestCoupons() {
        var auctionNo = intent.getStringExtra("auctionNo")
        Client.getService().auctionCoupon(auctionNo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<List<List<Coupon>>>>() {
                    override fun onSuccess(result: Result<List<List<Coupon>>>) {
                        if (result.data != null && result.data!!.size > 0) {
                            onCouponsSuccess(result.data!!)
                        }
                    }
                })
    }

    fun onCouponsSuccess(dataList: List<List<Coupon>>) {
        var usableList = dataList[0]
        if (usableList.size == 0) {
            usableRecyclerView.visibility = View.GONE
            usableNullLL.visibility = View.VISIBLE
        } else {
            usableRecyclerView.visibility = View.VISIBLE
            usableNullLL.visibility = View.GONE
            usableAdapter.refreshDatas(usableList)
        }
        if (dataList.size > 1) {
            var disableList = dataList[1]
            if (disableList.size > 0) {
                disableLL.visibility = View.VISIBLE
                disableAdapter.refreshDatas(disableList)
            } else {
                disableLL.visibility = View.GONE
            }
        } else {
            disableLL.visibility = View.GONE
        }
    }

    fun showConfigDialog() {
        var carInfo = intent.getStringExtra("carInfo")
        var coupon = usableAdapter.getCoupon()!!
        var value = "${coupon.value}元"
        if (coupon.type == Coupon.TYPE_ZHEKOU) {
            value = "${coupon.value}折"
        }
        ToastDialog(this)
                .setTitleString("提示")
                .setContent("$carInfo 成交价为${FormatUtil.getDouble2(coupon.currentPrice)}元，" +
                        "优惠后价格为${FormatUtil.getDouble2(coupon.couponPrice)}元。" +
                        "\n是否确认使用${value}优惠券？")
                .setNegative("取消", View.OnClickListener {
                    ToastUtil.show("您已取消使用优惠券")
                    finish()
                })
                .setPositive("确定", View.OnClickListener { useCoupon() })
                .show()
    }

    fun useCoupon() {
        var auctionNo = intent.getStringExtra("auctionNo")
        var couponId = usableAdapter.getCoupon()!!.id.toString()
        var dailog = ProgressDialog(this)
        dailog.show()
        Client.getService().useAuctionCoupon(couponId, auctionNo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>(dailog) {
                    override fun onSuccess(result: Result<*>) {
                        ToastUtil.show("优惠券使用成功")
                        finish()
                        RxBus.get().post(EventKey.KEY_COUPON_USE_SUCCESS, true)
                    }
                })
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_COUPON_SELECT)))
    fun onCouponSelect(isSelect: Boolean?) {
        LogUtil.d("EventKey.KEY_COUPON_SELECT onCouponSelect $isSelect")
        commitTV.isSelected = isSelect!!
    }
}
