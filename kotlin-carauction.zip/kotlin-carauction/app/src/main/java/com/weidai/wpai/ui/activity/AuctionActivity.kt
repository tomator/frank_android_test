package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import android.view.View
import android.widget.TextView
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.AuctionBean
import com.weidai.wpai.ui.fragment.AuctionFragment
import com.weidai.wpai.ui.fragment.CarInfoFragment
import com.weidai.wpai.ui.view.NavigationTabView
import kotlinx.android.synthetic.main.activity_auction.*


class AuctionActivity : BaseActivity() {

    lateinit var auctionFragment: AuctionFragment
    lateinit var carInfoFragment: CarInfoFragment
    lateinit var auctionNo: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auction)
        auctionNo = intent.getStringExtra("auctionNo")
        auctionFragment = AuctionFragment()
        carInfoFragment = CarInfoFragment()
        initView()
    }

    private fun initView() {
        navigationTabView.visibility = View.GONE
        navigationView.visibility = View.VISIBLE
        navigationView.setTitle("竞拍详情")

        viewpager.adapter = object : FragmentPagerAdapter(supportFragmentManager) {
            override fun getItem(position: Int): Fragment {
                if (position == 0) {
                    return auctionFragment
                } else {
                    return carInfoFragment
                }
            }

            override fun getCount(): Int {
                return 2
            }
        }

        viewpager.setOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                if (position == 0) {
                    navigationTabView.visibility = View.GONE
                    navigationView.visibility = View.VISIBLE
                } else {
                    navigationTabView.visibility = View.VISIBLE
                    navigationView.visibility = View.GONE
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        bidTV.setOnClickListener { auctionFragment.onBidClick() }
        fixedTV.setOnClickListener { auctionFragment.onFixedClick() }
        remindLL.setOnClickListener {
            auctionFragment.onRemindClick()
        }
    }

    fun getNavigationTabView(): NavigationTabView {
        return navigationTabView
    }

    fun setAuctionBean(auctionBean: AuctionBean) {
        carInfoFragment.setAuctionBean(auctionBean)
    }

    fun getBidLL(): View {
        return bidLL
    }

    fun getBidTV(): TextView {
        return bidTV
    }

    fun getFixedTV(): TextView {
        return fixedTV
    }

    fun remindSelect(isSelect: Boolean) {
        if (isSelect) {
            remindIV.setImageResource(R.mipmap.ic_remind_blue)
            remindTV.text = "提醒"
            remindTV.setTextColor(resources.getColor(R.color.C1EA1FF))
        } else {
            remindIV.setImageResource(R.mipmap.ic_remind_gray)
            remindTV.text = "取消提醒"
            remindTV.setTextColor(resources.getColor(R.color.text_light_black))
        }
    }

    fun remindShow(isShow: Boolean) {
        if (isShow) {
            remindLL.visibility = View.VISIBLE
        } else {
            remindLL.visibility = View.GONE
        }
    }

    companion object {

        fun gotoThis(context: Context, auctionNo: String) {
            context.startActivity(Intent(context, AuctionActivity::class.java)
                    .putExtra("auctionNo", auctionNo))
        }
    }
}
