package com.weidai.wpai.common

import android.graphics.Bitmap
import android.support.annotation.DrawableRes
import android.text.TextUtils
import android.widget.ImageView
import com.squareup.picasso.LruCache
import com.squareup.picasso.MemoryPolicy
import com.squareup.picasso.Picasso
import com.weidai.wpai.App
import com.weidai.wpai.http.ApiHelper
import com.weidai.wpai.http.HostConfig
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.Executors

/**
 * Created by zhongyuan.jiang on 16/3/31 下午6:12.
 * Email jiang7637@gmail.com
 */
class ImageLoader private constructor() {
    private val picasso: Picasso
    private val noCachePicasso: Picasso
    private val largePicasso: Picasso

    init {
        val okHttpClient = ApiHelper.createImageLoaderClient()
        picasso = Picasso.Builder(App.instance)
                .memoryCache(LruCache(20 * 1000 * 1000))
                .downloader(OkHttp3Downloader(okHttpClient))
                .build()
        noCachePicasso = Picasso.Builder(App.instance)
                .downloader(OkHttp3Downloader(ApiHelper.createNoCacheClient()))
                .build()
        largePicasso = Picasso.Builder(App.instance)
                .downloader(OkHttp3Downloader(ApiHelper.createNoCacheClient()))
                .executor(Executors.newSingleThreadExecutor())
                .build()
    }

    fun displayRes(@DrawableRes resId: Int, imageView: ImageView) {
        picasso.load(resId).into(imageView)
    }

    fun displayRoundAssets(path: String, imageView: ImageView, @DrawableRes errorRes: Int) {
        val assets = "file:///android_asset/$path"
        picasso.load(assets).transform(CircleTransform()).error(errorRes).into(imageView)
    }

    fun displayFile(file: File, imageView: ImageView) {
        picasso.load(file).memoryPolicy(MemoryPolicy.NO_CACHE).into(imageView)
    }

    fun displayResize(url: String?, imageView: ImageView, width: Int, height: Int) {
        if (!TextUtils.isEmpty(url)) {
            picasso.load(url).resize(width, height).centerCrop().into(imageView)
        }
    }

    @JvmOverloads fun display(url: String?, imageView: ImageView, @DrawableRes errorRes: Int = 0, @DrawableRes holdRes: Int = 0) {
        var url = url
        if (url == null || TextUtils.isEmpty(url)) {
            if (errorRes != 0) {
                imageView.setImageResource(errorRes)
            }
            return
        }
        if (!url.startsWith("http")) {
            url = HostConfig.STATIC_HOST + url
        }
        val requestCreator = picasso.load(url)
        //                .memoryPolicy(MemoryPolicy.NO_CACHE);
        if (errorRes != 0) {
            requestCreator.error(errorRes)
            requestCreator.placeholder(errorRes)
        }
        if (holdRes != 0) {
            requestCreator.placeholder(holdRes)
        }
        requestCreator.into(imageView)
    }

    fun display(url: String?, imageView: ImageView, @DrawableRes errorRes: Int, width: Int, height: Int) {
        var url = url
        if (url == null || TextUtils.isEmpty(url)) {
            url = "error url"
        }
        val requestCreator = picasso.load(url)
        if (errorRes != 0) {
            requestCreator.error(errorRes)
            requestCreator.placeholder(errorRes)
        }
        requestCreator.resize(width, height)
        requestCreator.into(imageView)
    }

    fun displayRound(url: String?, imageView: ImageView, @DrawableRes errorRes: Int) {
        var url = url
        if (url == null || TextUtils.isEmpty(url)) {
            url = "error url"
        }
        val requestCreator = picasso.load(url)
        //                .memoryPolicy(MemoryPolicy.NO_CACHE);
        if (errorRes != 0) {
            requestCreator.error(errorRes)
            requestCreator.placeholder(errorRes)
        }
        requestCreator.transform(CircleTransform())
        //        requestCreator.transform(new RoundedTransformation(radius, margin));
        requestCreator.into(imageView)
    }


    fun load(url: String?): Bitmap? {
        var url = url
        if (url == null || TextUtils.isEmpty(url)) {
            url = "error url"
        }
        if (!url.startsWith("http")) {
            url = HostConfig.STATIC_HOST + url
        }
        try {
            return picasso.load(url).get()
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun storeBitmap(bitmap: Bitmap, fileName: String) {
        val file = File(fileName)
        storeBitmap(bitmap, file)
    }

    fun storeBitmap(bitmap: Bitmap, file: File) {
        var out: FileOutputStream? = null
        try {
            out = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 60, out)
            out.flush()
            out.close()
        } catch (e: Exception) {
            e.printStackTrace()
            if (out != null) {
                try {
                    out.close()
                } catch (ioException: IOException) {
                    ioException.printStackTrace()
                }
            }
        }
    }

    fun getNoCacheClient(): Picasso {
        return noCachePicasso
    }

    fun getLargeClient(): Picasso {
        return largePicasso
    }

    companion object {
        val instance = ImageLoader()

        val CHAT_IMAGE_PATH_TEMP = "/images/tmp.png"
        val CUT_IMAGE_PATH_TEMP = "/images/cut_tmp.png"

        val workFolder: String
            get() = App.instance.externalCacheDir!!.path

        fun createTempImage(): File {
            val tmpImagePath = workFolder + CHAT_IMAGE_PATH_TEMP
            val file = File(tmpImagePath)
            if (!file.exists()) {
                file.parentFile.mkdirs()
            } else {
                file.delete()
                file.parentFile.mkdirs()
            }
            return file
        }

        fun createTempImageByCut(): File {
            val tmpImagePath = workFolder + CUT_IMAGE_PATH_TEMP
            val file = File(tmpImagePath)
            if (!file.exists()) {
                file.parentFile.mkdirs()
            } else {
                file.delete()
                file.parentFile.mkdirs()
            }
            return file
        }

        val cutBitmapFile: File
            get() = File(workFolder + CUT_IMAGE_PATH_TEMP)
    }
}
