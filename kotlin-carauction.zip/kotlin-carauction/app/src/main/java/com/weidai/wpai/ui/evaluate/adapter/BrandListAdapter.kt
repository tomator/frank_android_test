package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.TextView
import com.github.promeg.pinyinhelper.Pinyin
import com.weidai.wpai.R
import com.weidai.wpai.extensions.findViewOften
import com.weidai.wpai.extensions.getFirstLetter
import com.weidai.wpai.extensions.pinyin
import com.zaaach.citypicker.view.WrapHeightGridView
import java.util.*

class BrandListAdapter(val mContext: Context) : BaseAdapter() {

    private var inflater: LayoutInflater = LayoutInflater.from(mContext)
    private val allDatas: MutableList<String> = ArrayList()
    private var hotDatas: MutableList<String> = ArrayList()
    private var letterIndexes: HashMap<String, Int>? = null
    private var itemClickListener: ItemClickListener? = null

    fun refreshDatas(allDatas: List<String>, hotDatas: List<String>) {
        this.allDatas.clear()
        Collections.sort(allDatas, Comparator<String> { o1, o2 ->
            if (o1 == null) return@Comparator -1
            if (o2 == null) return@Comparator 1
            var c1 = o1
            var c2 = o2
            if (Pinyin.isChinese(o1.first())) {
                c1 = o1.pinyin()
            }
            if (Pinyin.isChinese(o2.first())) {
                c2 = o2.pinyin()
            }
            c1.compareTo(c2)
        })
        this.allDatas.addAll(allDatas)
        this.hotDatas.clear()
        this.hotDatas.addAll(hotDatas)
        initDatas()
        notifyDataSetChanged()
        notifyDataSetInvalidated()
    }

    fun initDatas() {
        allDatas.add(0, "热")
        letterIndexes = HashMap<String, Int>()
        allDatas.forEachIndexed {
            index, s ->
            var currentLetter = allDatas[index].getFirstLetter()
            var previousLetter = if (index >= 1) {
                allDatas[index - 1].getFirstLetter()
            } else {
                ""
            }
            if (!TextUtils.equals(currentLetter, previousLetter)) {
                letterIndexes!!.put(currentLetter, index)
            }
        }
    }

    /**
     * 获取字母索引的位置
     * @param letter
     * @return
     */
    fun getLetterPosition(letter: String): Int {
        if (letterIndexes != null) {
            val integer = letterIndexes!![letter]
            return integer ?: -1
        } else {
            return -1
        }
    }

    override fun getViewTypeCount(): Int {
        return VIEW_TYPE_COUNT
    }

    override fun getItemViewType(position: Int): Int {
        return if (position < VIEW_TYPE_COUNT - 1) position else VIEW_TYPE_COUNT - 1
    }

    override fun getCount(): Int {
        return allDatas.size
    }

    override fun getItem(position: Int): String? {
        return allDatas[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view: View? = null
        val viewType = getItemViewType(position)
        when (viewType) {
            0 -> {
                view = inflater.inflate(R.layout.car_view_hot_brand, parent, false)
                val gridView = view!!.findViewById(R.id.gridView) as WrapHeightGridView
                val hotGridAdapter = HotGridAdapter(mContext, hotDatas)
                gridView.adapter = hotGridAdapter
                gridView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
                    if (itemClickListener != null) {
                        itemClickListener!!.onItemClick(hotGridAdapter.getItem(position)!!)
                    }
                }
            }
            1 -> {
                if (convertView == null) {
                    view = inflater.inflate(R.layout.car_view_brand_item, parent, false)
                } else {
                    view = convertView
                }
                if (position >= 1) {
                    val name = allDatas[position]
                    val nameTV: TextView = view!!.findViewOften(R.id.nameTV)
                    val letterTV: TextView = view!!.findViewOften(R.id.letterTV)
                    nameTV.text = name
                    val currentLetter = name.getFirstLetter()
                    val previousLetter = if (position >= 1) allDatas[position - 1].getFirstLetter() else ""
                    if (!TextUtils.equals(currentLetter, previousLetter)) {
                        letterTV.visibility = View.VISIBLE
                        letterTV.text = currentLetter
                    } else {
                        letterTV.visibility = View.GONE
                    }
                    nameTV.setOnClickListener {
                        if (itemClickListener != null) {
                            itemClickListener!!.onItemClick(name)
                        }
                    }
                }
            }
        }
        return view!!
    }

    fun setItemClickListener(listener: ItemClickListener) {
        this.itemClickListener = listener
    }

    interface ItemClickListener {
        fun onItemClick(name: String)
    }

    companion object {
        private val VIEW_TYPE_COUNT = 2
    }
}
