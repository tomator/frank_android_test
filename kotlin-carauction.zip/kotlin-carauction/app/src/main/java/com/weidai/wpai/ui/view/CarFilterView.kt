package com.weidai.wpai.ui.view

import android.app.Activity
import android.content.Context
import android.support.annotation.AttrRes
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.http.param.SearchAuctionVQO
import com.weidai.wpai.ui.dialog.*
import com.weidai.wpai.ui.model.CarAge
import com.weidai.wpai.ui.model.CarStatus
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.view_car_filter_tab.view.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/10
 */
class CarFilterView : FrameLayout {

    internal var cityPickerDialog: CityPickerDialog? = null
    internal var cityDialog2: CityPickerDialog2? = null
    internal var statusChooseDailog: StatusChooseDailog? = null
    internal var yearsPickerDailog: YearsPickerDailog? = null
    internal var chooseStatus: CarStatus? = null
    internal var chooseCity: City? = null
    internal var chooseAge: CarAge? = null

    var searchAuctionVQO: SearchAuctionVQO = SearchAuctionVQO()

    constructor(context: Context) : super(context) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init()
    }

    constructor(context: Context, attrs: AttributeSet?, @AttrRes defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init()
    }

    private fun init() {
        RxBus.get().register(this)
        LayoutInflater.from(context).inflate(R.layout.view_car_filter_tab, this, true)
        statusLL.setOnClickListener { onStatusClick() }
        cityLL.setOnClickListener { onCityClick() }
        carAgeLL.setOnClickListener { onCarAgeClick() }
    }

    fun getParams(): SearchAuctionVQO {
        if (chooseCity == null) {
            searchAuctionVQO.regionCode = SearchAuctionVQO.CAR_REGION_CODE_ALL
        } else {
            if ("all".equals(chooseCity!!.id)) {
                searchAuctionVQO.regionCode = SearchAuctionVQO.CAR_REGION_CODE_ALL
            } else {
                searchAuctionVQO.regionCode = chooseCity!!.id
            }
        }
        if (chooseStatus == null) {
            searchAuctionVQO.status = SearchAuctionVQO.CAR_STATUS_ALL
        } else {
            searchAuctionVQO.status = chooseStatus!!.value
        }
        if (chooseAge == null) {
            searchAuctionVQO.carAgeMin = "0"
            searchAuctionVQO.carAgeMax = "0"
        } else {
            searchAuctionVQO.carAgeMin = chooseAge!!.left
            searchAuctionVQO.carAgeMax = chooseAge!!.right
        }
        return searchAuctionVQO
    }

    private fun onStatusClick() {
        if (statusLL.isSelected) {
            closeAll()
        } else {
            closeAll()
            statusShow()
        }
    }

    private fun onCityClick() {
        if (cityLL.isSelected) {
            closeAll()
        } else {
            closeAll()
            cityShow()
        }
    }

    private fun onCarAgeClick() {
        if (carAgeLL.isSelected) {
            closeAll()
        } else {
            closeAll()
            carAgeShow()
        }
    }

    private fun closeAll() {
        statusClose()
        cityClose()
        carAgeClose()
    }

    private fun needShow(): Boolean {
        if (context == null) {
            return false
        }
        if (!App.instance.isAppOnForeground) {
            return false
        }
        if (context is Activity) {
            if (!(context as Activity).isFinishing) {
                return true
            }
        }
        return false
    }

    private fun statusShow() {
        statusLL.isSelected = true
        statusTV.isSelected = true
        statusLL.isSelected = true
        if (statusChooseDailog == null) {
            statusChooseDailog = StatusChooseDailog(context, this)
        }
        if (needShow()) {
            statusChooseDailog!!.show()
        }
    }

    private fun statusClose() {
        statusLL.isSelected = false
        statusTV.isSelected = false
        statusLL.isSelected = false
        if (statusChooseDailog != null && statusChooseDailog!!.isShowing) {
            statusChooseDailog!!.dismiss()
        }
    }

    private fun cityShow() {
        cityLL.isSelected = true
        cityTV.isSelected = true
        cityIV.isSelected = true
        if (cityPickerDialog == null) {
            cityPickerDialog = CityPickerDialog(context, this)
        }
        if (needShow()) {
            cityPickerDialog!!.show()
        }
    }

    private fun cityClose() {
        cityLL.isSelected = false
        cityTV.isSelected = false
        cityIV.isSelected = false
        if (cityPickerDialog != null && cityPickerDialog!!.isShowing) {
            cityPickerDialog!!.dismiss()
        }
        if (cityDialog2 != null && cityDialog2!!.isShowing) {
            cityDialog2!!.dismiss()
        }
    }

    private fun carAgeShow() {
        carAgeLL.isSelected = true
        carAgeTV.isSelected = true
        carAgeIV.isSelected = true
        if (yearsPickerDailog == null) {
            yearsPickerDailog = YearsPickerDailog(context, this)
        }
        if (needShow()) {
            yearsPickerDailog!!.show()
        }
    }

    private fun carAgeClose() {
        carAgeLL.isSelected = false
        carAgeTV.isSelected = false
        carAgeIV.isSelected = false
        if (yearsPickerDailog != null && yearsPickerDailog!!.isShowing) {
            yearsPickerDailog!!.dismiss()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_FILTER_DIALOG_DISMISS)))
    fun onFilterDialogDismiss(dialog: BaseFilterDialog) {
        LogUtil.d(EventKey.TAG, "onFilterDialogDismiss " + dialog)
        if (dialog is StatusChooseDailog) {
            statusClose()
        } else if (dialog is CityPickerDialog) {
            cityClose()
        } else if (dialog is YearsPickerDailog) {
            carAgeClose()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CITY)))
    fun onCityChoose(city: City) {
        LogUtil.d(EventKey.TAG, "onCityChoose " + city)
        when (city.type) {
            City.TYPE_PROVINCE -> {
                if (needShow()) {
                    cityDialog2 = CityPickerDialog2(context, this, city)
                    cityDialog2!!.show()
                }
            }
            City.TYPE_CITY_ALL, City.TYPE_CITY, City.TYPE_HOT, City.TYPE_LOCATION -> {
                chooseCity = city
                cityClose()
                cityTV.text = chooseCity!!.name
                RxBus.get().post(EventKey.KEY_FILTER_CHANGED, true)
            }
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_STATUS)))
    fun onCarStatusChoose(carStatus: CarStatus) {
        LogUtil.d(EventKey.TAG, "onCarStatusChoose " + carStatus)
        chooseStatus = carStatus
        statusTV.text = chooseStatus!!.name
        statusClose()
        RxBus.get().post(EventKey.KEY_FILTER_CHANGED, true)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_AGE)))
    fun onCarAgeChoose(carAge: CarAge) {
        LogUtil.d(EventKey.TAG, "onCarAgeChoose " + carAge)
        chooseAge = carAge
        carAgeTV.text = chooseAge!!.name
        carAgeClose()
        RxBus.get().post(EventKey.KEY_FILTER_CHANGED, true)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_FILTER_BAR_ON_CLICK)))
    fun onFilterBarClick(position: Int?) {
        LogUtil.d(EventKey.TAG, "onFilterBarClick " + position!!)
        when (position) {
            0 -> onStatusClick()
            1 -> onCityClick()
            2 -> onCarAgeClick()
        }
    }
}
