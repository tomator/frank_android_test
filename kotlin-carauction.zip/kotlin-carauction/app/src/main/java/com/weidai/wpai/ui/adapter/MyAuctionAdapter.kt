package com.weidai.wpai.ui.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.extensions.getSpan
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.AuctionBean
import com.weidai.wpai.http.bean.SimpleAuctionBean
import com.weidai.wpai.http.param.SearchTradeVQO
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.ui.activity.ChooseCouponActivity
import com.weidai.wpai.ui.activity.MyAuctionActivity
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.view_my_auction_item.view.*
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*


class MyAuctionAdapter(val context: Context, private val type: Int) : RecyclerView.Adapter<MyAuctionAdapter.ViewHolder>() {
    private val dataList = ArrayList<SimpleAuctionBean>()
    val viewMap = HashMap<String, ViewHolder>()
    private var timer: Timer? = null

    fun refreshDatas(datas: List<SimpleAuctionBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
        if (type == SearchTradeVQO.STATUS_AUCTION) {
            startTimer()
        }
    }

    fun addDatas(datas: List<SimpleAuctionBean>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_my_auction_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var auctionNo: String? = null

        fun bindData(data: SimpleAuctionBean) {
            itemView.currentPriceTV.setCharacterList(FormatUtil.getMoneyChars())
            itemView.currentPriceTV.animationDuration = 800
            itemView.dateTV.text = DateUtil.format(DateUtil.parse(data.createTime, 1), 15)
            itemView.statusTitleTV.text = data.tradeStatusName
            ImageLoader.instance.displayResize(data.picPath, itemView.carIV,
                    DensityUtil.dip2px(120f), DensityUtil.dip2px(90f))
            itemView.titleTV.text = data.title
            var carInfo = ""
            if (data.regionName != null) {
                for (i in 0..data.regionName!!.size - 1) {
                    carInfo += data.regionName!![i]
                }
            }
            val formatYear = DateUtil.getYear(data.registerTime)
            if (!TextUtils.isEmpty(formatYear)) {
                carInfo = "$carInfo/${formatYear}上牌"
            }
            carInfo = "$carInfo/${FormatUtil.getWan00(data.mileage)}公里"
            itemView.descriptionTV.text = carInfo
            itemView.minPriceTV.text = FormatUtil.getWan00(data.startPrice)
            if (viewMap.containsValue(this)) {
                viewMap.remove(auctionNo)
            }
            viewMap.put(data.auctionNo!!, this)
            itemView.currentPriceTV.setText("")
            itemView.remainingTV.visibility = View.GONE
            itemView.countDownView.visibility = View.GONE
            itemView.couponUseInfo.visibility = View.GONE
            itemView.useCouponTV.visibility = View.GONE
            auctionNo = data.auctionNo
            if (data.auctionMode == AuctionBean.AUCTION_MODE_NORMAL) {
                itemView.hideFlagIV.visibility = View.INVISIBLE
            } else {
                itemView.hideFlagIV.visibility = View.VISIBLE
            }
            itemView.toDetailTV.setOnClickListener {
                AuctionActivity.gotoThis(context, data.auctionNo!!)
            }
            if (data.canUseCoupon) {
                itemView.useCouponTV.visibility = View.VISIBLE
                itemView.useCouponTV.setOnClickListener {
                    context.startActivity(Intent(context, ChooseCouponActivity::class.java)
                            .putExtra("carInfo", data.title)
                            .putExtra("auctionNo", data.auctionNo))
                }
            } else {
                itemView.useCouponTV.visibility = View.GONE
            }
            if (TextUtils.isEmpty(data.couponInfo)) {
                itemView.couponUseInfo.visibility = View.GONE
            } else {
                itemView.couponUseInfo.visibility = View.VISIBLE
                var infoStr = "已使用优惠券 ${data.couponInfo}"
                var span = infoStr.getSpan(Color.parseColor("#FD3D14"), 7, infoStr.length)
                itemView.couponUseInfo.text = span
            }
            when (data.auctionDetailStatus) {
                AuctionBean.STATUS_AUCTIONING -> statusAuctioning(data)
                AuctionBean.STATUS_NOT_START -> statusNotStart(data)
                AuctionBean.STATUS_AUCTION_END,
                AuctionBean.STATUS_AUCTION_FAILED -> statusOver()
                AuctionBean.STATUS_AUCTION_WIN,
                AuctionBean.STATUS_AUCTION_WIN_DOWN -> {
                    statusOver()
                    itemView.statusTitleTV.setTextColor(Color.parseColor("#2196FE"))
                    itemView.priceDescTV.text = "成交"
                    itemView.minPriceTV.text = FormatUtil.getWan00(data.curPrice)
                }
                AuctionBean.STATUS_AUCTION_WIN_FAILED -> {
                    statusOver()
                    itemView.priceDescTV.text = "成交"
                    itemView.minPriceTV.text = FormatUtil.getWan00(data.curPrice)
                }
            }
        }

        fun statusAuctioning(data: SimpleAuctionBean) {
            itemView.statusTitleTV.setTextColor(Color.parseColor("#FD3D14"))
            itemView.statusTV.visibility = View.VISIBLE
            itemView.statusTV.text = "距离结束"
            itemView.statusTV.setTextColor(context.resources.getColor(R.color.FD3D14))
            itemView.statusTV.setBackgroundResource(R.drawable.bg_radiu_3_ffe9e5)
            itemView.countDownView.visibility = View.VISIBLE
            itemView.countDownView.start(data.remainingTime * 1000L)
            itemView.countDownView.setTextColor(context.resources.getColor(R.color.F9544F))
            itemView.countDownView.setOnCountdownEndListener {
                RxBus.get().post(EventKey.KEY_AUCTION_COUNTDOWN_END_MY, data.status)
            }
            val price = if (data.curPrice > data.startPrice) data.curPrice else data.startPrice
            if (data.auctionMode === AuctionBean.AUCTION_MODE_NORMAL) {
                itemView.currentPriceTV.setText("（当前价" + FormatUtil.getWan00(price) + "）")
            } else {
                itemView.currentPriceTV.setText("")
            }
            itemView.toDetailTV.text = "查看竞拍"
        }

        fun statusNotStart(data: SimpleAuctionBean) {
            itemView.statusTitleTV.setTextColor(Color.parseColor("#EB9604"))
            itemView.priceDescTV.text = "起拍"
            itemView.statusTV.visibility = View.VISIBLE
            itemView.statusTV.setTextColor(context.resources.getColor(R.color.EB9604))
            itemView.statusTV.setBackgroundResource(R.drawable.bg_radiu_3_fff0da)
            itemView.countDownView.setTextColor(context.resources.getColor(R.color.EB9604))
            if (data.remainingStartTime > THREE_HOUR) {
                itemView.statusTV.text = "开始时间"
                itemView.remainingTV.visibility = View.VISIBLE
                itemView.remainingTV.text = DateUtil.getYYMdHm(data.startTime)
            } else {
                itemView.statusTV.text = "即将开始"
                itemView.countDownView.visibility = View.VISIBLE
                itemView.countDownView.start(data.remainingStartTime * 1000)
                itemView.countDownView.setOnCountdownEndListener {
                    RxBus.get().post(EventKey.KEY_AUCTION_COUNTDOWN_END_MY, data.status)
                }
            }
            itemView.toDetailTV.text = "查看竞拍"
        }

        fun statusOver() {
            itemView.statusTitleTV.setTextColor(Color.parseColor("#999999"))
            itemView.priceDescTV.text = "起拍"
            itemView.statusTV.visibility = View.GONE
            itemView.countDownView.visibility = View.GONE
            itemView.remainingTV.visibility = View.GONE
            itemView.toDetailTV.text = "查看详情"
        }
    }

    fun startTimer() {
        timer?.let { timer!!.cancel() }
        timer = Timer()
        timer!!.schedule(object : TimerTask() {
            override fun run() {
                taskWorker()
            }
        }, 6000, 5000)
    }

    private fun taskWorker() {
        val activity = App.instance.currentActivity
        if (App.instance.isAppOnForeground
                && activity != null
                && activity is MyAuctionActivity) {
            var auctionNOs = ""
            for (auctionNo in dataList) {
                if (TextUtils.isEmpty(auctionNOs)) {
                    auctionNOs += auctionNo
                } else {
                    auctionNOs += "," + auctionNo
                }
            }
            if (!TextUtils.isEmpty(auctionNOs)) {
                requestWatch(auctionNOs)
            }
        }
    }

    private fun requestWatch(no: String) {
        Client.getService().auctionWatchList(no)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<Result<List<AuctionBean>>>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        LogUtil.e(e.message, e)
                    }

                    override fun onNext(listResult: Result<List<AuctionBean>>) {
                        if (listResult.data != null) {
                            onWatchList(listResult.data!!)
                        }
                    }
                })
    }

    private fun onWatchList(listResult: List<AuctionBean>) {
        listResult.forEach {
            if (viewMap.containsKey(it.auctionNo)) {
                val holder = viewMap[it.auctionNo]
                if (it.auctionMode === AuctionBean.AUCTION_MODE_NORMAL) {
                    holder!!.itemView.currentPriceTV.setText("（当前价${FormatUtil.getWan00(it.curPrice)}）")
                } else {
                    holder!!.itemView.currentPriceTV.setText("")
                }
                holder!!.itemView.countDownView.visibility = View.VISIBLE
                holder!!.itemView.countDownView.start(it.remainingEndTime * 1000L)
            }
        }
    }

    companion object {
        private val THREE_HOUR = 3 * 3600
    }
}
