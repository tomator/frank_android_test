package com.weidai.wpai.ui.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ImageView.ScaleType
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.ui.activity.AlbumActivity
import com.weidai.wpai.ui.view.AutoSwitchViewPager
import java.util.*

class AuctionBannerAdapter(private val mContext: Context, imageUrlList: List<String>?) : AutoSwitchViewPager.AutoSwitchPagerAdapter() {
    private var mBannerList: List<String> = ArrayList()
    private var mUrlListSize = 0

    init {
        if (null == imageUrlList) {
            mBannerList = ArrayList<String>()
        } else {
            mBannerList = imageUrlList
            mUrlListSize = imageUrlList.size
        }
    }

    override fun getCountOfContents(): Int {
        return mUrlListSize
    }

    override fun instantiateView(container: ViewGroup, position: Int): View? {
        if (0 == count) {
            return null
        }
        val realPosition = position % mUrlListSize
        val view = createBannerView(mBannerList[realPosition], realPosition)
        container.addView(view)
        return view
    }

    override fun destroyView(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun isViewFromObject(arg0: View, arg1: Any): Boolean {
        return arg0 === arg1
    }

    private fun createBannerView(bean: String, position: Int): View {
        val imageView = ImageView(mContext)
        ImageLoader.instance.display(bean, imageView, R.mipmap.bg_default_banner)
        imageView.scaleType = ScaleType.FIT_XY
        imageView.tag = bean
        imageView.setOnClickListener { AlbumActivity.gotoThis(mContext, mBannerList, position) }
        return imageView
    }
}