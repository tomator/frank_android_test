package com.weidai.wpai.http.bean

import java.io.Serializable

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/14
 */

/**
 * "asendTime": "2009-01-01",
 * "bizInsurance": 1,
 * "brand": "雷诺",
 * "carNumber": "浙A******",
 * "color": "黑",
 * "emission": "国4",
 * "fuelType": "柴油",
 * "gearbox": "自动",
 * "illegalFee": 100,
 * "illegalPoint": 10,
 * "illegalTotal": 10,
 * "insuranceExpireTime": "2009-01-01",
 * "licenseDescribe": "行驶证&交强险保单",
 * "mileage": 10000,
 * "model": "雷诺卡缤",
 * "note": "第24915测试测试，哈哈哈哈哈",
 * "produceTime": "2009-01-01",
 * "regionId": 330100,
 * "regionName": ["浙江省","杭州市"],
 * "registerTime": "2009-01-01",
 * "style": "2015款",
 * "transferable": 1,
 * "vin": "WBAYE2108DS124914",
 * "volume": "3.00T",
 * "withCarNumber": 2
 */
data class CarInfoBean(
        val illegalFee: Double,
        val withCarNumber: Int,
        val bizInsurance: Int,
        val insuranceExpireTime: String,
        val asendTime: String,
        val fuelType: String,
        val emission: String,
        val style: String,
        val gearbox: String,
        val brand: String,
        val carNumber: String,
        val color: String,
        val illegalPoint: Double,
        val illegalTotal: Int,
        val insurance: String,
        val invoiceMoney: Double,
        val mileage: Double,
        val model: String,
        val note: String,
        val produceTime: String,
        val regionId: Int,
        val registerTime: String,
        val reviewTime: String,
        val transferable: Int,
        val vin: String,
        val volume: String,
        val licenseDescribe: String,
        val regionName: List<String>,
        val shortRegionName: List<String>
) : Serializable