package com.weidai.wpai.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.activity_setting.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class SettingActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        navigationView.setTitle("设置")
        if (!UserManager.instance.isUserLogin) {
            logoutBtn.visibility = View.GONE
        }
        versionTV.text = "微车拍 V${BuildConfig.VERSION_NAME}(${BuildConfig.VERSION_CODE})"
        resetPwdItem.setOnClickListener { startActivity(Intent(this, PwdModifyActivity::class.java)) }
        resetPayPwdItem.setOnClickListener { startActivity(Intent(this, PayPwdResetActivity::class.java)) }
        logoutBtn.setOnClickListener { logout() }
    }

    fun testRoute() {
        var target: String? = null
        resetPwdItem.setOnClickListener {
            target = "native://notice"
        }
        resetPayPwdItem.setOnClickListener {
            target = "tab://1"
        }
        logoutBtn.setOnClickListener {
            target = "native://myCoupon"
        }
        var intent = Intent(this, MainActivity::class.java)
        intent.putExtra("target", target)
        startActivity(intent)
    }

    private fun logout() {
        val progressDialog = ProgressDialog(this)
        progressDialog.show()
        Client.getService().logout()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                    override fun onSuccess(result: Result<Boolean>) {
                        super.onSuccess(result)
                        UserManager.instance.cleanUserInfo()
                        RxBus.get().post(EventKey.KEY_USER_LOGOUT_SUCCESS, true)
                        ToastUtil.show("退出成功")
                        logoutBtn.visibility = View.GONE
                        finish()
                    }
                })
    }
}
