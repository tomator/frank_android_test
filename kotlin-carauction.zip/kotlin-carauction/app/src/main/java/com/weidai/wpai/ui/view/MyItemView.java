package com.weidai.wpai.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.weidai.wpai.R;


/**
 * Created by Administrator on 2016/4/28.
 */
public class MyItemView extends FrameLayout {

    private Drawable leftImg;
    private Drawable rightImg;
    private String leftText;
    private String rightText;

    private ImageView leftImgView;
    private ImageView rightImgView;
    private TextView leftTextView;
    private TextView rightTextView;
    private View lineView;

    private boolean isShake;
    private boolean isShowDot;
    private boolean isUserClick = true;
    private int rightTextSize = 0;
    private boolean isTop;

    private View view;
    private View dotView;
    private Context context;

    public MyItemView(Context context) {
        this(context, null);
    }

    public MyItemView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MyItemView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.ItemView);
        leftImg = typedArray.getDrawable(R.styleable.ItemView_leftImg);
        rightImg = typedArray.getDrawable(R.styleable.ItemView_rightImg);
        leftText = typedArray.getString(R.styleable.ItemView_leftText);
        rightText = typedArray.getString(R.styleable.ItemView_rightText);
        isShake = typedArray.getBoolean(R.styleable.ItemView_isShake, false);
        isShowDot = typedArray.getBoolean(R.styleable.ItemView_isShowDot, false);
        rightTextSize = typedArray.getInteger(R.styleable.ItemView_rightTextSize, 0);
        isTop = typedArray.getBoolean(R.styleable.ItemView_isTop, false);
        typedArray.recycle();

        initView();
    }

    private void initView() {
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.view_my_item, this);
        leftImgView = (ImageView) view.findViewById(R.id.leftImg);
        rightImgView = (ImageView) view.findViewById(R.id.rightImg);
        leftTextView = (TextView) view.findViewById(R.id.leftText);
        rightTextView = (TextView) view.findViewById(R.id.rightText);
        lineView = view.findViewById(R.id.line);
        dotView = view.findViewById(R.id.dotView);

        if (leftImg != null) {
            leftImgView.setVisibility(VISIBLE);
            leftImgView.setImageDrawable(leftImg);
        } else {
            leftImgView.setVisibility(GONE);
        }
        if (rightImg != null) {
            rightImgView.setVisibility(VISIBLE);
            rightImgView.setImageDrawable(rightImg);
        }
        if (leftText != null) {
            leftTextView.setVisibility(VISIBLE);
            leftTextView.setText(leftText);
        }
        if (rightText != null) {
            rightTextView.setVisibility(VISIBLE);
            rightTextView.setText(rightText);
        }
        if (isShowDot) {
            dotView.setVisibility(VISIBLE);
        }
        if (rightTextSize != 0) {
            rightTextView.setTextSize(rightTextSize);
        }

        if (isTop) {
            lineView.setVisibility(INVISIBLE);
        } else {
            lineView.setVisibility(VISIBLE);
        }
    }

    public void setRightText(String rightText) {
        this.rightText = rightText;
        rightTextView.setText(rightText);
    }

    public void showHideDot(boolean show) {
        if (show) {
            dotView.setVisibility(VISIBLE);
        } else {
            dotView.setVisibility(INVISIBLE);
        }
    }
}
