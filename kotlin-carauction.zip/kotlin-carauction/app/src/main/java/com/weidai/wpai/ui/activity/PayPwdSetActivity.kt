package com.weidai.wpai.ui.activity

import android.os.Bundle
import com.weidai.wpai.R
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.SetPayPwdVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_pay_pwd_set.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class PayPwdSetActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_pwd_set)
        passwordAET.setOnTextChange { checkCommitEnable() }
        repeatAET.setOnTextChange { checkCommitEnable() }
        confirmBtn.setOnClickListener {
            if (confirmBtn.isSelected) {
                submit()
            }
        }
    }

    private fun checkCommitEnable() {
        val password = passwordAET.text.toString()
        val repeat = repeatAET.text.toString()
        confirmBtn.isSelected = ValidityUtils.checkPayPwd(repeat)
                && ValidityUtils.checkPayPwd(password)
    }

    private fun submit() {
        val password = passwordAET.text.toString()
        val repeat = repeatAET.text.toString()
        if (password == repeat) {
            val progressDialog = ProgressDialog(this)
            progressDialog.show()
            Client.getService().setPayPwd(SetPayPwdVQO(PasswordUtil.encode(password)))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                        override fun onSuccess(result: Result<Boolean>) {
                            super.onSuccess(result)
                            ToastUtil.show("设置成功")
                            UserManager.instance.setPayPwd(true)
                            finish()
                        }
                    })
        } else {
            ToastUtil.show("两次密码输入不一致，请重新输入")
        }
    }
}
