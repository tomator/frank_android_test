package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import com.weidai.wpai.R
import com.weidai.wpai.http.param.SearchTradeVQO
import com.weidai.wpai.ui.fragment.MyAuctionFragment
import kotlinx.android.synthetic.main.activity_my_auction.*

class MyAuctionActivity : BaseActivity() {

    lateinit var fragmentEntry: MyAuctionFragment
    lateinit var fragmentAcution: MyAuctionFragment
    lateinit var fragmentOver: MyAuctionFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_auction)
        fragmentAcution = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_AUCTION)
        fragmentEntry = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_ENTRY)
        fragmentOver = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_OVER)
        initView()
        var position = intent.getIntExtra("position", 0)
        viewpager.currentItem = position
    }

    private fun initView() {
        navigationView.setTitle("我的竞拍")
        tabView.setOnCheckedLinstener { v, index -> viewpager.currentItem = index }
        viewpager.offscreenPageLimit = 2
        viewpager.adapter = object : FragmentPagerAdapter(supportFragmentManager) {
            override fun getItem(position: Int): Fragment? {
                when (position) {
                    0 -> return fragmentAcution
                    1 -> return fragmentEntry
                    2 -> return fragmentOver
                    else -> return null
                }
            }

            override fun getCount(): Int {
                return resources.getStringArray(R.array.tabMyAuctions).size
            }
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                tabView.setCheckViewByIndex(position)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }
}
