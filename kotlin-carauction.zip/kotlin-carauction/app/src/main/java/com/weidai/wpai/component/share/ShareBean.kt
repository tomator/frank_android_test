package com.weidai.wpai.component.share

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/26
 */
class ShareBean {

    var title: String? = null
    var description: String? = null
    var shareUrl: String? = null
    var imgRes: Int = 0
    var type: Int = 0

    override fun toString(): String {
        return " title = $title \n " +
                "description = $description \n " +
                "shareUrl = $shareUrl \n " +
                "type = $type"
    }

    companion object {
        val TYPE_WECHAT = 1            //微信
        val TYPE_WECHAT_GROUP = 2      //微信朋友圈
    }
}
