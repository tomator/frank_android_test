package com.weidai.wpai.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

import com.weidai.wpai.R

/**
 * Created by Aeiric on 16-11-4.
 */

class GuideFragment : BaseFragment() {
    private var index = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            index = arguments.getInt(ARG_INDEX)
        }
    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater!!.inflate(R.layout.fragment_guide, container, false)
        val imageView = view.findViewById(R.id.imageView) as ImageView
        when (index) {
            1 -> {
            }
        }
        container!!.addView(view)
        imageView.setOnClickListener {
            if (index == 4) {

            }
        }
        return view
    }

    companion object {

        private val ARG_INDEX = "ARG_INDEX"

        fun newInstance(type: Int): GuideFragment {
            val fragment = GuideFragment()
            val args = Bundle()
            args.putInt(ARG_INDEX, type)
            fragment.arguments = args
            return fragment
        }
    }
}
