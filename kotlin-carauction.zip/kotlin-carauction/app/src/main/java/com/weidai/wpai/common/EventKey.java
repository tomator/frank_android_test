package com.weidai.wpai.common;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/11
 */
public interface EventKey {

    public static final String TAG = "EventKey";
    public static final String KEY_FILTER_DIALOG_DISMISS = "KEY_FILTER_DIALOG_DISMISS";
    public static final String KEY_FILTER_BAR_ON_CLICK = "KEY_FILTER_BAR_ON_CLICK";

    public static final String KEY_USER_REGISTER_SUCCESS = "KEY_USER_REGISTER_SUCCESS";
    public static final String KEY_USER_PWD_RESET_SUCCESS = "KEY_USER_PWD_RESET_SUCCESS";
    public static final String KEY_USER_LOGIN_SUCCESS = "KEY_USER_LOGIN_SUCCESS";
    public static final String KEY_USER_NOT_LOGIN = "KEY_USER_NOT_LOGIN";
    public static final String KEY_USER_LOGOUT_SUCCESS = "KEY_USER_LOGOUT_SUCCESS";
    public static final String KEY_USER_GET_CARD_INFO = "KEY_USER_GET_CARD_INFO";
    public static final String KEY_USER_GET_BALANCE = "KEY_USER_GET_BALANCE";
    public static final String KEY_USER_CLEAR_INFO = "KEY_USER_CLEAR_INFO";

    public static final String KEY_GET_CITYS_RESULT = "KEY_GET_CITYS_RESULT";
    public static final String KEY_LOCATION_CITY = "KEY_LOCATION_CITY";
    public static final String KEY_CHOOSE_CITY = "KEY_CHOOSE_CITY";
    public static final String KEY_CHOOSE_CAR_STATUS = "KEY_CHOOSE_CAR_STATUS";
    public static final String KEY_CHOOSE_CAR_AGE = "KEY_CHOOSE_CAR_AGE";
    public static final String KEY_FILTER_CHANGED = "KEY_AUCTION_FILTER_CHANGED";

    public static final String KEY_USER_BIND_CARD_SUCCESS = "KEY_USER_BIND_CARD_SUCCESS";
    public static final String KEY_PAY_PWD_INPUT_FINISH = "KEY_PAY_PWD_INPUT_FINISH";
    public static final String KEY_RECHARGE_RESULT = "KEY_RECHARGE_RESULT";
    public static final String KEY_WITHDRAW_RESULT = "KEY_WITHDRAW_RESULT";

    public static final String KEY_AUCTION_COUNTDOWN_END_MY = "KEY_AUCTION_COUNTDOWN_END_MY";
    public static final String KEY_AUCTION_COUNTDOWN_END = "KEY_AUCTION_COUNTDOWN_END";

    public static final String KEY_NOTICE_TIP = "KEY_NOTICE_TIP";
    public static final String KEY_PUSH_DATA = "KEY_PUSH_DATA";

    public static final String KEY_CHOOSE_CAR_EVALUATE = "KEY_CHOOSE_CAR_EVALUATE";

    public static final String KEY_COUPON_SELECT = "KEY_COUPON_SELECT";
    public static final String KEY_COUPON_USE_SUCCESS = "KEY_COUPON_USE_SUCCESS";

    public static final String KEY_CAR_DETAIL_INFO = "KEY_CAR_DETAIL_INFO";

}
