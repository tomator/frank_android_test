package com.weidai.wpai.ui.model;

import com.weidai.wpai.http.base.Bean;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class CarAge implements Bean {

    private String left;

    private String right;

    private String name;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLeft() {
        return left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }
}
