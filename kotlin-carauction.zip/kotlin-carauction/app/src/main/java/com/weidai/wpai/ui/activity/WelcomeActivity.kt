package com.weidai.wpai.ui.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.R
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.activity_welcome.*

class WelcomeActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
        initView()
    }

    private fun initView() {
        if (SpfUtils.getInstance().lastVersion < BuildConfig.VERSION_CODE) {
            showGuide()
        } else {
            toMainActivity(1000)
        }
    }

    private fun showGuide() {
        val resArray = intArrayOf(R.mipmap.img_guide_image1,
                R.mipmap.img_guide_image2,
                R.mipmap.img_guide_image3)
        viewpagerDot.setDot(resArray.size)
        viewpagerDot.visibility = View.GONE
        viewpagerDot.setDotLight(0)
        viewpager.visibility = View.VISIBLE
        viewpager.adapter = object : PagerAdapter() {
            override fun getCount(): Int {
                return resArray.size
            }

            override fun isViewFromObject(view: View, `object`: Any): Boolean {
                return view === `object`
            }

            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                val imageView = ImageView(container.context)
                val redId = resArray[position]
                imageView.setImageResource(redId)
                container.addView(imageView)
                imageView.scaleType = ImageView.ScaleType.FIT_XY
                imageView.setOnClickListener {
                    if (position == resArray.size - 1) {
                        toMainActivity(0)
                    }
                }
                return imageView
            }

            override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {

            }
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                viewpagerDot.setDotLight(position)
                if (position == resArray.size - 1) {
                    SpfUtils.getInstance().saveLastVersion()
                }
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }

    fun toMainActivity(second: Long) {
        Handler().postDelayed({
            startActivity(Intent(this@WelcomeActivity, MainActivity::class.java))
            finish()
        }, second)
    }
}
