package com.weidai.wpai

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.os.IBinder
import android.text.TextUtils
import android.view.View
import android.view.inputmethod.InputMethodManager
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.facebook.stetho.Stetho
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.igexin.sdk.PushManager
import com.tencent.bugly.crashreport.CrashReport
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.StatisticalManager
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.component.cityPick.db.DBManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.ConstantBean
import com.weidai.wpai.http.bean.HotCity
import com.weidai.wpai.http.bean.NoticeTipBean
import com.weidai.wpai.service.GTPushIntentService
import com.weidai.wpai.service.GTPushService
import com.weidai.wpai.ui.activity.MainActivity
import com.weidai.wpai.ui.model.PushBean
import com.weidai.wpai.util.AppUtil
import com.weidai.wpai.util.ChannelUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfUtils
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/7
 */
class App : Application() {
    var mActivitys: MutableMap<String, Activity> = HashMap()
    var currentActivity: Activity? = null
    private var locationClient: AMapLocationClient? = null
    var locationCity: City? = null
        private set
    var constantBean: ConstantBean? = null
        private set

    companion object {
        lateinit var instance: App
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val processName = AppUtil.getProcessName(this, android.os.Process.myPid())
        if (processName != null && processName == packageName) {
            initMainProcess()
        }
    }

    private fun initMainProcess() {
        CrashReport.initCrashReport(this, BuildConfig.BUGLY_APPID, false)
        CrashReport.setAppChannel(this, ChannelUtil.getChannel(this))
        if (UserManager.instance.isUserLogin) {
            CrashReport.setUserId(UserManager.instance.userMobile)
        }
        StatisticalManager.init(this)
        PushManager.getInstance().initialize(this, GTPushService::class.java)
        PushManager.getInstance().registerPushIntentService(this, GTPushIntentService::class.java)
        Stetho.initializeWithDefaults(this)
        Client.init()
        initAppConfigInfo()
        RxBus.get().register(this)
    }

    private fun initAppConfigInfo() {
        initLocation()
        initConstant()
        initCity()
        if (UserManager.instance.isUserLogin) {
            PushManager.getInstance().bindAlias(this, UserManager.instance.userMobile)
        }
    }

    fun initConstant() {
        Client.getService().constant
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.computation())
                .subscribe(object : Subscriber<Result<ConstantBean>>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        LogUtil.e(e.message, e)
                    }

                    override fun onNext(result: Result<ConstantBean>) {
                        if (result.code == Result.CODE_SUCEESS) {
                            constantBean = result.data
                            if (constantBean != null) {
                                SpfUtils.getInstance().saveServiceNo(constantBean!!.custommobile)
                            }
                        }
                    }
                })
    }

    fun initCity() {
        var dbManager = DBManager(this)
        if (dbManager.cityCount <= 0) {
            dbManager.importCity()
            initHotCitys()
        } else {
            initHotCitys()
        }
    }

    fun initHotCitys() {
        Client.getService().hotCityList
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(object : Subscriber<Result<HotCity>>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        LogUtil.e(e.message, e)
                    }

                    override fun onNext(result: Result<HotCity>) {
                        if (result.code == Result.CODE_SUCEESS
                                && result.data != null) {
                            SpfUtils.getInstance().saveHotCityId(result.data)
                        }
                    }
                })
    }

    private fun initLocation() {
        AMapLocationClient.setApiKey(BuildConfig.AMAP_APPID)
        locationClient = AMapLocationClient(this)
        val lastLocation = locationClient!!.lastKnownLocation
        if (lastLocation != null) {
            val city = lastLocation.city
            locationCity = DBManager(this).getLocalCity(city)
            LogUtil.d("aMapLocation last : " + lastLocation)
        }
        val option = AMapLocationClientOption()
        option.locationMode = AMapLocationClientOption.AMapLocationMode.Battery_Saving
        option.isOnceLocation = true
        option.isGpsFirst = false
        option.httpTimeOut = 30 * 1000L
        locationClient!!.setLocationOption(option)
        locationClient!!.setLocationListener { aMapLocation ->
            LogUtil.d("aMapLocation : " + aMapLocation!!)
            if (aMapLocation != null && aMapLocation.errorCode == 0) {
                val city = aMapLocation.city
                locationCity = DBManager(this@App).getLocalCity(city)
                RxBus.get().post(EventKey.KEY_LOCATION_CITY, locationCity!!)
            } else {
                locationCity = null
                RxBus.get().post(EventKey.KEY_LOCATION_CITY, City())
            }
        }
        startLocation()
    }

    fun startLocation() {
        locationClient!!.startLocation()
    }

    fun requestNewMessage() {
        Client.getService().hasNewMessage(SpfUtils.getInstance().getNoticeData())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<Result<NoticeTipBean>>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {

                    }

                    override fun onNext(result: Result<NoticeTipBean>) {
                        RxBus.get().post(EventKey.KEY_NOTICE_TIP, result.data)
                    }
                })
    }

    fun addActivity(key: String, activity: Activity) {
        if ("LoginActivity" == key && mActivitys[key] != null) {
            mActivitys[key]!!.finish()
        }
        mActivitys.put(key, activity)
    }

    fun removeActivity(key: String) {
        mActivitys.remove(key)
    }

    fun resetActivity() {
        for (activity in mActivitys.values) {
            if (activity !is MainActivity) {
                activity.finish()
            }
        }
    }

    val mainActivity: MainActivity?
        get() {
            if (mActivitys != null) {
                val activity = mActivitys[MainActivity::class.java.simpleName]
                if (activity != null && activity is MainActivity) {
                    return activity
                }
            }
            return null
        }

    fun finishAll() {
        for (activity in mActivitys.values) {
            activity.finish()
        }
    }

    fun exit() {
        finishAll()
        System.exit(0)
    }

    /**
     * 获取Android设备中所有正在运行的App
     */
    // The name of the process that this object is associated with.
    val isAppOnForeground: Boolean
        get() {
            val activityManager = applicationContext
                    .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val packageName = applicationContext.packageName
            val appProcesses = activityManager.runningAppProcesses ?: return false
            for (appProcess in appProcesses) {
                if (appProcess.processName == packageName
                        && appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    return true
                }
            }
            return false
        }

    fun isNetWorkConnected(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        return netInfo != null && netInfo.isConnected
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_PUSH_DATA)))
    fun onPushData(pushBean: PushBean) {
        LogUtil.d(EventKey.TAG, " App onPushData " + pushBean)
        if (pushBean.isAlert) {
            showNotification(pushBean)
        }
    }

    fun showNotification(pushBean: PushBean) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = Notification.Builder(this)
                .setTicker(getString(R.string.app_name))
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.push_small)
                .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.push))
                .setContentTitle(pushBean.title)
                .setContentText(pushBean.content)
        val intent = Intent()
        intent.action = Intent.ACTION_MAIN
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.setClass(this, MainActivity::class.java)
        if (!TextUtils.isEmpty(pushBean.url)) {
            intent.putExtra("target", pushBean.url)
        }
        val contentIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        builder.setContentIntent(contentIntent)
        val notification = builder.build()
        notificationManager.notify((System.currentTimeMillis() / 1000).toInt(), notification)
    }

    /**
     * 隐藏软键盘
     */
    fun hideSoftInput(windowToken: IBinder) {
        val inputManger = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputManger.hideSoftInputFromWindow(windowToken, 0)
    }

    /**
     * 打开软键盘
     */
    fun showSoftInput(view: View) {
        val inputManger = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputManger.showSoftInput(view, InputMethodManager.SHOW_FORCED)
    }

}
