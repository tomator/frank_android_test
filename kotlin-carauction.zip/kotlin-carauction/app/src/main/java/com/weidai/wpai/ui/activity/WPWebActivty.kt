package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.webkit.WebSettings
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.http.HostConfig
import com.weidai.wpai.util.LogUtil
import org.apache.cordova.BaseCordovaWebActivity
import org.apache.cordova.plugin.IRouteStrategy

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/28
 */
class WPWebActivty : BaseCordovaWebActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.extras.getString(IRouteStrategy.INTENT_TITLE)
        if (!TextUtils.isEmpty(title)) {
            setTitle(title)
        }
    }

    override fun setUserAgent(webSettings: WebSettings) {
        val userAgent = "WeiDai($packageName/${BuildConfig.VERSION_NAME}) Cordova/1.0.0"
        webSettings.userAgentString = webSettings.userAgentString + userAgent
        LogUtil.d("userAgent : " + webSettings.userAgentString)
    }

    override fun getIntentFilterDataHostName(): String {
        return packageName
    }

    companion object {

        fun openStaticPage(context: Context, url: String, title: String? = null) {
            if (!TextUtils.isEmpty(url)) {
                var url = url
                if (!url.startsWith("http") && !url.startsWith("www.")) {
                    url = HostConfig.STATIC_HOST + url
                }
                open(context, url, title)
            }
        }

        fun open(context: Context, url: String, title: String? = null) {
            val bundle = Bundle()
            bundle.putString(IRouteStrategy.INTENT_URL, url)
            bundle.putString(IRouteStrategy.INTENT_TITLE, title)
            open(context, bundle)
        }

        fun open(context: Context, bundle: Bundle) {
            val intent = Intent(context, WPWebActivty::class.java)
            intent.putExtras(bundle)
            context.startActivity(intent)
        }
    }
}
