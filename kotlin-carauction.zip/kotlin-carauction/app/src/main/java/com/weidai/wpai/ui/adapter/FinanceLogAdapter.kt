package com.weidai.wpai.ui.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.FunLogBean
import com.weidai.wpai.ui.fragment.FinanceLogFragment
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.view_finance_item.view.*
import java.util.*

class FinanceLogAdapter(val context: Context, val type: Int) : RecyclerView.Adapter<FinanceLogAdapter.ViewHolder>() {
    private val dataList = ArrayList<FunLogBean>()

    fun refreshDatas(datas: List<FunLogBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<FunLogBean>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_finance_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bindData(data: FunLogBean) {
            itemView.titleTV.text = data.transSubName
            itemView.dateTV.text = data.gmtCreate
            var amountString = FormatUtil.getFormateMoney(data.amount)
            if (data.amount > 0) {
                amountString = "+" + amountString
            }
            itemView.detailTV.text = amountString
            if (type == FinanceLogFragment.TYPE_FINANCE
                    && data.transSubType == FunLogBean.TYPE_RECHARE) {
                itemView.detailTV.setTextColor(context.resources.getColor(R.color.main_blue))
            } else {
                itemView.detailTV.setTextColor(context.resources.getColor(R.color.text_dark_black))
            }
        }
    }
}
