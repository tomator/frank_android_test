package com.weidai.wpai.ui.evaluate.activity

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.text.TextUtils
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.CarSearchBean
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.evaluate.adapter.BrandListAdapter
import com.weidai.wpai.ui.evaluate.adapter.LabelAdapter
import com.weidai.wpai.ui.evaluate.adapter.SearchBrandAdapter
import com.weidai.wpai.ui.evaluate.adapter.SearchModelAdapter
import com.weidai.wpai.ui.view.FlowLayoutManager
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.activity_car_search.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class CarSearchActivity : BaseActivity() {

    lateinit var histroyAdapter: LabelAdapter
    lateinit var hotAdapter: LabelAdapter
    lateinit var searchBrandAdapter: SearchBrandAdapter
    lateinit var searchModelAdapter: SearchModelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_search)
        navigationView.searchView.edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        navigationView.searchView.edit.setOnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                App.instance.hideSoftInput(navigationView.searchView.edit.windowToken)
                search(navigationView.getSearchText())
            }
            false
        }
        navigationView.onSearchListener = View.OnClickListener {
            var keyWord = navigationView.getSearchText()
            if (!TextUtils.isEmpty(keyWord)) {
                search(keyWord)
            }
        }
        navigationView.searchView.setOnTextChange { input ->
            if (TextUtils.isEmpty(input)) {
                noSearchLL.visibility = View.VISIBLE
                searchResultLL.visibility = View.GONE
                refreshHistroy()
            }
        }
        noSearchLL.visibility = View.VISIBLE
        searchResultLL.visibility = View.GONE
        initHistory()
        initHot()
        initBrand()
        initModel()
        clearHistroyIV.setOnClickListener {
            SpfUtils.getInstance().saveData(SpfKey.SEARCH_HISTROY_CAR, null)
            refreshHistroy()
        }
    }

    fun initHistory() {
        histroyAdapter = LabelAdapter(this)
        histroyAdapter.itemClickListener = object : BrandListAdapter.ItemClickListener {
            override fun onItemClick(name: String) {
                onLabelClick(name)
            }
        }
        historyRecyclerView.adapter = histroyAdapter
        var layoutManager = FlowLayoutManager(this)
        historyRecyclerView.layoutManager = layoutManager
        refreshHistroy()
    }

    fun refreshHistroy() {
        var history = SpfUtils.getInstance().getStringList(SpfKey.SEARCH_HISTROY_CAR)
        histroyAdapter.refreshDatas(history)
    }

    fun initHot() {
        hotAdapter = LabelAdapter(this)
        hotAdapter.itemClickListener = object : BrandListAdapter.ItemClickListener {
            override fun onItemClick(name: String) {
                onLabelClick(name)
            }
        }
        hotRecyclerView.adapter = hotAdapter
        var layoutManager = FlowLayoutManager(this)
        hotRecyclerView.layoutManager = layoutManager
        var history = arrayOf("奥迪", "雷克萨斯", "本田", "奔驰")
        hotAdapter.refreshDatas(history.asList())
    }

    fun onLabelClick(label: String) {
        navigationView.searchView.text = label
        search(label)
    }

    fun initBrand() {
        searchBrandAdapter = SearchBrandAdapter(this, navigationView)
        brandRecyclerView.adapter = searchBrandAdapter
        brandRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    fun initModel() {
        searchModelAdapter = SearchModelAdapter(this, navigationView)
        modelRecyclerView.adapter = searchModelAdapter
        modelRecyclerView.layoutManager = LinearLayoutManager(this)
    }

    fun search(keyWord: String) {
        Client.getService().carSearch(keyWord)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<CarSearchBean>>() {
                    override fun onSuccess(result: Result<CarSearchBean>) {
                        SpfUtils.getInstance().addStringListItem(SpfKey.SEARCH_HISTROY_CAR, keyWord)
                        onSearchResult(result.data!!)
                    }
                })
    }

    fun onSearchResult(searchBean: CarSearchBean) {
        var brands = searchBean.carBrands
        var models = searchBean.carModels
        if ((brands != null && brands.size > 0)
                || (models != null && models.size > 0)) {
            noSearchLL.visibility = View.GONE
            searchResultLL.visibility = View.VISIBLE

            if (brands != null && brands.size > 0) {
                brandLL.visibility = View.VISIBLE
                searchBrandAdapter.refreshDatas(brands)
            } else {
                brandLL.visibility = View.GONE
            }
            if (models != null && models.size > 0) {
                modelLL.visibility = View.VISIBLE
                searchModelAdapter.refreshDatas(models)
            } else {
                modelLL.visibility = View.GONE
            }
        } else {
            ToastUtil.show("没有搜到任何结果")
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_EVALUATE)))
    fun onCarChoose(evaluateCar: EvaluateCar) {
        LogUtil.d(EventKey.TAG, "onCarChoose " + evaluateCar)
        finish()
    }

}
