package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.weidai.wpai.R
import com.weidai.wpai.extensions.displayRoundAssets
import com.weidai.wpai.extensions.findViewOften

/**
 * author zaaach on 2016/1/26.
 */
class HotGridAdapter(val mContext: Context, val datas: List<String>) : BaseAdapter() {

    override fun getCount(): Int {
        return datas?.size
    }

    override fun getItem(position: Int): String? {
        return if (datas == null) null else datas[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view: View
        if (convertView == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.car_view_brand_item_hot, parent, false)
        } else {
            view = convertView
        }
        var textView: TextView = view.findViewOften(R.id.textView)
        var imageView: ImageView = view.findViewOften(R.id.imageView)
        textView.text = datas[position]
        imageView.displayRoundAssets(datas[position], R.mipmap.ic_car_logo)
        return view
    }
}
