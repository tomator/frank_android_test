package com.weidai.wpai.component.appLink;

import android.app.Activity;
import android.support.annotation.NonNull;

import com.weidai.wpai.util.ToastUtil;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by bici on 16/11/21.
 */

public class AppLink {
    public static String APP_LINK_HEAD = "native://";

    private static AppLink instatnce = new AppLink();

    private Map<Route, LinkCallBack> routeMap = new HashMap<>();

    private AppLink() {
    }

    public static AppLink getInstance() {
        return instatnce;
    }

    public void register(@NonNull String route, @NonNull LinkCallBack callBack) {
        routeMap.put(new Route(route), callBack);
    }

    public void startLink(String url, Activity activity) {
        if (isAppLink(url)) {
            Route route = match(url);
            if (route == null) {
                ToastUtil.show("没有可以跳转的页面！");
            } else {
                LinkCallBack callBack = routeMap.get(route);
                if (callBack != null) {
                    callBack.onLink(activity, new Link(url, route));
                }
            }
        }
    }

    public Route match(String url) {
        Iterator<Route> iterator = routeMap.keySet().iterator();
        while (iterator.hasNext()) {
            Route route = iterator.next();
            if (route.match(url)) {
                return route;
            }
        }
        return null;
    }

    public boolean isAppLink(String url) {
        if (url != null && url.startsWith(APP_LINK_HEAD)) {
            return true;
        }
        return false;
    }
}
