package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.support.annotation.IdRes
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.R
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.HostConfig
import com.weidai.wpai.util.ChannelUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.activity_app_info.*

class AppInfoActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_info)
        if (BuildConfig.DEBUG) {
            showInfo()
        } else {
            hideInfo()
        }
        commitBtn.setOnClickListener { v -> showConfirmDialog(v.id) }
        clearBtn.setOnClickListener { v -> showConfirmDialog(v.id) }
    }

    private fun hideInfo() {
        infoContentLL.visibility = View.GONE
        commitBtn.visibility = View.GONE
        clearBtn.visibility = View.GONE
        passwordET.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable) {
                if (INFO_PASSWORD == s.toString()) {
                    showInfo()
                }
            }
        })
    }

    private fun showInfo() {
        passwordET.visibility = View.GONE
        infoContentLL.visibility = View.VISIBLE
        versionNameTV.text = BuildConfig.VERSION_NAME
        versionCodeTV.text = BuildConfig.VERSION_CODE.toString() + ""
        packageNameTV.text = BuildConfig.APPLICATION_ID
        debugTV.text = BuildConfig.DEBUG.toString() + ""
        if (BuildConfig.DEBUG) {
            serverApiTV.setText(HostConfig.API_HOST)
            serverImageTV.setText(HostConfig.STATIC_HOST)
        } else {
            serverApiTV.visibility = View.GONE
            serverImageTV.visibility = View.GONE
        }
        channelTV.text = ChannelUtil.getChannel(this)
    }

    private fun showConfirmDialog(@IdRes resId: Int) {
        AlertDialog.Builder(this)
                .setTitle("此操作将会清除用户数据，确定要继续吗？")
                .setPositiveButton("确认设置") { dialog, which -> setConfig(resId) }
                .setNegativeButton("取消") { dialog, which -> }
                .show()
    }

    private fun setConfig(@IdRes resId: Int) {
        when (resId) {
            R.id.commitBtn -> {
                val apiHost = serverApiTV.text.toString()
                val webHost = serverImageTV.text.toString()
                SpfUtils.getInstance().saveData(SpfKey.API_HOST, apiHost)
                SpfUtils.getInstance().saveData(SpfKey.STATIC_HOST, webHost)
            }
            R.id.clearBtn -> {
                SpfUtils.getInstance().saveData(SpfKey.API_HOST, null)
                SpfUtils.getInstance().saveData(SpfKey.STATIC_HOST, null)
            }
        }
        HostConfig.init()
        UserManager.instance.cleanUserInfo()
        Client.init()
        showInfo()
    }

    companion object {
        val INFO_PASSWORD = "weipai2017"
    }
}
