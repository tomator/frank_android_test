package com.weidai.wpai.ui.activity

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.bean.BalanceBean
import com.weidai.wpai.http.bean.BankCardBean
import com.weidai.wpai.ui.dialog.PayPwdDialog
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.activity_recharge.*
import kotlinx.android.synthetic.main.view_recharge_no_bind_card.*
import kotlinx.android.synthetic.main.view_recharge_with_card.*

/**
 * 充值提现
 */
class RechargeActivity : BaseActivity() {

    lateinit var helper: RechargeHelper
    lateinit var bankCard: BankCardBean
    internal var type = TYPE_RECHARGE
    lateinit var balance: BalanceBean

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recharge)
        helper = RechargeHelper(this)
        type = intent.getIntExtra("type", TYPE_RECHARGE)
        if (type == TYPE_RECHARGE) {
            navigationView.setTitle("充值")
            navigationView.setNextText("限额说明",
                    View.OnClickListener {
                        WPWebActivty.openStaticPage(this@RechargeActivity,
                                StaticPage.deal_recharge)
                    })
        } else {
            navigationView.setTitle("提现")
            navigationView.setNextText("提现说明", View.OnClickListener {
                WPWebActivty.openStaticPage(this@RechargeActivity,
                        StaticPage.deal_deposit)
            })
        }
        refreshBankView(null)
        helper.requestBindCard()
        helper.requestBalance()
        onViewClicked()
    }

    internal fun refreshBankView(bankCardBean: BankCardBean?) {
        if (UserManager.instance.hasBindCard()) {
            noBindCardView.visibility = View.GONE
            hasBindCardView.visibility = View.VISIBLE
        } else {
            noBindCardView.visibility = View.VISIBLE
            hasBindCardView.visibility = View.GONE
        }
        if (bankCardBean != null) {
            this.bankCard = bankCardBean
            ImageLoader.instance.display(bankCard.logo, bankLogoIV)
            bankNameTV.text = bankCard.bankName
            if (TextUtils.isEmpty(bankCard.cardType)) {
                cardTypeTV.text = ""
            } else {
                cardTypeTV.text = bankCard.cardType
            }
            val cardNo = bankCard.bankAccountNo
            tailNumberTV.text = cardNo.substring(cardNo.length - 4, cardNo.length)
            if (type == TYPE_RECHARGE) {
                var builder = StringBuilder()
                if (bankCard.perTxnMaxAmt == 0.0) {
                    builder.append("单笔无限额")
                } else {
                    builder.append("单笔限额${bankCard.perTxnMaxAmt}万元")
                }
                if (bankCard.perDayMaxAmt == 0.0) {
                    builder.append(",单日无限额")
                } else {
                    builder.append(",单日限额${bankCard.perDayMaxAmt}万元")
                }
                limitInfoTV.text = builder.toString()
                protocolTV.visibility = View.VISIBLE
            } else {
                limitInfoTV.text = "每个账户每天限提现一次，提现不收取手续费"
                protocolTV.visibility = View.GONE
            }
            val startColor = Color.parseColor("#" + bankCard.startColor)
            val endColor = Color.parseColor("#" + bankCard.endColor)
            val colors = intArrayOf(startColor, endColor)
            val bg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors)
            bg.cornerRadius = DensityUtil.dip2px(6f).toFloat()
            bankCardLL.background = bg
        }
    }

    internal fun refreshBalanceView(balanceBean: BalanceBean) {
        this.balance = balanceBean
        val availabeAmount = FormatUtil.getFormateMoney(balance.availabeAmount)
        accountUseableTV.text = getString(R.string.useable_balance, availabeAmount)
    }

    private fun nextRecharge() {
        val money = FormatUtil.getDoubleMoney(rechargeAET.text.toString())
        val limit = balance.rechargefee.toDouble()
        if (money <= 0) {
            return
        }
        if (money < limit) {
            ToastUtil.show("限额" + limit + "起充")
            return
        }
        if (money > bankCard.perTxnMaxAmt * 10000) {
            ToastUtil.show("充值金额太大")
            return
        }
        helper.showPayPwdDialog(money)
    }

    private fun nextWithdraw() {
        val money = FormatUtil.getDoubleMoney(rechargeAET.text.toString())
        if (money <= 0) {
            return
        }
        if (money > balance.availabeAmount) {
            ToastUtil.show("可用余额不足")
            return
        }
        if (!UserManager.instance.hasPayPwd()) {
            UserManager.instance.toSetPayPwd(this)
            return
        }
        helper.showPayPwdDialog(money)
    }

    private fun checkPayPwd(): Boolean {
        if (!UserManager.instance.hasPayPwd()) {
            UserManager.instance.toSetPayPwd(this)
            ToastUtil.show("请先设置支付密码")
        }
        return UserManager.instance.hasPayPwd()
    }

    fun onViewClicked() {
        nextStepTV.setOnClickListener {
            if (balance == null) {
                ToastUtil.show("获取账户余额失败，请稍后再试")
                helper.requestBalance()
                return@setOnClickListener
            }
            if (bankCard == null) {
                ToastUtil.show("获取银行卡信息失败，请稍后再试")
                helper.requestBindCard()
                return@setOnClickListener
            }
            if (!checkPayPwd()) {
                return@setOnClickListener
            }
            if (type == TYPE_RECHARGE) {
                nextRecharge()
            } else {
                nextWithdraw()
            }
        }
        protocolTV.setOnClickListener { WPWebActivty.openStaticPage(this@RechargeActivity, StaticPage.deal_recharge) }
        noBindCardLL.setOnClickListener { startActivity(Intent(this, BindCardActivity::class.java)) }
        addBankCardTV.setOnClickListener { startActivity(Intent(this, BindCardActivity::class.java)) }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_BIND_CARD_SUCCESS)))
    fun onBindCard(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onBindCard " + success)
        helper.requestBindCard()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_LOGIN_SUCCESS)))
    fun onLoginResult(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onLoginResult " + success)
        helper.requestBindCard()
        helper.requestBalance()
    }

    companion object {
        val TYPE_RECHARGE = PayPwdDialog.TYPE_RECHARE
        val TYPE_WITHDRAW = PayPwdDialog.TYPE_WITHDRAW
    }
}
