package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.weidai.wpai.R
import com.weidai.wpai.extensions.findViewOften

/**
 * author zaaach on 2016/1/26.
 */
class StyleGridAdapter(val mContext: Context, val datas: List<String>) : BaseAdapter() {
    var viewList: MutableList<View> = ArrayList()
    var onItemSelectListener: OnItemSelectListener? = null
    var selected: String? = null

    override fun getCount(): Int {
        return datas?.size
    }

    override fun getItem(position: Int): String? {
        return if (datas == null) null else datas[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view: View
        if (convertView == null) {
            view = LayoutInflater.from(mContext).inflate(R.layout.car_view_style_item_grid, parent, false)
        } else {
            view = convertView
        }
        var textView: TextView = view.findViewOften(R.id.textView)
        if (!viewList.contains(textView)) {
            viewList.add(textView)
        }
        textView.text = datas[position]
        textView.setOnClickListener {
            if (!textView.isSelected) {
                viewList.forEach {
                    it.isSelected = false
                }
                textView.isSelected = true
                selected = datas[position]
                onItemSelectListener.let {
                    onItemSelectListener!!.onItemSelcet(datas[position])
                }

            }
        }
        return view
    }

    interface OnItemSelectListener {
        fun onItemSelcet(name: String)
    }
}
