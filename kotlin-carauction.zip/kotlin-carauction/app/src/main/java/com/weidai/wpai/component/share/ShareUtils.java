package com.weidai.wpai.component.share;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.tencent.mm.opensdk.modelmsg.SendMessageToWX;
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage;
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;
import com.weidai.wpai.BuildConfig;
import com.weidai.wpai.R;
import com.weidai.wpai.util.LogUtil;
import com.weidai.wpai.util.ToastUtil;

public class ShareUtils {
    private static final String TAG = "ShareUtils";

    public static void shareToWeChat(Context context, ShareBean shareBean) {
        LogUtil.d(TAG, "shareToWeChat : " + shareBean);
        PackageManager pm = context.getPackageManager();
        //判断是否安装了微信，无安装提醒安装微信
        try {
            pm.getPackageInfo("com.tencent.mm", 0);
        } catch (PackageManager.NameNotFoundException e) {
            ToastUtil.show(R.string.share_not_install_weixin);
            return;
        }
        IWXAPI iwxapi = WXAPIFactory.createWXAPI(context, BuildConfig.WECHAT_APPID, true);
        WXWebpageObject webpage = new WXWebpageObject();
        webpage.webpageUrl = shareBean.getShareUrl();
        WXMediaMessage msg = new WXMediaMessage(webpage);
        msg.title = shareBean.getTitle();
        msg.description = shareBean.getDescription();
        Bitmap bmp = BitmapFactory.decodeResource(context.getResources(), shareBean.getImgRes());
        msg.thumbData = Util.bmpToByteArray(bmp, false);

        SendMessageToWX.Req req = new SendMessageToWX.Req();
        req.transaction = buildTransaction("webpage");
        req.message = msg;
        if (shareBean.getType() == ShareBean.Companion.getTYPE_WECHAT()) {
            req.scene = SendMessageToWX.Req.WXSceneSession;
        }
        if (shareBean.getType() == ShareBean.Companion.getTYPE_WECHAT_GROUP()) {
            req.scene = SendMessageToWX.Req.WXSceneTimeline;
        }
        iwxapi.sendReq(req);
    }

    private static String buildTransaction(String type) {
        return (type == null) ? String.valueOf(System.currentTimeMillis()) : type + System.currentTimeMillis();
    }
}
