package com.weidai.wpai.component.appUpdate

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.View
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.dialog_app_upgrade.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/3
 */
class UpgradeDialog(context: Context, content: String) : Dialog(context, R.style.Dialog_Fullscreen) {

    init {
        val window = window
        window!!.attributes.windowAnimations = R.style.DialogAnimFadeIn
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = ActionBar.LayoutParams.MATCH_PARENT
        params.gravity = Gravity.CENTER
        window.attributes = params
        window.setBackgroundDrawableResource(R.color.transparent)
        setContentView(R.layout.dialog_app_upgrade)
        setCanceledOnTouchOutside(false)
        contentTV.text = content
        closeIV.setOnClickListener { cancel() }
    }

    fun setCloseable(closeable: Boolean) {
        if (closeable) {
            closeIV.visibility = View.VISIBLE
        } else {
            closeIV.visibility = View.GONE
        }
    }

    fun setOnCommitListener(onCommitListener: View.OnClickListener) {
        upgradeBtn.setOnClickListener { v ->
            upgradeBtn.visibility = View.GONE
            progressBar.visibility = View.VISIBLE
            onCommitListener.onClick(v)
        }
    }

    fun setOnCloseListener(onCloseListener: View.OnClickListener) {
        closeIV.setOnClickListener { v ->
            cancel()
            onCloseListener.onClick(v)
        }
    }

    fun setProgress(progress: Int) {
        progressBar.progress = progress
    }

    override fun onBackPressed() {

    }
}
