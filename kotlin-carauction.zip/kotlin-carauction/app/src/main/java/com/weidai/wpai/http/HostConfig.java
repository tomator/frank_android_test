package com.weidai.wpai.http;

import android.text.TextUtils;

import com.weidai.wpai.BuildConfig;
import com.weidai.wpai.util.preferences.SpfKey;
import com.weidai.wpai.util.preferences.SpfUtils;

/**
 * Created by bici on 16/6/4.
 */
public class HostConfig {

    public static String API_HOST;
    public static String STATIC_HOST;

    static {
        init();
    }

    public static void init() {
        initApiHost();
        initWebHost();
    }

    public static void initApiHost() {
        if (BuildConfig.DEBUG) {
            String configApiHost = SpfUtils.getInstance().getString(SpfKey.API_HOST, null);
            if (TextUtils.isEmpty(configApiHost)) {
                API_HOST = BuildConfig.API_SERVER_URL;
            } else {
                API_HOST = configApiHost;
            }
        } else {
            API_HOST = BuildConfig.API_SERVER_URL;
        }
    }

    public static void initWebHost() {
        if (BuildConfig.DEBUG) {
            String configWebHost = SpfUtils.getInstance().getString(SpfKey.STATIC_HOST, null);
            if (TextUtils.isEmpty(configWebHost)) {
                STATIC_HOST = BuildConfig.API_SERVER_HTML_URL;
            } else {
                STATIC_HOST = configWebHost;
            }
        } else {
            STATIC_HOST = BuildConfig.API_SERVER_HTML_URL;
        }
    }
}
