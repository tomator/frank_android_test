package com.weidai.wpai.ui.view.ptr;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;

import com.weidai.wpai.R;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/20
 */
public class DefaultFooter extends FrameLayout {

    public DefaultFooter(Context context) {
        this(context, null);
    }

    public DefaultFooter(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_ptr_default_footer, this);
    }
}
