package com.weidai.wpai.component.appLink;

import android.app.Activity;

/**
 * Created by bici on 16/11/21.
 */

public interface LinkCallBack {

    public void onLink(Activity activity, Link link);
}
