package com.weidai.wpai.http;

/**
 * User: LiYajun
 * Date: 2016-09-27
 * Describe:
 */

public class MsgException extends Exception {
    private String msg;

    public MsgException(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
