package com.weidai.wpai.ui.evaluate.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.BrandBean
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.evaluate.adapter.BrandListAdapter
import com.weidai.wpai.ui.evaluate.dialog.CarModelDialog
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.activity_car_brand.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class CarBrandActivity : BaseActivity() {

    lateinit var adapter: BrandListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_brand)
        navigationView.setTitle("车辆型号")
        navigationView.setNextRes(R.mipmap.ic_nav_search)
        navigationView.setOnNextClickListener(View.OnClickListener {
            startActivity(Intent(this, CarSearchActivity::class.java))
        })
        adapter = BrandListAdapter(this)
        listView.adapter = adapter
        sideLetterBar.setOverlay(overlayTV)
        sideLetterBar.setOnLetterChangedListener { letter ->
            val position = adapter.getLetterPosition(letter)
            listView.setSelection(position)
        }
        adapter.setItemClickListener(object : BrandListAdapter.ItemClickListener {
            override fun onItemClick(name: String) {
                var top = top_line.bottom + StatusBarCompat.getStatusBarHeight(this@CarBrandActivity)
                CarModelDialog(this@CarBrandActivity, top, name).show()
            }
        })
        requestDatas()
    }

    fun requestDatas() {
        Client.getService().carBrandList()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<List<BrandBean>>>() {
                    override fun onSuccess(result: Result<List<BrandBean>>) {
                        if (result.data != null) {
                            refreshView(result.data!!)
                        }
                    }
                })
    }

    fun refreshView(datas: List<BrandBean>) {
        var hotDatas = resources.getStringArray(R.array.hotBrand).asList()
        var nameList = ArrayList<String>()
        datas.forEach {
            nameList.add(it.brand_name)
        }
        adapter.refreshDatas(nameList, hotDatas)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_EVALUATE)))
    fun onCarChoose(evaluateCar: EvaluateCar) {
        LogUtil.d(EventKey.TAG, "onCarChoose " + evaluateCar)
        finish()
    }

}
