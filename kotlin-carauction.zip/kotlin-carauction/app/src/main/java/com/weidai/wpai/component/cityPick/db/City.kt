package com.weidai.wpai.component.cityPick.db

class City : Cloneable {

    var id = ID_NULL
    var name: String? = null
    var pinyin: String? = null
    var parentId: String? = null
    var parentName: String? = null
    var level: Int = 0
    var type: Int = 0
    var py: String? = null

    constructor()

    constructor(name: String?, id: String) {
        this.id = id
        this.name = name
    }

    override fun toString(): String {
        return "city: _id = $id , name = $name , parentName = $parentName " +
                ", pinyin = $pinyin , parentId = $parentId  " +
                ", type = $type , level = $level "
    }

    @Throws(CloneNotSupportedException::class)
    public override fun clone(): City {
        return super.clone() as City
    }

    override fun equals(obj: Any?): Boolean {
        if (obj is City) {
            return obj.hashCode() == hashCode()
        }
        return false
    }

    override fun hashCode(): Int {
        return (id + name!!).hashCode()
    }

    companion object {
        val TABLE_NAME = "City"
        val ID = "_id"
        val NAME = "name"
        val PINYIN = "pinyin"
        val PARENT_ID = "parent_id"
        val PARENT_NAME = "parent_name"
        val LEVEL = "level"
        val PY = "py"
        val CREATE_TABLE = " CREATE TABLE City( " +
                "  $ID TEXT NOT NULL, " +
                "  $NAME TEXT NOT NULL, " +
                "  $PINYIN TEXT NOT NULL, " +
                "  $PARENT_ID TEXT NOT NULL, " +
                "  $PARENT_NAME TEXT NOT NULL, " +
                "  $PY TEXT NOT NULL, " +
                "  $LEVEL Integer)"

        val ID_NULL = "-1"
        val LEVEL_COUNTRY = 0
        val LEVEL_PROVINCE = 1
        val LEVEL_CITY = 2

        val TYPE_PROVINCE = 1
        val TYPE_CITY = 2
        val TYPE_HOT = 5
        val TYPE_CITY_ALL = 6
        val TYPE_LOCATION = 10
    }
}
