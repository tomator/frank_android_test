package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.TransactionRecords
import com.weidai.wpai.util.DateUtil
import kotlinx.android.synthetic.main.car_view_item_sale_record.view.*

/**
 * author zaaach on 2016/1/26.
 */
class SaleRecordAdapter(val context: Context, val dataList: List<TransactionRecords>) : RecyclerView.Adapter<SaleRecordAdapter.ViewHolder>() {
    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = inflater.inflate(R.layout.car_view_item_sale_record, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            var data = dataList[position]
            itemView.modelDetailTV.text = data.typeName
            itemView.baseInfoTV.text = "${data.cityName}/${data.ppDate}上牌/${data.mileage}万公里"
            itemView.priceTV.text = "${data.tranCharge}万"
            itemView.saleTimeTV.text = "成交于\n${DateUtil.format(data.tranDate.toLong(), 15)}"
        }
    }
}
