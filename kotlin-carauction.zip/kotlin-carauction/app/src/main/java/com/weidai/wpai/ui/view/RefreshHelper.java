package com.weidai.wpai.ui.view;

import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * Created by bici on 16/6/15.
 */
public class RefreshHelper {

    public static void autoRefresh(final PtrFrameLayout refreshView) {
        refreshView.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshView.autoRefresh();
            }
        }, 200);
    }

    public static void autoRefresh(final PtrFrameLayout refreshView, int deley) {
        refreshView.postDelayed(new Runnable() {
            @Override
            public void run() {
                refreshView.autoRefresh();
            }
        }, deley);
    }
}
