package com.weidai.wpai.component.appLink;

import java.util.Map;

/**
 * Created by bici on 16/11/21.
 */

public class Link {
    private String url;
    private Route route;
    private Map<String, String> paramMap;

    public Link(String url, Route route) {
        this.url = url;
        this.route = route;
        paramMap = ParamUtil.toMap(url);
    }

    public String getRouteParam(String key) {
        return route.getParam(key);
    }

    public String getQueryParam(String key) {
        return paramMap.get(key);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Route getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        this.route = route;
    }

    public Map<String, String> getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map<String, String> paramMap) {
        this.paramMap = paramMap;
    }
}
