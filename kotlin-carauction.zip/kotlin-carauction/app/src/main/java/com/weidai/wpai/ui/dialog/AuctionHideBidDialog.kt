package com.weidai.wpai.ui.dialog

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import com.weidai.wpai.R
import com.weidai.wpai.ui.view.NumberInputView
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.dialog_auction_hide_bid.*


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/22
 */
class AuctionHideBidDialog(context: Context, val basePrice: Double, val lastPrice: Double)
    : Dialog(context, R.style.Dialog_Fullscreen) {

    private var onCommitLister: OnCommitLister? = null
    private var inputPrice = 0.0

    init {
        initWindow()
        initView()
    }

    private fun initWindow() {
        val window = window
        window.attributes.windowAnimations = R.style.DialogAnimFadeIn
        val windowHeight = window.windowManager.defaultDisplay.height
        val statusBarHeight = StatusBarCompat.getStatusBarHeight(context)
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - statusBarHeight
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_auction_hide_bid, null)
        setContentView(view)
    }

    private fun initView() {
        if (lastPrice > 0) {
            titleTV.text = "更改报价"
            tipsTV.text = "上一次报价:"
            priceTV.text = FormatUtil.getFormateMoney(lastPrice)
        } else {
            titleTV.text = "暗拍报价"
            tipsTV.text = "起拍价:"
            priceTV.text = FormatUtil.getFormateMoney(basePrice)
        }
        inputPriceET.inputType = InputType.TYPE_NULL
        numberInputView.addInputListener(object : NumberInputView.OnInputListener {
            override fun onInput(input: String, last: String) {
                inputPriceET.setText(input)
                numberInputView.initValue(inputPriceET.text.toString())
                checkEnable(input)
            }
        })
        commitTV.setOnClickListener {
            if (commitTV.isSelected && onCommitLister != null) {
                onCommitLister!!.onCommit(inputPrice)
            }
        }
        backTV.setOnClickListener { cancel() }
        shadowView.setOnClickListener { cancel() }
    }

    private fun checkEnable(input: String) {
        try {
            inputPrice = java.lang.Double.parseDouble(input)
        } catch (e: Exception) {
            inputPrice = 0.0
            e.printStackTrace()
        }
        commitTV.isSelected = inputPrice > 0 && inputPrice > basePrice
    }

    fun setOnCommitLister(onCommitLister: OnCommitLister) {
        this.onCommitLister = onCommitLister
    }

    interface OnCommitLister {
        fun onCommit(price: Double)
    }

}
