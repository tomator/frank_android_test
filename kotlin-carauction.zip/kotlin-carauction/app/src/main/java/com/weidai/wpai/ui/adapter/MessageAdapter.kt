package com.weidai.wpai.ui.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.MessageBean
import com.weidai.wpai.util.DateUtil
import kotlinx.android.synthetic.main.view_message_item.view.*
import java.util.*

class MessageAdapter(val context: Context, val type: Int) : RecyclerView.Adapter<MessageAdapter.ViewHolder>() {
    private val dataList = ArrayList<MessageBean>()

    fun refreshDatas(datas: List<MessageBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<MessageBean>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_message_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(data: MessageBean) {
            itemView.dateTV.text = DateUtil.format(data.publish, 10)
            itemView.titleTV.text = data.title
            itemView.contentTV.text = data.content
        }
    }
}
