package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.weidai.wpai.App
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.activity_recharge_result.*

class RechargeResultActivity : BaseActivity() {

    private var type: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recharge_result)
        navigationView.setTitle("充值")
        type = intent.getIntExtra("type", TYPE_FAILED)
        when (type) {
            TYPE_FAILED -> {
                resultIV.setImageResource(R.mipmap.ic_result_failed)
                resultTV.text = "充值失败"
                descriptionTV.text = "您的充值未成功，请稍后重试。"
                contactTV.visibility = View.VISIBLE
            }
            TYPE_SUCCESS -> {
                resultIV.setImageResource(R.mipmap.ic_result_success)
                resultTV.text = "充值成功"
                descriptionTV.text = "您的充值已成功到账。"
                contactTV.visibility = View.GONE
            }
            TYPE_SUCCESS_WAIT -> {
                resultIV.setImageResource(R.mipmap.ic_result_wait)
                resultTV.text = "充值处理中…"
                descriptionTV.text = "预计30分钟内到账，敬请留意。"
                contactTV.visibility = View.GONE
            }
        }
        returnBtn.setOnClickListener { finish() }
        gotoAuctionBtn.setOnClickListener {
            App.instance.resetActivity()
            val mainActivity = App.instance.mainActivity
            mainActivity?.setCurrentItem(1)
        }
    }

    companion object {
        val TYPE_FAILED = 1
        val TYPE_SUCCESS = 2
        val TYPE_SUCCESS_WAIT = 3

        fun gotoThis(context: Context, type: Int) {
            val intent = Intent(context, RechargeResultActivity::class.java)
            intent.putExtra("type", type)
            context.startActivity(intent)
        }
    }
}
