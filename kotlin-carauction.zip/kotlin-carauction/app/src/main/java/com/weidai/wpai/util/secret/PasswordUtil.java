package com.weidai.wpai.util.secret;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class PasswordUtil {
    private static final String table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    public static String encode(String password) {
        String result = Base64Util.encode(password);
        result = getRamdom(result);
        return result;
    }

    public static String getRamdom(String password) {
        String pw = getRandomString(10) + password + getRandomString(10);
        return pw;
    }

    public static String getRandomString(int count) {
        String result = "";
        for (int i = 0; i < count; i++) {
            int index = (int) (Math.random() * table.length());
            result += table.charAt(index);
        }
        return result;
    }
}
