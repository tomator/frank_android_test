package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.activity_bind_card_result.*

class BindCardResultActivity : BaseActivity() {

    private var type: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bind_card_result)
        navigationView.setTitle("绑定银行卡")
        type = intent.getIntExtra("type", TYPE_FAILED)
        when (type) {
            TYPE_FAILED -> {
                resultIV.setImageResource(R.mipmap.ic_result_failed)
                resultTV.text = "绑卡未成功"
                descriptionTV.text = "请检查您的信息是否填写正确，或换一张绑定。"
                returnBtn.text = "重新绑定"
                contactTV.visibility = View.VISIBLE
            }
            TYPE_SUCCESS -> {
                resultIV.setImageResource(R.mipmap.ic_result_success)
                resultTV.text = "绑卡成功"
                descriptionTV.text = "您的银行卡已绑定成功。"
                returnBtn.text = "去充值"
                contactTV.visibility = View.GONE
            }
        }
        returnBtn.setOnClickListener {
            finish()
            if (type == TYPE_FAILED) {
                startActivity(Intent(this, BindCardActivity::class.java))
            } else {
                startActivity(Intent(this, RechargeActivity::class.java))
            }
        }
    }

    companion object {

        val TYPE_FAILED = 1
        val TYPE_SUCCESS = 2

        fun gotoThis(context: Context, type: Int) {
            val intent = Intent(context, BindCardResultActivity::class.java)
            intent.putExtra("type", type)
            context.startActivity(intent)
        }
    }
}
