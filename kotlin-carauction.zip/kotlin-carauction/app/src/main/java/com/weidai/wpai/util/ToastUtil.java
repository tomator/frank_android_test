package com.weidai.wpai.util;

import android.support.annotation.StringRes;
import android.text.TextUtils;
import android.widget.Toast;

import com.weidai.wpai.App;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/7
 */
public class ToastUtil {
    private static Toast toast;

    public static void show(String msg) {
        if (TextUtils.isEmpty(msg)) {
            return;
        }
        if (toast != null) {
            toast.cancel();
        }
        toast = Toast.makeText(App.Companion.getInstance(), msg, Toast.LENGTH_SHORT);
        toast.show();
    }

    public static void show(@StringRes int msg) {
        show(App.Companion.getInstance().getString(msg));
    }

}
