package com.weidai.wpai.common;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/29
 */
public interface StaticPage {
    /**
     * http://wpai.weidai.com.cn/ (prod)
     * http://wpai.wdai.com/ (uat)
     */

    public static final String deal_deposit = "deal.deposit.html"; // `提现说明`
    public static final String deal_recharge = "deal.recharge.html"; // `充值说明`
    public static final String deal_register = "deal.register.html"; // `用户注册协议`
    public static final String deal_bank = "deal.bank.html"; // `银行卡信息页`
    public static final String deal_mustKnow = "deal.mustKnow.html"; // `竞拍须知`
    public static final String deal_about = "deal.about.html"; // `关于微车拍`
    public static final String deal_protect = "deal.protect.html"; // `维保协议`

}
