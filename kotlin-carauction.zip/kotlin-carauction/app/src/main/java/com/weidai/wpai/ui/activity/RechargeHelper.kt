package com.weidai.wpai.ui.activity

import android.content.Intent
import android.text.TextUtils
import com.hwangjr.rxbus.RxBus
import com.jungly.gridpasswordview.GridPasswordView
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.BalanceBean
import com.weidai.wpai.http.bean.BankCardBean
import com.weidai.wpai.http.bean.RechargeBean
import com.weidai.wpai.http.param.PayOperateVQO
import com.weidai.wpai.ui.dialog.PayPwdDialog
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.secret.PasswordUtil

import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/27
 */
class RechargeHelper(internal var activity: RechargeActivity) {

    internal fun requestBindCard() {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        UserManager.instance.reqeustBindCardInfo(
                true, object : SimpleSubscriber<Result<BankCardBean>>(progressDialog) {
            override fun onSuccess(result: Result<BankCardBean>) {
                super.onSuccess(result)
                UserManager.instance.saveBindCrad(result.data!!.bankAccountNo)
                activity.refreshBankView(result.data)
            }
        })
    }

    internal fun requestBalance() {
        Client.getService().balance
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<BalanceBean>>() {
                    override fun onSuccess(result: Result<BalanceBean>) {
                        super.onSuccess(result)
                        activity.refreshBalanceView(result.data!!)
                    }
                })
    }

    internal fun showPayPwdDialog(money: Double) {
        val payPwdDialog = PayPwdDialog(activity, money, activity.type)
        payPwdDialog.show()
        payPwdDialog.setOnPasswordChangedListener(object : GridPasswordView.OnPasswordChangedListener {
            override fun onTextChanged(psw: String) {

            }

            override fun onInputFinish(psw: String) {
                payPwdDialog.cancel()
                if (activity.type === RechargeActivity.TYPE_RECHARGE) {
                    recharge(psw, money)
                } else {
                    withdraw(psw, money)
                }
            }
        })
    }

    internal fun recharge(pwd: String, rechargeMoney: Double) {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        Client.getService().recharge(PayOperateVQO(rechargeMoney.toString(),
                PasswordUtil.encode(pwd)))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<RechargeBean>>(progressDialog) {
                    override fun onSuccess(result: Result<RechargeBean>) {
                        super.onSuccess(result)
                        if (result.data != null && !TextUtils.isEmpty(result.data!!.outBillNo)) {
                            toAuthPhone(result.data!!)
                        } else {
                            ToastUtil.show(result.message)
                            RxBus.get().post(EventKey.KEY_RECHARGE_RESULT, true)
                            if (result.code == Result.CODE_RECHARGE_OR_WITHDRAW_WAIT) {
                                RechargeResultActivity.gotoThis(activity, RechargeResultActivity.TYPE_SUCCESS_WAIT)
                            } else {
                                RechargeResultActivity.gotoThis(activity, RechargeResultActivity.TYPE_SUCCESS)
                            }
                            activity.finish()
                        }
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        rechargeFialed()
                    }
                })
    }

    fun toAuthPhone(rechargeBean: RechargeBean) {
        activity.startActivity(Intent(activity, RechargePhoneAuthActivity::class.java)
                .putExtra("rechargeBean", rechargeBean))
    }

    internal fun rechargeFialed() {
        RxBus.get().post(EventKey.KEY_RECHARGE_RESULT, false)
        RechargeResultActivity.gotoThis(activity, RechargeResultActivity.TYPE_FAILED)
    }

    internal fun withdraw(pwd: String, rechargeMoney: Double) {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        Client.getService().withdraw(PayOperateVQO(rechargeMoney.toString(),
                PasswordUtil.encode(pwd)))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>(progressDialog) {
                    override fun onSuccess(result: Result<*>) {
                        super.onSuccess(result)
                        ToastUtil.show(result.message)
                        withdrawSuccess()
                    }
                })
    }

    internal fun withdrawSuccess() {
        RxBus.get().post(EventKey.KEY_WITHDRAW_RESULT, true)
        WithdrawResultActivity.gotoThis(activity, WithdrawResultActivity.TYPE_SUCCESS)
        activity.finish()
    }
}
