package com.weidai.wpai.ui.evaluate.dialog

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.adapter.SecondCityListAdapter
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.component.cityPick.db.DBManager
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.WindowUtil
import kotlinx.android.synthetic.main.cp_dialog_city_list2.*
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/10
 */
class CityChildDialog(context: Context, top: Int, val province: City) : Dialog(context, R.style.Dialog_Fullscreen) {
    private var mCityAdapter: SecondCityListAdapter? = null
    private var mAllCities: List<City> = ArrayList()
    private val dbManager = DBManager(getContext())

    init {
        window!!.attributes.windowAnimations = R.style.DialogAnimRightIn
        val view = LayoutInflater.from(context).inflate(R.layout.cp_dialog_city_list2, null)
        setContentView(view)
        var windowHeight = window!!.windowManager.defaultDisplay.height
        val realHeight = WindowUtil.getRealHeight(getContext())
        LogUtil.d("TOP_HEIGHT : realHeight = $realHeight, windowHeight = $windowHeight")
        windowHeight = if (realHeight > windowHeight) realHeight else windowHeight
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - top
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        not_limit_LL.visibility = View.GONE
        setCanceledOnTouchOutside(true)
        initData()
    }

    protected fun initData() {
        not_limit_LL.visibility = View.GONE
        letter_province.text = province.name
        mAllCities = dbManager.getCitys(province.id)
        mCityAdapter = SecondCityListAdapter(context, mAllCities)
        listview_all_city!!.adapter = mCityAdapter
        mCityAdapter!!.setOnCityClickListener { city ->
            RxBus.get().post(EventKey.KEY_CHOOSE_CITY, city)
            dismiss()
        }
        leftShadowView!!.setOnClickListener { dismiss() }
    }
}
