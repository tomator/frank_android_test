package com.weidai.wpai.ui.view

import android.app.Activity
import android.content.Context
import android.support.annotation.DrawableRes
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.RelativeLayout
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.view_navigation_tab.view.*

/**
 * Created by bici on 16/4/18.
 */
class NavigationTabView @JvmOverloads constructor(context: Context, attributeSet: AttributeSet? = null) : RelativeLayout(context, attributeSet) {

    init {
        LayoutInflater.from(context).inflate(R.layout.view_navigation_tab, this)
        backBtn.setOnClickListener {
            try {
                (context as Activity).onBackPressed()
            } catch (e: Exception) {
            }
        }
    }

    fun getTabView(): TabView {
        return tabView
    }

    fun setNextRes(@DrawableRes resId: Int) {
        nextBtn.visibility = View.VISIBLE
        nextBtn.setImageResource(resId)
    }

    fun setOnBackClickListener(onClickListener: View.OnClickListener) {
        backBtn.setOnClickListener(onClickListener)
    }

    fun setOnNextClickListener(onClickListener: View.OnClickListener) {
        nextBtn.setOnClickListener(onClickListener)
    }

    fun hideBack() {
        backBtn.visibility = View.GONE
    }
}
