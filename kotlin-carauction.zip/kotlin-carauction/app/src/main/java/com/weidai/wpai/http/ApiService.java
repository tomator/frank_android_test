package com.weidai.wpai.http;

import com.weidai.wpai.http.base.ListData;
import com.weidai.wpai.http.base.Result;
import com.weidai.wpai.http.bean.AddressBean;
import com.weidai.wpai.http.bean.AuctionBean;
import com.weidai.wpai.http.bean.BalanceBean;
import com.weidai.wpai.http.bean.BankCardBean;
import com.weidai.wpai.http.bean.BannerBean;
import com.weidai.wpai.http.bean.BrandBean;
import com.weidai.wpai.http.bean.CarInfoBean;
import com.weidai.wpai.http.bean.CarSearchBean;
import com.weidai.wpai.http.bean.ConstantBean;
import com.weidai.wpai.http.bean.Coupon;
import com.weidai.wpai.http.bean.EvaluateCar;
import com.weidai.wpai.http.bean.EvaluateResult;
import com.weidai.wpai.http.bean.FunLogBean;
import com.weidai.wpai.http.bean.HotCity;
import com.weidai.wpai.http.bean.InvitationInfoBean;
import com.weidai.wpai.http.bean.MaintenanceBean;
import com.weidai.wpai.http.bean.MessageBean;
import com.weidai.wpai.http.bean.NewRecordBean;
import com.weidai.wpai.http.bean.NoticeTipBean;
import com.weidai.wpai.http.bean.RechargeBean;
import com.weidai.wpai.http.bean.SimpleAuctionBean;
import com.weidai.wpai.http.bean.UserInfoBean;
import com.weidai.wpai.http.bean.VinResultBean;
import com.weidai.wpai.http.param.AuctionRecommendVQO;
import com.weidai.wpai.http.param.BankCardVQO;
import com.weidai.wpai.http.param.BaseSearchObject;
import com.weidai.wpai.http.param.BuildeOrderVQO;
import com.weidai.wpai.http.param.DateNoticeVQO;
import com.weidai.wpai.http.param.ForgetPayPwdVQO;
import com.weidai.wpai.http.param.LoginVQO;
import com.weidai.wpai.http.param.PayOperateVQO;
import com.weidai.wpai.http.param.PwdModfiyVQO;
import com.weidai.wpai.http.param.PwdResetVQO;
import com.weidai.wpai.http.param.RegisterVQO;
import com.weidai.wpai.http.param.SearchAuctionNewsVQO;
import com.weidai.wpai.http.param.SearchAuctionVQO;
import com.weidai.wpai.http.param.SearchCodeVQO;
import com.weidai.wpai.http.param.SearchTradeVQO;
import com.weidai.wpai.http.param.SendMsgVQO;
import com.weidai.wpai.http.param.SendVerifyCodeVQO;
import com.weidai.wpai.http.param.SetPayPwdVQO;
import com.weidai.wpai.http.param.SignUpVQO;
import com.weidai.wpai.http.param.UpfeeVQO;

import java.util.List;
import java.util.Map;

import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by bici on 16/12/8.
 */

public interface ApiService {

    /**
     * 获取首页banner
     */
    @GET("banner/list")
    Observable<Result<List<BannerBean>>> getBannerList(@Query("positionCode") String positionCode);

    /**
     * 推荐列表查询
     */
    @POST("auction/recommend")
    Observable<Result<ListData<SimpleAuctionBean>>> getRecommendList(@Body AuctionRecommendVQO auctionRecommendVQO);

    /**
     * 竞拍列表查询
     */
    @POST("auction/list")
    Observable<Result<ListData<SimpleAuctionBean>>> getAuctionList(@Body SearchAuctionVQO searchAuctionVQO);

    /**
     * 地市筛选
     */
    @POST("app/addr")
    Observable<Result<AddressBean>> getCityList();

    /**
     * 热门城市
     */
    @POST("app/hot/addr")
    Observable<Result<HotCity>> getHotCityList();

    /**
     * 发送手机验证码
     */
    @POST("valid/sendmobilecode")
    Observable<Result> sendAuthCode(@Body SendMsgVQO sendMsgVQO);

    /**
     * 发送手机验证码（充值时使用）
     */
    @POST("my/account/send/verify/code")
    Observable<Result> sendVerifyCode(@Body SendVerifyCodeVQO sendVerifyCodeVQO);

    /**
     * 发送手机验证码需要图片验证码
     */
    @POST("valid/sendcode")
    Observable<Result> sendAuthCodeWithImage(@Body SendMsgVQO sendMsgVQO);

    /**
     * 快速注册 无需图片验证码
     */
    @POST("user/fastregister")
    Observable<Result<Boolean>> fastRegister(@Body RegisterVQO registerVQO);

    /**
     * 忘记密码，该接口不需要传图片验证码
     */
    @POST("user/fastreset")
    Observable<Result<Boolean>> fastReset(@Body PwdResetVQO pwdResetVQO);

    /**
     * 登录
     */
    @POST("user/login")
    Observable<Result<Boolean>> login(@Body LoginVQO loginVQO);

    /**
     * 登录
     */
    @POST("user/loginout")
    Observable<Result<Boolean>> logout();

    /**
     * 获取用户信息
     */
    @POST("user/info")
    Observable<Result<UserInfoBean>> getUserInfo();

    /**
     * 我的钱包——余额查询
     */
    @POST("my/account/balance")
    Observable<Result<BalanceBean>> getBalance();

    /**
     * 我的钱包——获取默认银行卡,判断用户是否绑卡
     */
    @POST("my/account/card")
    Observable<Result<BankCardBean>> getBindCard();

    /**
     * 我的钱包——绑定银行卡
     */
    @POST("my/account/fastbindcard")
    Observable<Result<Boolean>> bindCard(@Body BankCardVQO bankCardVQO);

    /**
     * 我的钱包—设置支付密码
     */
    @POST("my/account/setpwd")
    Observable<Result<Boolean>> setPayPwd(@Body SetPayPwdVQO setPayPwdVQO);

    /**
     * 我的钱包——忘记支付密码
     */
    @POST("my/account/fastforgetpaypwd")
    Observable<Result<Boolean>> resetPayPwd(@Body ForgetPayPwdVQO forgetPayPwdVQO);

    /**
     * 修改密码
     */
    @POST("user/modify")
    Observable<Result> modifyPwd(@Body PwdModfiyVQO pwdModfiyVQO);

    /**
     * 我的钱包——充值
     */
    @POST("my/account/recharge/new")
    Observable<Result<RechargeBean>> recharge(@Body PayOperateVQO payOperateVQO);

    /**
     * 我的钱包——充值
     */
    @POST("my/account/draw")
    Observable<Result> withdraw(@Body PayOperateVQO payOperateVQO);

    /**
     * 判断是否是否符合保证金,参数 code = 保证金
     */
    @POST("my/account/info")
    Observable<Result<Boolean>> depositInfo(@Body SearchCodeVQO searchCodeVQO);

    /**
     * 拍卖品内容详情 app 调用
     */
    @POST("auction/base")
    Observable<Result<AuctionBean>> auctionBase(@Body SearchCodeVQO searchCodeVQO);

    /**
     * 拍卖品内容详情 app 调用
     */
    @POST("auction/carinfo")
    Observable<Result<CarInfoBean>> auctionCarInfo(@Body SearchCodeVQO searchCodeVQO);

    /**
     * 最新出价记录 number条快报
     */
    @POST("auction/news")
    Observable<Result<ListData<NewRecordBean>>> auctionRecords(@Body SearchAuctionNewsVQO searchAuctionNewsVQO);

    /**
     * 拍卖品监听
     */
    @GET("auction/watch")
    Observable<Result<AuctionBean>> auctionWatch(@Query("auctionNO") String auctionNO);

    /**
     * 在app,微信客户端，竞拍中心列表需要定时跟服务端更新状态，结束时间，最新价格等信息。
     * no  竞拍品code，支持传多个，用英文逗号隔开，最多支持20个
     */
    @GET("auction/watchlist")
    Observable<Result<List<AuctionBean>>> auctionWatchList(@Query("no") String auctionNOs);

    /**
     * 交保证金
     */
    @POST("my/trade/entry")
    Observable<Result<String>> auctionEntry(@Body SignUpVQO signUpVQO);

    /**
     * 出价
     */
    @POST("my/trade/upfee")
    Observable<Result> auctionUpfee(@Body UpfeeVQO upfeeVQO);

    /**
     * 我的竞拍单列表查询
     */
    @POST("my/trade/newlist")
    Observable<Result<ListData<SimpleAuctionBean>>> myAuctions(@Body SearchTradeVQO searchTradeVQO);

    /**
     * 我的钱包——交易明细
     */
    @POST("my/account/funlog")
    Observable<Result<ListData<FunLogBean>>> financeLog(@Body BaseSearchObject baseSearchObject);

    /**
     * 我的钱包——冻结明细
     */
    @POST("my/account/freezelog")
    Observable<Result<ListData<FunLogBean>>> freezeLog(@Body BaseSearchObject baseSearchObject);

    /**
     * app启动常量参数
     */
    @GET("app/constant")
    Observable<Result<ConstantBean>> getConstant();

    /**
     * 平台通知列表
     */
    @POST("notice/sys")
    Observable<Result<ListData<MessageBean>>> getMessageNotice(@Body BaseSearchObject baseSearchObject);

    /**
     * 系统提醒列表
     */
    @POST("notice/user")
    Observable<Result<ListData<MessageBean>>> getMessageUser(@Body BaseSearchObject baseSearchObject);

    /**
     * 是否有新消息
     */
    @POST("notice/hasnew")
    Observable<Result<NoticeTipBean>> hasNewMessage(@Body DateNoticeVQO dateNoticeVQO);

    /**
     * 查询免费剩余次数
     */
    @POST("carmaintenance/freecnt")
    Observable<Result<Integer>> freeTimes();

    /**
     * 验证vin码是否查询
     */
    @POST("carmaintenance/checkvin")
    Observable<Result<VinResultBean>> checkvin(@Body SearchCodeVQO searchCodeVQO);

    /**
     * 查询报告 code 传 orderId
     */
    @POST("carmaintenance/find")
    Observable<Result<String>> findCode(@Body SearchCodeVQO searchCodeVQO);

    /**
     * 生成查询订单
     */
    @POST("carmaintenance/order")
    Observable<Result> buildOrder(@Body BuildeOrderVQO buildeOrderVQO);

    /**
     * 我的查询订单
     */
    @POST("carmaintenance/list")
    Observable<Result<ListData<MaintenanceBean>>> maintenanceList(@Body BaseSearchObject baseSearchObject);

    /**
     * 获取邀请好友页面信息
     */
    @POST("invitation/page/info")
    Observable<Result<InvitationInfoBean>> invitationInfo();

    /**
     * 获取邀请好友链接
     */
    @POST("user/invitation/url")
    Observable<Result<String>> invitationUrl();

    /**
     * 获取所有的车辆品牌
     */
    @POST("car/brandList")
    Observable<Result<List<BrandBean>>> carBrandList();

    /**
     * 根据品牌查询车辆型号
     */
    @GET("car/modelList")
    Observable<Result<Map<String, List<String>>>> carModelList(@Query("brand") String brand);

    /**
     * 根据品牌和车型获取车辆款型
     */
    @GET("car/styleList")
    Observable<Result<List<EvaluateCar>>> carStyleList(@Query("brand") String brand, @Query("model") String model);

    /**
     * 根据vin码获取车辆信息
     */
    @GET("car/getByVin")
    Observable<Result<List<EvaluateCar>>> carGetByVin(@Query("vin") String vin);

    /**
     * 进行车辆估价
     */
    @POST("car/evaluate")
    Observable<Result<EvaluateResult>> carEvaluate(@Body EvaluateCar evaluateCar);

    /**
     * 车型搜索
     */
    @GET("search")
    Observable<Result<CarSearchBean>> carSearch(@Query("q") String keyWord);

    /**
     * 我的优惠券查询接口,根据状态查询
     */
    @POST("my/coupon/list")
    Observable<Result<ListData<Coupon>>> myCouponList(@Body SearchTradeVQO searchTradeVQO);

    /**
     * 竞拍优惠券选择接口（不同于维保查询的优惠券）
     */
    @GET("my/coupon/auctionCoupon")
    Observable<Result<List<List<Coupon>>>> auctionCoupon(@Query("auctionNo") String articleId);

    /**
     * 使用优惠券
     */
    @GET("my/coupon/useAuctionCoupon")
    Observable<Result> useAuctionCoupon(@Query("couponId") String couponId, @Query("auctionNo") String articleId);

    /**
     * 我的提醒列表查询
     */
    @POST("remind/list")
    Observable<Result<ListData<SimpleAuctionBean>>> remindList(@Body BaseSearchObject baseSearchObject);

    /**
     * 添加提醒
     */
    @FormUrlEncoded
    @POST("remind/add")
    Observable<Result> remindAdd(@Field("auctionNo") String auctionNo);

    /**
     * 取消提醒
     */
    @FormUrlEncoded
    @POST("remind/cancel")
    Observable<Result> remindCancel(@Field("auctionNo") String auctionNo);


    /**
     * 取消提醒
     */
    @POST("my/account/quick/pay")
    Observable<Result> quickPay(@Field("auctionNo") String auctionNo);

}
