package com.weidai.wpai.http.bean

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/14
 */

/**
 * increment	number	N	竞拍幅度
 * tradeStatus	number	N	如果用户已经登录，显示交易状态，否则0，交易状态 -1 表示用户未登录
 * 0未报名 10 已报名 21 竞拍中 31 已成交未付款 32 已成交已付款
 * 33 已结束未退保证金 34 已结束已退保证金 35 已结束退保证金中
 * remainingStartTime	number	N	距离开始 ，单位秒
 * status	number	N	竞拍状态，1竞拍中、2即将开始、3结束
 * deposit	number	N	保证金
 * endTime	string	N	竞拍结束时间,格式 yyyy-MM-dd HH:mm:ss
 * startPrice	number	N	竞拍起拍价
 * startTime	string	N	竞拍开始时间,格式 yyyy-MM-dd HH:mm:ss
 * picPath	string[]	N	竞拍图列
 * auctionCarDetailVO	AuctionCarDetailVO	N	车信息
 * orderNO	string	N	交易状态 >0 存在正常 orderNo
 * title	string	N	竞拍title
 * delaytime	number	N	延迟周期,单位分
 * remainingEndTime	number	N	剩余时间 ，单位秒
 * instruction	string[]	N	拍卖说明
 * auctionNo	string	N	竞拍auctionNo
 * newsRecord	AuctionNewsVO[]	N	最新快报
 * curPrice	number	N	竞拍当前价

 * 三期新增字段
 * auctionDuration	number	Y	竞拍周期，单位分
 * hasLimitPrice	boolean	Y	有无保留价 true：有 false：无
 * auctionMode	number	Y	竞拍类型 0：升价拍 1：暗拍
 * fixedPrice	number	Y	一口价
 * guidePrice	number	Y	指导价
 * assessPrice	number	Y	评估价
 * peopleNumber	number	Y	出价人数
 * auctionNumber	number	Y	出价次数
 * userLastPrice   number 上次出价

 * 四期新增
 * couponInfo	string	Y	优惠券，服务端处理好，前端直接显示即可，例如：200元、9.5折
 * reducedPrice	number	Y	优惠价
 * unusedCouponCount	number	Y	未使用优惠券数量
 * articleStatus	string	Y	竞拍结束，未参与用户，会返回拍卖品状态：车辆成交、车辆流拍，客户端直接展示
 * takeCarPrice	number	Y	提车价

 * 五期修改了状态字段
 * auctionDetailStatus	    number	Y	竞拍状态 1：未开始 2：竞拍中 3：已流拍（撤回、流拍）4：已结束（被其他人拍得） 5：已成交 6：交易完成 7：交易失败
 * auctionDetailStatusName	string	Y	竞拍状态名称，客户端直接显示
 * auctionDetailStatusDesc	string	Y	竞拍状态描述，客户端直接显示
 * returnDeposit	        boolean	Y	是否退还保证金，没有保证金则为null，true：已退，false：未退
 * addRemind	            boolean	Y	是否添加过提醒，默认null，true：已添加过，前端显示取消提醒按钮，false：没有添加过，前端显示提醒按钮
 */
data class AuctionBean(
        val addRemind: Boolean,
        val auctionDetailStatus: Int,
        val auctionDetailStatusName: String,
        val auctionDetailStatusDesc: String,
        val returnDeposit: Boolean,
        val couponInfo: String,
        val reducedPrice: String,
        val unusedCouponCount: Int,
        val articleStatus: String,
        val takeCarPrice: String,
        val auctionDuration: Int,
        val userLastPrice: Double,
        val hasLimitPrice: Boolean,
        val auctionMode: Int,
        val fixedPrice: Double,
        val guidePrice: Double,
        val assessPrice: Double,
        val peopleNumber: Int,
        val auctionNumber: Int,
        val auctionNo: String,
        val orderNO: String,
        val curPrice: Double,
        val curTime: String,
        val delaytime: Int,
        val deposit: Double,
        val endTime: String,
        val increment: Double,
        val remainingStartTime: Long,
        val remainingEndTime: Long,
        val startPrice: Double,
        val startTime: String,
        val status: Int,
        val title: String,
        val tradeStatus: Int,
        val picPath: List<String>,
        val instruction: List<String>,
        val newsRecord: List<NewRecordBean>,
        val auctionCarDetailVO: CarInfoBean) {

    companion object {
        val STATUS_NOT_START = 1
        val STATUS_AUCTIONING = 2
        val STATUS_AUCTION_FAILED = 3
        val STATUS_AUCTION_END = 4
        val STATUS_AUCTION_WIN = 5
        val STATUS_AUCTION_WIN_DOWN = 6
        val STATUS_AUCTION_WIN_FAILED = 7
        val STATUS_AUCTION_END_ALL = 99 // 状态已结束，用于竞拍中心显示

        /**
         * 竞拍类型 0：升价拍 1：暗拍
         */
        val AUCTION_MODE_NORMAL = 0
        val AUCTION_MODE_HIDE = 1
    }
}
