package com.weidai.wpai.ui.view

import android.app.Activity
import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.RelativeLayout
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.view_navigation_search.view.*

/**
 * Created by bici on 16/4/18.
 */
class NavigationSearchView @JvmOverloads constructor(context: Context, attributeSet: AttributeSet? = null) : RelativeLayout(context, attributeSet) {

    var onSearchListener: View.OnClickListener? = null
    var searchView: AccountEditText

    init {
        init()
        searchView = searchAET
    }

    private fun init() {
        LayoutInflater.from(context).inflate(R.layout.view_navigation_search, this)
        backBtn.setOnClickListener {
            try {
                (context as Activity).onBackPressed()
            } catch (e: Exception) {
            }
        }
        searchTV.setOnClickListener {
            if (onSearchListener != null) {
                onSearchListener!!.onClick(searchAET)
            }
        }
    }

    fun getSearchText(): String {
        return searchAET.text.toString()
    }

}
