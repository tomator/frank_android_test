package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.EvaluateCar
import kotlinx.android.synthetic.main.view_car_choose_item.view.*

class CarChooseAdapter(val context: Context) : RecyclerView.Adapter<CarChooseAdapter.ViewHolder>() {
    private val dataList = ArrayList<EvaluateCar>()
    var viewList = ArrayList<View>()
    var selectPosition = -1

    fun refreshDatas(datas: List<EvaluateCar>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_car_choose_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    fun getSelectData(): EvaluateCar? {
        if (selectPosition >= 0) {
            return dataList[selectPosition]
        } else {
            return null
        }
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        init {
            if (!viewList.contains(itemView.selectImgBtn)) {
                viewList.add(itemView.selectImgBtn)
            }
        }

        fun bindData(position: Int) {
            var data = dataList[position]

            itemView.textView.text = "${data.modelName} ${data.modelDetail}"
            itemView.containerView.setOnClickListener {
                viewList.forEach {
                    it.isSelected = false
                }
                itemView.selectImgBtn.isSelected = true
                selectPosition = position
            }
        }
    }
}
