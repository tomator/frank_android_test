package com.weidai.wpai.http.param

import com.weidai.wpai.App
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.util.DeviceUtils

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/9/8
 */

/**
{
"app_id":"WPAI-DEV",
"client_version":"1.1",
"device_code":"qweq5454645wqe45we45",
"device_platform":"ios",
"ip_address":"123.565.3.87",
"page_info":"竞拍详情页",
"request_url":"/auction/detail",
"mobile":"13745653122",
"data_code":"98798756"
}
 */
class ReportData {
    var app_id: String? = null
    var client_version: String? = null
    var device_code: String? = null
    var device_platform: String? = null
    var ip_address: String? = null
    var page_info: String? = null
    var request_url: String? = null
    var mobile: String? = null
    var data_code: String? = null

    companion object {
        fun create(): ReportData {
            var instance = ReportData()
            instance.app_id = BuildConfig.WD_APP_ID
            instance.client_version = BuildConfig.VERSION_NAME
            instance.device_platform = "Android"
            instance.device_code = DeviceUtils.getDeviceId(App.instance)
            if (UserManager.instance.isUserLogin) {
                instance.mobile = UserManager.instance.userMobile
            }
            return instance
        }
    }
}