package com.weidai.wpai.ui.activity

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.View
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.VinResultBean
import com.weidai.wpai.http.param.BuildeOrderVQO
import com.weidai.wpai.http.param.SearchCodeVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import kotlinx.android.synthetic.main.activity_maintenance.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class MaintenanceActivity : BaseActivity() {

    private var channel: String? = null
    private var times = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintenance)
        navigationView.setThemeColor(R.color.main_blue)
        navigationView.setTitle("维保记录查询")
        navigationView.setNextText("查询记录", View.OnClickListener {
            startActivity(Intent(this@MaintenanceActivity, MaintenanceListActivity::class.java))
        })
        vinCodeAET.setOnTextChange { checkSubmitEnable() }
        submitTV.isSelected = false
        requestFreeTimes()
        val constantBean = App.instance.constantBean
        if (constantBean != null) {
            timesTV.text = constantBean.registerfree
        }
        submitTV.setOnClickListener { v -> onViewClicked(v) }
        shareRL.setOnClickListener { v -> onViewClicked(v) }
        serviceInfoTV.setOnClickListener { v -> onViewClicked(v) }

        var vinCode = intent.getStringExtra("vinCode")
        if (!TextUtils.isEmpty(vinCode)) {
            vinCodeAET.text = vinCode
        }
    }

    private fun checkSubmitEnable() {
        val vinCode = vinCodeAET.text.toString()
        carInfoTV.text = "已输入${vinCode.length}/17位"

        if (ValidityUtils.checkVinCode(vinCode)) {
            checkVinCode(vinCode)
        }
    }

    private fun requestFreeTimes() {
        Client.getService().freeTimes()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Int>>() {
                    override fun onSuccess(result: Result<Int>) {
                        times = result.data!!
                        refreshTimes()
                    }
                })
    }

    private fun refreshTimes() {
        val len = times.toString().length
        val span = SpannableString("今日剩余免费查询次数：$times 次")
        val fColorSpan = ForegroundColorSpan(Color.parseColor("#2196FE"))
        span.setSpan(fColorSpan, 11, 11 + len, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
        findLimitTV.text = span
        submitTV.isSelected = times > 0
    }

    private fun checkVinCode(vinCode: String) {
        carInfoTV.visibility = View.VISIBLE
        carInfoTV.text = "正在查询中…"
        Client.getService().checkvin(SearchCodeVQO(vinCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<VinResultBean>>() {
                    override fun onSuccess(result: Result<VinResultBean>) {
                        if (result.data == null) {
                            queryVinCodeFialed(result.message)
                        } else {
                            var bean = result.data!!
                            val vinCodeNow = vinCodeAET.text.toString()
                            if (ValidityUtils.checkVinCode(vinCodeNow)) {
                                channel = bean.channel
                                carInfoTV.text = bean.carname + " " + bean.modelName
                            }
                        }
                    }

                    override fun onFailed(result: Result<*>) {
                        queryVinCodeFialed(result.message)
                    }

                    override fun onFailed(e: Throwable?, msg: String?) {
                        queryVinCodeFialed(null)
                    }
                })
    }

    fun queryVinCodeFialed(message: String?) {
        channel = null
        val vinCodeNow = vinCodeAET.text.toString()
        if (ValidityUtils.checkVinCode(vinCodeNow)) {
            if (TextUtils.isEmpty(message)) {
                carInfoTV.text = "查询失败"
            } else {
                carInfoTV.text = message
            }
        }
    }

    private fun submit() {
        val vinCode = vinCodeAET.text.toString()
        if (!ValidityUtils.checkVinCode(vinCode)) {
            ToastUtil.show("请输入17位vin码")
            return
        }
        if (TextUtils.isEmpty(channel)) {
            ToastUtil.show("没有查询到车辆信息")
            return
        }
        val progressDialog = ProgressDialog(this)
        progressDialog.show()
        Client.getService().buildOrder(BuildeOrderVQO(channel!!, vinCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>(progressDialog) {

                    override fun onSuccess(result: Result<*>) {
                        ToastUtil.show("查询中，请稍后查看报告")
                        times = times - 1
                        refreshTimes()
                        startActivity(Intent(this@MaintenanceActivity, MaintenanceListActivity::class.java))
                    }
                })
    }

    fun onViewClicked(view: View) {
        when (view.id) {
            R.id.submitTV -> if (submitTV.isSelected) {
                submit()
            }
            R.id.shareRL -> startActivity(Intent(this, ShareActivity::class.java))
            R.id.serviceInfoTV -> WPWebActivty.openStaticPage(this, StaticPage.deal_protect)
        }
    }
}
