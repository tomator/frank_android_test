package com.weidai.wpai.ui.adapter

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.PagerAdapter
import android.view.ViewGroup

import com.weidai.wpai.ui.fragment.AuctionCenterFragment
import com.weidai.wpai.ui.fragment.HomeFragment
import com.weidai.wpai.ui.fragment.MyFragment

class HomeViewPagerAdapter(fm: FragmentManager, val context: Context) : FragmentPagerAdapter(fm) {
    var homeFragment: HomeFragment = HomeFragment()
    var auctionFragment: AuctionCenterFragment = AuctionCenterFragment()
    var myFragment: MyFragment = MyFragment()

    override fun getItem(arg0: Int): Fragment? {
        when (arg0) {
            0 -> return homeFragment
            1 -> return auctionFragment
            2 -> return myFragment
            else -> return null
        }
    }

    override fun getCount(): Int {
        return 3
    }

    override fun getPageTitle(position: Int): CharSequence? {
        when (position) {
            0 -> return "首页"
            1 -> return "竞拍中心"
            2 -> return "我的"
            else -> return null
        }
        return null
    }

    override fun getItemPosition(`object`: Any?): Int {
        return PagerAdapter.POSITION_UNCHANGED
    }

    override fun destroyItem(container: ViewGroup?, position: Int, `object`: Any) {

    }

}
