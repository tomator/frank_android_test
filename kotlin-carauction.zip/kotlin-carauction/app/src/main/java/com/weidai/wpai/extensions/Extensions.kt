@file:JvmName("ExtensionsUtils")

package com.weidai.wpai.extensions

import android.support.annotation.DrawableRes
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.github.promeg.pinyinhelper.Pinyin
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.util.FormatUtil
import com.zaaach.citypicker.utils.PinyinUtils


fun ViewGroup.inflate(layoutId: Int, attachToRoot: Boolean = false): View {
    return LayoutInflater.from(context).inflate(layoutId, this, attachToRoot)
}

fun ImageView.displayRoundAssets(name: String,
                                 @DrawableRes error: Int = R.mipmap.ic_car_logo) {
    val path = "car_logo/$name.png"
    ImageLoader.instance.displayRoundAssets(path, this, error)
}

fun <T : View> View.findViewOften(viewId: Int): T {
    var viewHolder: SparseArray<View> = tag as? SparseArray<View> ?: SparseArray()
    tag = viewHolder
    var childView: View? = viewHolder.get(viewId)
    if (null == childView) {
        childView = findViewById(viewId)
        viewHolder.put(viewId, childView)
    }
    return childView as T
}

fun String.pinyin(separator: String = ""): String {
    return Pinyin.toPinyin(this, separator)
}

fun String.equalsIgnoreUpLow(other: String): Boolean {
    return this.toUpperCase().equals(other.toUpperCase())
}

fun String.getFirstLetter(): String {
    return PinyinUtils.getFirstLetter(this.pinyin())
}

fun String?.show(): String {
    if (TextUtils.isEmpty(this)) {
        return ""
    } else {
        return this!!
    }
}

/**
 * 去除所有空格
 */
fun String?.trimAll(): String {
    if (TextUtils.isEmpty(this)) {
        return ""
    } else {
        return this!!.replace(" ", "")
    }
}

fun String?.double2(): String {
    if (TextUtils.isEmpty(this)) {
        return ""
    }
    try {
        var doubleValue = this!!.toDouble()
        return FormatUtil.getDouble2(doubleValue)
    } catch (e: Exception) {
        return this!!
    }
}

fun String.getSpan(color: Int, start: Int, end: Int): SpannableString {
    val span = SpannableString(this)
    val fColorSpan = ForegroundColorSpan(color)
    span.setSpan(fColorSpan, start, end, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
    return span
}