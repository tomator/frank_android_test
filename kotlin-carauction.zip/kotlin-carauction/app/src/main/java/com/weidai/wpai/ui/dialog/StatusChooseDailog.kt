package com.weidai.wpai.ui.dialog

import android.content.Context
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.param.SearchAuctionVQO
import com.weidai.wpai.ui.model.CarStatus
import com.weidai.wpai.ui.view.StatusItemView
import kotlinx.android.synthetic.main.dialog_status_chosse.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/10
 */
class StatusChooseDailog(context: Context, baseView: View)
    : BaseFilterDialog(context, baseView) {

    var carStatus: CarStatus? = null

    init {
        allView.carStatus = CarStatus("全部", SearchAuctionVQO.CAR_STATUS_ALL)
        auctionView.carStatus = CarStatus("竞拍中", SearchAuctionVQO.CAR_STATUS_AUCTION)
        aboutToView.carStatus = CarStatus("即将拍卖", SearchAuctionVQO.CAR_STATUS_ABOUT_TO)
        finishView.carStatus = CarStatus("已结束", SearchAuctionVQO.CAR_STATUS_FINISH)
        setOnShowListener {
            if (carStatus == null) {
                carStatus = allView.carStatus
                allView.isSelected = true
            }
        }
        shadowView.setOnClickListener { dismiss() }
        allView.setOnClickListener { v -> onViewClicked(v) }
        auctionView.setOnClickListener { v -> onViewClicked(v) }
        aboutToView.setOnClickListener { v -> onViewClicked(v) }
        finishView.setOnClickListener { v -> onViewClicked(v) }
    }

    override fun getLayoutRes(): Int {
        return R.layout.dialog_status_chosse
    }

    override fun initView() {}

    fun onViewClicked(view: View) {
        closeAll()
        view.isSelected = true
        if (view is StatusItemView) {
            carStatus = view.carStatus
        }
        RxBus.get().post(EventKey.KEY_CHOOSE_CAR_STATUS, carStatus)
    }

    private fun closeAll() {
        allView.isSelected = false
        auctionView.isSelected = false
        aboutToView.isSelected = false
        finishView.isSelected = false
    }
}
