package com.weidai.wpai.ui.fragment

import android.view.View
import com.jungly.gridpasswordview.GridPasswordView
import com.weidai.wpai.App
import com.weidai.wpai.component.StatisticalManager
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.AuctionBean
import com.weidai.wpai.http.param.SearchCodeVQO
import com.weidai.wpai.http.param.SignUpVQO
import com.weidai.wpai.http.param.UpfeeVQO
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.ui.dialog.PayPwdDialog
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.dialog.ToastDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.secret.PasswordUtil
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/21
 */
class AuctionHelper(var fragment: AuctionFragment) {
    var activity: AuctionActivity
    var auctionNo: String
    var timer: Timer? = null
    var isWatching = false
    var auctionBean: AuctionBean? = null
    var watchBack = true

    init {
        activity = fragment.context as AuctionActivity
        auctionNo = activity.auctionNo
    }

    fun requestAuctionBase() {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        Client.getService().auctionBase(SearchCodeVQO(auctionNo))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<AuctionBean>>(progressDialog) {
                    override fun onSuccess(result: Result<AuctionBean>) {
                        super.onSuccess(result)
                        LogUtil.d("requestAuctionBase : " + result.data)
                        auctionBean = result.data
                        fragment.refreshView(auctionBean!!)
                        activity.setAuctionBean(auctionBean!!)
                        StatisticalManager.reportAuctionDetail(auctionBean!!.auctionNo)
                    }
                })
    }

    fun auctionEntry(pwd: String) {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        Client.getService().auctionEntry(SignUpVQO(PasswordUtil.encode(pwd), auctionNo))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<String>>(progressDialog) {
                    override fun onSuccess(result: Result<String>) {
                        super.onSuccess(result)
                        fragment.isDeposed = true
                        fragment.orderNo = result.data!!
                        fragment.refreshUserInfo()
                        fragment.onBidClick()
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        if (result.code == Result.CODE_NO_BANK) {
                            UserManager.instance.toBindCard(activity)
                        }
                    }
                })
    }

    fun auctionUpfee(orderNo: String, price: Double) {
        val progressDialog = ProgressDialog(activity)
        progressDialog.show()
        Client.getService().auctionUpfee(UpfeeVQO(price.toString(), orderNo))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>(progressDialog) {
                    override fun onSuccess(result: Result<*>) {
                        super.onSuccess(result)
                        auctionWatch()
                        ToastUtil.show(result.message)
                        fragment.bidSuccess(price)
                    }
                })
    }

    fun auctionWatch() {
        if (!watchBack || !App.instance.isAppOnForeground) {
            return
        }
        watchBack = false
        Client.getService().auctionWatch(auctionNo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<AuctionBean>>() {
                    override fun onSuccess(result: Result<AuctionBean>) {
                        super.onSuccess(result)
                        if (result.data != null) {
                            fragment.refreshByWatch(result.data!!)
                        }
                        watchBack = true
                    }

                    override fun onFailed() {
                        watchBack = true
                    }
                })
    }

    @Synchronized fun startWatch() {
        if (!isWatching) {
            isWatching = true
            timer = Timer()
            timer!!.schedule(object : TimerTask() {
                override fun run() {
                    auctionWatch()
                }
            }, 0, WATCH_INTERVAL)
        }
    }

    fun stopWatch() {
        isWatching = false
        if (timer != null) {
            timer!!.cancel()
        }
    }

    fun showBindCardDialog() {
        ToastDialog(activity)
                .setTitleString("提示")
                .setContent("您还没有绑定银行卡，请先绑卡。")
                .setNegative("取消", null)
                .setPositive("绑定", View.OnClickListener { UserManager.instance.toBindCard(activity) })
                .show()
    }

    fun showRechargeDialog() {
        ToastDialog(activity)
                .setTitleString("提示")
                .setContent("参与竞拍需冻结" + auctionBean!!.deposit + "元保证金，您的余额不足，请先充值")
                .setNegative("取消", null)
                .setPositive("充值", View.OnClickListener { UserManager.instance.toRecharge(activity) })
                .show()
    }

    fun showDepositDialog() {
        ToastDialog(activity)
                .setTitleString("提示")
                .setContent("需冻结" + auctionBean!!.deposit + "元保证金，结束后解冻。是否确定报名竞拍？")
                .setNegative("取消", null)
                .setPositive("确定", View.OnClickListener { showPayPwdDialog() })
                .show()
    }

    fun showPayPwdDialog() {
        val payPwdDialog = PayPwdDialog(activity, auctionBean!!.deposit, PayPwdDialog.TYPE_PAY)
        payPwdDialog.show()
        payPwdDialog.setOnPasswordChangedListener(object : GridPasswordView.OnPasswordChangedListener {
            override fun onTextChanged(psw: String) {

            }

            override fun onInputFinish(psw: String) {
                auctionEntry(psw)
                payPwdDialog.cancel()
            }
        })
    }

    fun showBidConfirmDialog(orderNo: String, price: Double, isFixed: Boolean = false) {
        var tips = "确认是否出价${FormatUtil.getChineseMoney(price)}元"
        if (isFixed) {
            tips = "若确定一口价出价，车辆将立即成交。\n是否出价${FormatUtil.getChineseMoney(price)}元"
        }
        if (auctionBean!!.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
            tips = "暗拍模式以您最后一次出价为有效报价。\n是否出价${FormatUtil.getChineseMoney(price)}元？"
        }
        ToastDialog(activity)
                .setTitleString("提示")
                .setContent(tips)
                .setNegative("取消", null)
                .setPositive("出价", View.OnClickListener { auctionUpfee(orderNo, price) })
                .show()
    }

    fun remind(auctionNo: String, isRemind: Boolean) {
        var dialog = ProgressDialog(activity)
        dialog.show()
        var subscribe = object : SimpleSubscriber<Result<*>>(dialog) {
            override fun onSuccess(result: Result<*>) {
                requestAuctionBase()
                if (isRemind) {
                    ToastUtil.show("添加成功，开拍时以短信和APP提醒")
                } else {
                    ToastUtil.show("您已取消开拍提醒")
                }
            }
        }
        if (isRemind) {
            Client.getService().remindAdd(auctionNo)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(subscribe)
        } else {
            Client.getService().remindCancel(auctionNo)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(subscribe)
        }
    }

    companion object {
        val WATCH_INTERVAL = 10 * 1000L
    }

}
