package com.weidai.wpai.util.preferences;

import android.text.TextUtils;

import com.weidai.wpai.App;
import com.weidai.wpai.BuildConfig;
import com.weidai.wpai.http.bean.HotCity;
import com.weidai.wpai.http.bean.UserInfoBean;
import com.weidai.wpai.http.param.DateNoticeVQO;
import com.weidai.wpai.ui.model.User;
import com.weidai.wpai.util.DateUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Describe: sharePreface数据操作类
 * User: LiYajun
 * Date: 2016-06-06
 */
public class SpfUtils {
    private SecurePreferences mSharedPreferences;
    private static SpfUtils mPreferences = new SpfUtils();
    public static final String DEFAULT_SERVICE_NO = "400-077-0888";

    private SpfUtils() {
        mSharedPreferences = new SecurePreferences(App.Companion.getInstance());
    }

    public synchronized static SpfUtils getInstance() {
        return mPreferences;
    }

    public void saveHotCityId(HotCity hotCity) {
        List<HotCity.HotCitys> hotCitysList = hotCity.getHotCitys();
        StringBuilder builder = new StringBuilder();
        for (HotCity.HotCitys hotCitys : hotCitysList) {
            builder.append(hotCitys.getId()).append(",");
        }
        saveData(SpfKey.HOT_CITY_COMMON, builder.toString());

        List<HotCity.CarHotCitys> evalList = hotCity.getCarHotCitys();
        builder = new StringBuilder();
        for (HotCity.CarHotCitys eval : evalList) {
            builder.append(eval.getId()).append(",");
        }
        saveData(SpfKey.HOT_CITY_EVALUATE, builder.toString());
    }

    public void saveUserInfo(UserInfoBean userInfo) {
        saveData(SpfKey.USER_NAME, userInfo.getUserName());
        saveData(SpfKey.USER_MOBILE_NO, userInfo.getMobileNo());
        saveData(SpfKey.USER_HAS_PAY_PWD, userInfo.getHasPayPwd());
    }

    public User getUser() {
        return new User().setUserName(getString(SpfKey.USER_NAME, null))
                .setHasPayPwd(getString(SpfKey.USER_HAS_PAY_PWD, null))
                .setAvatar(getString(SpfKey.USER_AVATAR, null))
                .setBindCardNo(getString(SpfKey.USER_BIND_CARD_NO, null))
                .setMobileNo(getString(SpfKey.USER_MOBILE_NO, null));
    }

    public void clearUserInfo() {
        saveData(SpfKey.USER_NAME, null);
        saveData(SpfKey.USER_MOBILE_NO, null);
        saveData(SpfKey.USER_HAS_PAY_PWD, null);
        saveData(SpfKey.USER_AVATAR, null);
        saveData(SpfKey.USER_BIND_CARD_NO, null);
        saveData(SpfKey.COOKIE_WPAI_CODE, null);
        saveData(SpfKey.COOKIE_WPAI_TOKEN, null);
    }

    public void addStringListItem(String key, String item) {
        if (!TextUtils.isEmpty(item)) {
            List<String> list = getStringList(key);
            if (!list.contains(item)) {
                String str = getString(key, null);
                if (TextUtils.isEmpty(str)) {
                    saveData(key, item);
                } else {
                    saveData(key, str + "," + item);
                }
            }
        }
    }

    public List<String> getStringList(String key) {
        List<String> list = new ArrayList<>();
        String str = getString(key, null);
        if (!TextUtils.isEmpty(str)) {
            String[] array = str.split(",");
            list.addAll(Arrays.asList(array));
        }
        return list;
    }

    public String getChannelKey() {
        return getString(SpfKey.APP_CHANNEL_KEY, null);
    }

    public void setChannelKey(String channelKey) {
        saveData(SpfKey.APP_CHANNEL_KEY, channelKey);
    }

    public long getLastVersion() {
        return getLong(SpfKey.LAST_APP_VERSION, 0);
    }

    public void saveLastVersion() {
        saveData(SpfKey.LAST_APP_VERSION, BuildConfig.VERSION_CODE);
    }

    public String getServiceNo() {
        return getString(SpfKey.SERVICE_CONTACT_NO, DEFAULT_SERVICE_NO);
    }

    public void saveServiceNo(String serviceNo) {
        saveData(SpfKey.SERVICE_CONTACT_NO, serviceNo);
    }

    public void saveSysNotice() {
        saveData(SpfKey.LAST_TIME_NOTICE_SYS, DateUtil.format(System.currentTimeMillis(), 17));
        App.instance.requestNewMessage();
    }

    public void saveUserNotice() {
        saveData(SpfKey.LAST_TIME_NOTICE_USER, DateUtil.format(System.currentTimeMillis(), 17));
        App.instance.requestNewMessage();
    }

    public void saveCouponNotice() {
        saveData(SpfKey.LAST_TIME_NOTICE_COUPON, DateUtil.format(System.currentTimeMillis(), 17));
        App.instance.requestNewMessage();
    }

    public DateNoticeVQO getNoticeData() {
        String sysTime = getString(SpfKey.LAST_TIME_NOTICE_SYS, null);
        String userTime = getString(SpfKey.LAST_TIME_NOTICE_USER, null);
        String couponTime = getString(SpfKey.LAST_TIME_NOTICE_COUPON, null);
        DateNoticeVQO notice = new DateNoticeVQO(sysTime, userTime, couponTime);
        return notice;
    }

    /**
     * 保存数据到文件
     *
     * @param key  键，一般保存在SpfKey
     * @param data
     */
    public void saveData(String key, Object data) {
        SecurePreferences.Editor editor = mSharedPreferences.edit();
        if (data == null) {
            editor.putString(key, null);
        } else if (data instanceof Integer) {
            editor.putInt(key, (Integer) data);
        } else if (data instanceof Boolean) {
            editor.putBoolean(key, (Boolean) data);
        } else if (data instanceof Float) {
            editor.putFloat(key, (Float) data);
        } else if (data instanceof Long) {
            editor.putLong(key, (Long) data);
        } else {
            editor.putString(key, data.toString());
        }
        editor.apply();
    }

    /**
     * 从文件中读取数据
     *
     * @param key 关键字
     */
    public void clearData(String key) {
        SecurePreferences.Editor editor = mSharedPreferences.edit();
        editor.remove(key).apply();
    }

    /**
     * 获取保存在sharedPreferences的bool值
     *
     * @param key      key值
     * @param defValue 默认值
     * @return
     */
    public boolean getBoolean(String key, Object defValue) {
        return mSharedPreferences.getBoolean(key, (Boolean) defValue);
    }

    /**
     * 获取保存在sharedPreferences的int值
     *
     * @param key      key值
     * @param defValue 默认值
     * @return
     */
    public int getInt(String key, Object defValue) {
        return mSharedPreferences.getInt(key, (Integer) defValue);
    }

    /**
     * 获取保存在sharedPreferences的string值
     *
     * @param key      key值
     * @param defValue 默认值
     * @return
     */
    public String getString(String key, Object defValue) {
        return mSharedPreferences.getString(key, (String) defValue);
    }

    /**
     * 获取保存在sharedPreferences的float值
     *
     * @param key      key值
     * @param defValue 默认值
     * @return
     */
    public float getFloat(String key, Object defValue) {
        return mSharedPreferences.getFloat(key, (Float) defValue);
    }

    /**
     * 获取保存在sharedPreferences的long值
     *
     * @param key      key值
     * @param defValue 默认值
     * @return
     */
    public long getLong(String key, long defValue) {
        return mSharedPreferences.getLong(key, defValue);
    }
}
