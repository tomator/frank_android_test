package com.weidai.wpai.ui.activity

import android.os.Bundle
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.RechargeBean
import com.weidai.wpai.http.param.BankCardVQO
import com.weidai.wpai.http.param.SendMsgVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ValidityUtils
import kotlinx.android.synthetic.main.activity_phone_auth.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class RechargePhoneAuthActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phone_auth)
        var data = intent.getSerializableExtra("rechargeBean")
        if (data == null) {
            finish()
            return
        }
        var rechargeBean = data as RechargeBean
        tipsTV.text = "本次操作需要短信确认，验证码已发送至手机: " +
                "${FormatUtil.getDisplayMobile(UserManager.instance.userMobile)}, " +
                "请输入验证码确认。"
        authcodeView.setPhoneNumber(UserManager.instance.userMobile)
        authcodeView.setType(SendMsgVQO.TYPE_BIND_CARD)
        authcodeView.rechargeBean = rechargeBean
        authcodeView.getAuthcodeAET().setTextSize(13)
        authcodeView.getAuthcodeAET().setOnTextChange {
            val authcode = authcodeView.text.toString()
            if (ValidityUtils.checkAuthcode(authcode)) {
                nextStepTV.isSelected = true
            }
        }
        nextStepTV.setOnClickListener {
            if (nextStepTV.isSelected) {
                submit(rechargeBean)
            }
        }
    }

    private fun submit(rechargeBean: RechargeBean) {
        val authcode = authcodeView.text.toString()
        val progressDialog = ProgressDialog(this)
        progressDialog.show()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_BIND_CARD_SUCCESS)))
    fun onBindCard(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onBindCard " + success)
        finish()
    }
}
