package com.weidai.wpai.db

import com.google.gson.Gson
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.http.bean.EvaluateResult

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/9/26
 */

data class EvaluateParam(
        var vinCode: String? = null,
        var evaluateResult: String,
        var carInfo: String,
        var enableVinCode: String? = null) {

    companion object {
        val TABLE_NAME = "EvaluateParam"
        val VIN_CODE = "vinCode"
        val EVALUATE_RESULT = "evaluateResult"
        val CAR_INFO = "carInfo"
        val ENABLE_VIN_CODE = "enableVinCode"
        val CREATE_TABLE = " CREATE TABLE $TABLE_NAME ( " +
                "  $EVALUATE_RESULT TEXT NOT NULL, " +
                "  $CAR_INFO TEXT NOT NULL, " +
                "  $VIN_CODE TEXT , " +
                "  $ENABLE_VIN_CODE TEXT )"

        fun create(vinCode: String?,
                   evaluateResult: EvaluateResult,
                   carInfo: EvaluateCar,
                   enableVinCode: String? = null): EvaluateParam {
            var gson = Gson()
            return EvaluateParam(vinCode, gson.toJson(evaluateResult), gson.toJson(carInfo), enableVinCode)
        }
    }
}
