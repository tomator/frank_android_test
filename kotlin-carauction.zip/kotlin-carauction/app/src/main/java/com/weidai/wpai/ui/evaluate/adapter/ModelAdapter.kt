package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.ModelBean
import kotlinx.android.synthetic.main.car_view_model_item.view.*
import kotlinx.android.synthetic.main.car_view_model_title_item.view.*
import java.util.*

/**
 * author zaaach on 2016/1/26.
 */
class ModelAdapter(context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var dataList: MutableList<ModelBean> = ArrayList()
    var inflater: LayoutInflater = LayoutInflater.from(context)
    private var itemClickListener: BrandListAdapter.ItemClickListener? = null

    fun refreshDatas(datas: List<ModelBean>?) {
        this.dataList.clear()
        if (datas != null && datas.size > 0) {
            this.dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemViewType(position: Int): Int {
        return dataList[position].type
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        var view: View? = null
        if (viewType == 0) {
            view = inflater.inflate(R.layout.car_view_model_title_item, parent, false)
            return TitleViewHolder(view)
        } else {
            view = inflater.inflate(R.layout.car_view_model_item, parent, false)
            return ItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is TitleViewHolder) {
            holder.bindData(position)
        } else if (holder is ItemViewHolder) {
            holder.bindData(position)
        }
    }

    inner class TitleViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            itemView.textView.text = dataList[position].name
        }
    }

    inner class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            itemView.groupTV.visibility = View.GONE
            itemView.modelTV.text = dataList[position].name
            itemView.modelTV.setOnClickListener {
                if (itemClickListener != null) {
                    itemClickListener!!.onItemClick(dataList[position].name)
                }
            }
        }
    }

    fun setItemClickListener(listener: BrandListAdapter.ItemClickListener) {
        this.itemClickListener = listener
    }
}
