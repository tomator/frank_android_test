package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import com.weidai.wpai.R
import com.weidai.wpai.http.param.SearchTradeVQO
import com.weidai.wpai.ui.fragment.MyAuctionFragment
import kotlinx.android.synthetic.main.activity_my_order.*

class MyOrderActivity : BaseActivity() {

    lateinit var fragmentDeal: MyAuctionFragment
    lateinit var fragmentComplete: MyAuctionFragment
    lateinit var fragmentFailed: MyAuctionFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_order)
        fragmentDeal = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_DEAL)
        fragmentComplete = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_COMPLETE)
        fragmentFailed = MyAuctionFragment.newInstance(SearchTradeVQO.STATUS_FAILED)
        initView()
        var position = intent.getIntExtra("position", 0)
        viewpager.currentItem = position
    }

    private fun initView() {
        navigationView.setTitle("我的订单")
        tabView.setOnCheckedLinstener { v, index -> viewpager.currentItem = index }
        viewpager.offscreenPageLimit = 2
        viewpager.adapter = object : FragmentPagerAdapter(supportFragmentManager) {
            override fun getItem(position: Int): Fragment? {
                when (position) {
                    0 -> return fragmentDeal
                    1 -> return fragmentComplete
                    2 -> return fragmentFailed
                    else -> return null
                }
            }

            override fun getCount(): Int {
                return resources.getStringArray(R.array.tabMyOrders).size
            }
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                tabView.setCheckViewByIndex(position)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }
}
