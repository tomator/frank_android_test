package com.weidai.wpai.ui.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.BalanceBean
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.activity_wallet.*

class WalletActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wallet)
        navigationView.setTitle("我的钱包")
        navigationView.setNextText("资金明细", View.OnClickListener {
            startActivity(Intent(this@WalletActivity, FinanceLogActivity::class.java))
        })
        requestBalance()
        onViewClicked()
    }

    private fun requestBalance() {
        val progressDialog = ProgressDialog(this)
        progressDialog.show()
        UserManager.instance.reqeustUserBalance(
                object : SimpleSubscriber<Result<BalanceBean>>(progressDialog) {
                    override fun onSuccess(result: Result<BalanceBean>) {
                        super.onSuccess(result)
                        refreshView(result.data!!)
                    }
                })
    }

    private fun refreshView(balance: BalanceBean) {
        val accountBalance = FormatUtil.MONEY_UNIT_SYMBOL + FormatUtil.getFormateMoney(balance.accountAmount)
        val availabeAmount = FormatUtil.MONEY_UNIT_SYMBOL + FormatUtil.getFormateMoney(balance.availabeAmount)
        val freezeAmount = FormatUtil.MONEY_UNIT_SYMBOL + FormatUtil.getFormateMoney(balance.freezeAmount)
        accountBalanceTV.text = accountBalance
        accountFrozenTV.text = freezeAmount
        accountUseableTV.text = availabeAmount
    }

    fun onViewClicked() {
        val intent = Intent(this, RechargeActivity::class.java)
        rechargeTV.setOnClickListener {
            intent.putExtra("type", RechargeActivity.TYPE_RECHARGE)
            startActivity(intent)
        }
        withdrawTV.setOnClickListener {
            intent.putExtra("type", RechargeActivity.TYPE_WITHDRAW)
            startActivity(intent)
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_RECHARGE_RESULT),
            Tag(EventKey.KEY_WITHDRAW_RESULT)))
    fun onRechargeResult(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onRechargeResult " + success)
        requestBalance()
    }
}
