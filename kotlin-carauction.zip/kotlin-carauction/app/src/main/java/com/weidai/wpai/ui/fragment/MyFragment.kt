package com.weidai.wpai.ui.fragment

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.NoticeTipBean
import com.weidai.wpai.http.bean.UserInfoBean
import com.weidai.wpai.ui.activity.*
import com.weidai.wpai.ui.evaluate.activity.EvaluateActivity
import com.weidai.wpai.ui.model.PushBean
import com.weidai.wpai.util.CallUtil
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.fragment_my.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/8
 */
class MyFragment : BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_my, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            val layoutParams = messageRL.layoutParams as RelativeLayout.LayoutParams
            layoutParams.setMargins(0, DensityUtil.dip2px(10f), DensityUtil.dip2px(15f), 0)
        }
        refreshView()
        if (UserManager.instance.isUserLogin) {
            requestUserInfo()
        }
        contactItem.setRightText(SpfUtils.getInstance().serviceNo)
        serviceRecordItem.showHideDot(!SpfUtils.getInstance()
                .getBoolean(SpfKey.MAINTENANCE_HAS_READED, false))
        evaluateItem.showHideDot(!SpfUtils.getInstance()
                .getBoolean(SpfKey.EVALUATE_HAS_READED, false))
        onViewClick()
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        if (isVisibleToUser) {
            App.instance.requestNewMessage()
        }
    }

    private fun refreshView() {
        if (userNotLoginLL == null || userLoginLL == null) {
            return
        }
        if (UserManager.instance.isUserLogin) {
            val user = SpfUtils.getInstance().user
            userNotLoginLL.visibility = View.GONE
            userLoginLL.visibility = View.VISIBLE
            userNameTV.text = FormatUtil.getDisplayMobile(user.mobileNo)
            ImageLoader.instance.display(user.avatar, avatarIV)
        } else {
            userNotLoginLL.visibility = View.VISIBLE
            userLoginLL.visibility = View.GONE
        }
    }

    private fun requestUserInfo() {
        requestUserBaseInfo()
        UserManager.instance.reqeustBindCardInfo()
    }

    private fun requestUserBaseInfo() {
        Client.getService().userInfo.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<UserInfoBean>>(false) {
                    override fun onSuccess(result: Result<UserInfoBean>) {
                        super.onSuccess(result)
                        if (result.code == Result.CODE_LOGIN) {
                            UserManager.instance.cleanUserInfo()
                        } else if (result.code == Result.CODE_SUCEESS) {
                            UserManager.instance.saveUserInfo(result.data)
                        }
                        refreshView()
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        refreshView()
                    }

                    override fun onFailed(e: Throwable?, msg: String?) {
                        super.onFailed(e, msg)
                        refreshView()
                    }
                })
    }

    fun onViewClick() {
        loginBtn.setOnClickListener { startActivity(Intent(context, LoginActivity::class.java)) }
        myWalletItem.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                startActivity(Intent(context, WalletActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        protocolItem.setOnClickListener { WPWebActivty.openStaticPage(context, StaticPage.deal_mustKnow) }
        aboutAppItem.setOnClickListener {
            WPWebActivty.openStaticPage(context, StaticPage.deal_about)
//            WPWebActivty.open(context, "https://api.chaboshi.cn/new_report/show_reportMobile?userid=64653&orderid=ac58d3355fe64f8c885ff70e85cb4a59&nonce=8f920ecb-9cc0-4b2a-bd6f-171098fb2f26&timestamp=1504833736098&signature=eBQMr%2Fv%2BybX%2BLXFIOtbco9NJ0mE%3D")
        }
        contactItem.setOnClickListener { CallUtil.callService(context as Activity) }
        settingItem.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                startActivity(Intent(context, SettingActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        appInfoBtn.setOnClickListener { appInfo() }
        messageIV.setOnClickListener {
            SpfUtils.getInstance().saveSysNotice()
            startActivity(Intent(context, MessageActivity::class.java))
        }
        serviceRecordItem.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                SpfUtils.getInstance().saveData(SpfKey.MAINTENANCE_HAS_READED, true)
                serviceRecordItem.showHideDot(false)
                (context as MainActivity).needShowMyPoint(null)
                startActivity(Intent(context, MaintenanceActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        evaluateItem.setOnClickListener {
            SpfUtils.getInstance().saveData(SpfKey.EVALUATE_HAS_READED, true)
            evaluateItem.showHideDot(false)
            (context as MainActivity).needShowMyPoint(null)
            startActivity(Intent(context, EvaluateActivity::class.java))
        }
        myCouponItem.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                SpfUtils.getInstance().saveCouponNotice()
                myCouponItem.showHideDot(false)
                startActivity(Intent(context, MyCouponActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        myRemindLL.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                startActivity(Intent(context, RemindActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        myAuctionLL.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                startActivity(Intent(context, MyAuctionActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
        myOrderLL.setOnClickListener {
            if (UserManager.instance.isUserLogin) {
                startActivity(Intent(context, MyOrderActivity::class.java))
            } else {
                UserManager.instance.turn2Login()
            }
        }
    }

//    fun test() {
//        var gson = Gson()
//        var reader = BufferedReader(InputStreamReader(context.assets.open("eval")))
//        var result = gson.fromJson(reader, EvaluateResult::class.java)
//        LogUtil.d("result = ${result}")
//    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_LOGIN_SUCCESS),
            Tag(EventKey.KEY_USER_NOT_LOGIN),
            Tag(EventKey.KEY_USER_CLEAR_INFO),
            Tag(EventKey.KEY_USER_LOGOUT_SUCCESS)))
    fun onUserRegister(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onUserRegister " + success)
        refreshView()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_NOTICE_TIP)))
    fun onNoticeTip(noticeTip: NoticeTipBean?) {
        LogUtil.d(EventKey.TAG, "onNoticeTip " + noticeTip!!)
        if (noticeTip != null) {
            if (noticeTip.hasUserNotice || noticeTip.hasSysNotice) {
                dotView.visibility = View.VISIBLE
            } else {
                dotView.visibility = View.INVISIBLE
            }
            myCouponItem.showHideDot(noticeTip.hasCouponNotice)
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_PUSH_DATA)))
    fun onPushData(pushBean: PushBean) {
        LogUtil.d(EventKey.TAG, "onPushData " + pushBean)
        dotView.visibility = View.VISIBLE
        App.instance.requestNewMessage()
    }

    private var appInfoClickTime: Long = 0
    private var appInfoClickCount: Long = 0

    private fun appInfo() {
        val time = System.currentTimeMillis()
        val offset = time - appInfoClickTime
        LogUtil.d("time offset = " + offset)
        if (offset < 500) {
            appInfoClickCount++
            if (appInfoClickCount >= 7) {
                appInfoClickCount = 0
                appInfoClickTime = 0
                startActivity(Intent(context, AppInfoActivity::class.java))
            }
        } else {
            appInfoClickCount = 0
        }
        appInfoClickTime = time
    }
}
