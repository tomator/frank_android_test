package com.weidai.wpai.ui.activity

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.MaintenanceBean
import com.weidai.wpai.http.param.BaseSearchObject
import com.weidai.wpai.ui.adapter.MaintenanceAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import kotlinx.android.synthetic.main.activity_maintenance_list.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class MaintenanceListActivity : BaseActivity() {

    lateinit var adapter: MaintenanceAdapter
    private var index = Bean.PAGE_INDEX

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintenance_list)
        navigationView.setTitle("查询记录")
        initRefresh()
        toFindTV.setOnClickListener { onBackPressed() }
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(this)
        ptrFrame.setHeaderView(refreshHeader)
        ptrFrame.setFooterView(DefaultFooter(this))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.setMode(PtrFrameLayout.Mode.REFRESH)
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.setResistanceFooter(1.0f)
        ptrFrame.setDurationToCloseFooter(200)
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(this,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.setLayoutManager(linearLayoutManager)
        adapter = MaintenanceAdapter(this)
        recyclerView.setAdapter(adapter)
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        val simpleSubscriber = object : SimpleSubscriber<Result<ListData<MaintenanceBean>>>(ptrFrame) {
            override fun onSuccess(result: Result<ListData<MaintenanceBean>>) {
                super.onSuccess(result)
                val dataList = result.data!!.data
                if (refresh && (dataList == null || dataList.size == 0)) {
                    recyclerView.setVisibility(View.GONE)
                    nullView.setVisibility(View.VISIBLE)
                    return
                }
                recyclerView.setVisibility(View.VISIBLE)
                nullView.setVisibility(View.GONE)
                if (refresh) {
                    adapter.refreshDatas(dataList)
                } else {
                    adapter.addDatas(dataList)
                }
                if (dataList!!.size >= Bean.PAGE_SIZE) {
                    ptrFrame.setMode(PtrFrameLayout.Mode.BOTH)
                    index++
                } else {
                    ptrFrame.setMode(PtrFrameLayout.Mode.REFRESH)
                }
            }

            override fun onFailed() {
                recyclerView.setVisibility(View.GONE)
                nullView.setVisibility(View.VISIBLE)
            }
        }
        Client.getService().maintenanceList(BaseSearchObject(index, Bean.PAGE_SIZE))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(simpleSubscriber)
    }
}
