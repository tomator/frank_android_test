package com.weidai.wpai.ui.view;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.weidai.wpai.R;
import com.weidai.wpai.ui.model.CarStatus;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class StatusItemView extends FrameLayout {

    private View containerView;
    private TextView textView;
    private ImageView imageView;
    private CarStatus carStatus;

    public StatusItemView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        LayoutInflater.from(getContext()).inflate(R.layout.view_auction_status_item, this);
        containerView = findViewById(R.id.containerView);
        textView = (TextView) findViewById(R.id.textView);
        imageView = (ImageView) findViewById(R.id.imageView);
    }

    public CarStatus getCarStatus() {
        return carStatus;
    }

    public void setCarStatus(CarStatus carStatus) {
        this.carStatus = carStatus;
        textView.setText(carStatus.getName());
    }

    @Override
    public void setSelected(boolean selected) {
        super.setSelected(selected);
        textView.setSelected(selected);
        if (selected) {
            imageView.setVisibility(VISIBLE);
        } else {
            imageView.setVisibility(GONE);
        }
    }
}
