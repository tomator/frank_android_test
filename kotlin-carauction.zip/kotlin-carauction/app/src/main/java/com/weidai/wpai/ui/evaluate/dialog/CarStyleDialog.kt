package com.weidai.wpai.ui.evaluate.dialog

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.extensions.show
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.ui.evaluate.adapter.StyleAdapter
import com.weidai.wpai.ui.evaluate.adapter.StyleGridAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.WindowUtil
import kotlinx.android.synthetic.main.car_dialog_style.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/16
 */

class CarStyleDialog(context: Context, top: Int, val brand: String, val model: String) : Dialog(context, R.style.Dialog_Fullscreen) {

    var adapter: StyleAdapter
    var gridAdapter: StyleGridAdapter? = null
    var allDatas: List<EvaluateCar> = ArrayList()
    var filterResult: List<EvaluateCar> = ArrayList()

    init {
        window!!.attributes.windowAnimations = R.style.DialogAnimRightIn
        setContentView(R.layout.car_dialog_style)
        var windowHeight = window!!.windowManager.defaultDisplay.height
        val realHeight = WindowUtil.getRealHeight(getContext())
        LogUtil.d("TOP_HEIGHT : realHeight = $realHeight, windowHeight = $windowHeight")
        windowHeight = if (realHeight > windowHeight) realHeight else windowHeight
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - top
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        requestData()
        leftShadowView.setOnClickListener { cancel() }
        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = StyleAdapter(context)
        recyclerView.adapter = adapter
        automaticTV.setOnClickListener { v -> onTypeClick(v) }
        manualTV.setOnClickListener { v -> onTypeClick(v) }
        setCanceledOnTouchOutside(true)
        RxBus.get().register(this)
        setOnDismissListener {
            RxBus.get().unregister(this)
        }
    }

    fun requestData() {
        Client.getService().carStyleList(brand, model)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<List<EvaluateCar>>>() {
                    override fun onSuccess(result: Result<List<EvaluateCar>>) {
                        result.data.let {
                            refreshView(result.data!!)
                        }
                    }
                })
    }

    fun refreshView(datas: List<EvaluateCar>) {
        allDatas = datas
        val outputList: MutableList<String> = ArrayList()
        datas.forEach {
            if (it.output!!.toDouble() > 0) {
                var outputData = "${it.output}${it.outputTye.show()}"
                if (outputData != null && !outputList.contains(outputData)) {
                    outputList.add(outputData)
                }
            }
        }
        if (outputList.size <= 6) {
            gridView.numColumns = 2
        } else if (outputList.size <= 9) {
            gridView.numColumns = 3
        } else {
            gridView.numColumns = 4
        }
        gridAdapter = StyleGridAdapter(context, outputList)
        gridView.adapter = gridAdapter
        gridAdapter!!.onItemSelectListener = object : StyleGridAdapter.OnItemSelectListener {
            override fun onItemSelcet(name: String) {
                filter()
            }
        }
        adapter.refreshDatas(datas)
    }

    fun onTypeClick(view: View) {
        if (!view.isSelected) {
            automaticTV.isSelected = false
            manualTV.isSelected = false
            view.isSelected = true
            filter()
        }
    }

    fun filter() {
        filterResult = allDatas
        if (automaticTV.isSelected) {
            filterResult = allDatas.filter { !"手动".equals(it.transmission) }
        }
        if (manualTV.isSelected) {
            filterResult = allDatas.filter { "手动".equals(it.transmission) }
        }
        if (gridAdapter != null) {
            if (!TextUtils.isEmpty(gridAdapter!!.selected)) {
                filterResult = filterResult.filter {
                    gridAdapter!!.selected!!.equals("${it.output}${it.outputTye.show()}")
                }
            }
        }
        adapter.refreshDatas(filterResult)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_EVALUATE)))
    fun onCarChoose(evaluateCar: EvaluateCar) {
        LogUtil.d(EventKey.TAG, "onCarChoose " + evaluateCar)
        cancel()
    }

}