package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.activity_base_tab.*

abstract class SimpleTabActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base_tab)
        initView()
    }

    protected abstract val tabContents: Array<String>

    protected abstract val fragments: Array<Fragment>

    private fun initView() {
        val fragments = fragments
        val tabContents = tabContents
        tabView.setContentView(tabContents)
        tabView.setOnCheckedLinstener { v, index -> viewpager.currentItem = index }
        viewpager.adapter = object : FragmentPagerAdapter(supportFragmentManager) {
            override fun getItem(position: Int): Fragment {
                return fragments[position]
            }

            override fun getCount(): Int {
                return fragments.size
            }
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}

            override fun onPageSelected(position: Int) {
                tabView.setCheckViewByIndex(position)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
    }
}
