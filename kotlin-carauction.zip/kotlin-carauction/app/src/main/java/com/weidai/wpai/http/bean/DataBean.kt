package com.weidai.wpai.http.bean

import com.github.promeg.pinyinhelper.Pinyin
import com.zaaach.citypicker.model.City
import java.io.Serializable
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/5
 */
data class AddressBean(val hotCitys: List<CityBean>?,
                       val provinces: List<ProvinceBean>?)

data class ApkUpdateBean(val createTime: String,
                         val info: String,
                         val isupdate: String,
                         val osType: String,
                         val url: String,
                         val version: String)

data class BalanceBean(val draw: Boolean,
                       val everyDrawCount: Int,
                       val rechargefee: Int,
                       val accountAmount: Double,
                       val freezeAmount: Double,
                       val availabeAmount: Double)

data class BankCardBean(val logo: String,
                        val cardName: String,
                        val fontColor: String,
                        val startColor: String,
                        val bankAccountNo: String,
                        val perDayMaxAmt: Double,
                        val bankName: String,
                        val endColor: String,
                        val cardType: String,
                        val perTxnMaxAmt: Double,
                        val bankAccountName: String,
                        val bankCode: String)

data class BannerBean(val id: Int,
                      val bannerUrl: String,
                      val bannerName: String,
                      val bannerImgUrl: String)

data class ConstantBean(val custommobile: String,
                        val registerfree: String,
                        val dayfree: String)

data class FunLogBean(val amount: Double,
                      val transSubName: String,
                      val gmtCreate: String,
                      val transSubType: Int) {
    companion object {
        const val TYPE_FREEZE = 1
        const val TYPE_UNFREEZE = 2
        const val TYPE_UNFREEZE_TO_PAY = 3
        const val TYPE_RECHARE = 4
        const val TYPE_WITHDRAWALS = 5
    }
}

data class NewRecordBean(val time: String,
                         val price: Double,
                         val priceString: String,
                         val status: Int,
                         val userName: String) {
    companion object {
        const val STATUS_COMPLETE = 1
    }
}

data class UserInfoBean(val hasPayPwd: String,
                        val userName: String,
                        val mobileNo: String
)

data class ProvinceBean(val id: String,
                        val name: String,
                        val cityList: List<CityBean>) {
    fun toCitys(): List<City> {
        val cities = ArrayList<City>()
        val city = City()
        city.id = id
        city.name = name
        city.pinyin = Pinyin.toPinyin(name, "")
        city.parentId = "-1"
        city.type = City.TYPE_PROVINCE
        cities.add(city)
        for (cityBean in cityList) {
            cities.add(cityBean.toCity(City.TYPE_CITY, id))
        }
        return cities
    }
}

data class CityBean(val id: String,
                    val name: String) {
    fun toCity(type: Int, parentId: String = "0"): City {
        val city = City()
        city.id = id
        city.name = name
        city.pinyin = Pinyin.toPinyin(name, "")
        city.parentId = parentId
        city.type = type
        return city
    }
}

data class MessageBean(val publish: String,
                       val title: String,
                       val content: String)

data class NoticeTipBean(val hasSysNotice: Boolean,
                         val hasUserNotice: Boolean,
                         val hasCouponNotice: Boolean)

data class VinResultBean(val modelName: String,
                         val carname: String,
                         val channel: String)

data class MaintenanceBean(val modelName: String,
                           val gmtCreate: String,
                           val failDesc: String,
                           val vin: String,
                           val state: Int,
                           val carname: String,
                           val orderId: String) {
    companion object {
        const val STATE_FINDING = 1
        const val STATE_SUCCESS = 2
        const val STATE_FAILED = 3
    }
}

data class InvitationInfoBean(val cmQueryCount: Int,
                              val freeCountPerDay: Int,
                              val freeCountPerInvitation: Int,
                              val invitationNumber: Int,
                              val userId: Int,
                              val serviceTel: String)

data class BrandBean(val brand_py: String,
                     val brand_name: String)

data class ModelBean(val name: String,
                     val type: Int)

/**
outBillNo	string	Y	外部订单号，需要短信验证码时有这个值
channelCode	string	Y	通道编码，需要短信验证码时有这个值
instCode	string	Y	渠道编码，需要短信验证码时有这个值
 */
data class RechargeBean(val outBillNo: String,
                        val channelCode: String,
                        val instCode: String) : Serializable




