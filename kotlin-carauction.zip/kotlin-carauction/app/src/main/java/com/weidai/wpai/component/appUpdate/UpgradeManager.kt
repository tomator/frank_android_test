package com.weidai.wpai.component.appUpdate

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Toast
import com.google.gson.Gson
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.util.LogUtil
import okhttp3.Response
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.io.File
import java.io.IOException

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/6
 */
class UpgradeManager(private val mContext: Activity, private val appUpgradleListener: UpgradeManager.AppUpgradleListener) {

    lateinit var upgradeDialog: UpgradeDialog

    fun checkVersion() {
        val path = BuildConfig.HTML_BASE_URL + "mmp/checkVersion"
        val appId = BuildConfig.APP_ID
        val platform = "2"  //2:android
        val channel = "guanfang"
        val requestUrl = "$path?appId=$appId&platform=$platform&channel=$channel"
        val subscriber = object : Subscriber<Response>() {
            override fun onError(e: Throwable) {
                e.printStackTrace()
                appUpgradleListener.failed(e.message)
            }

            override fun onNext(response: Response) {
                try {
                    var jsonString = response.body().string()
                    jsonString = jsonString.replace("\\\\n".toRegex(), "\n")
                    LogUtil.d("jsonString : " + jsonString)
                    val bean = Gson().fromJson(jsonString, AppVersionBean::class.java)
                    showUploadDialogByVersion(bean.d)
                } catch (e: IOException) {
                    e.printStackTrace()
                    appUpgradleListener.failed(e.message)
                }
            }

            override fun onCompleted() {

            }
        }
        HttpUtil.requestGet(requestUrl, subscriber)
    }

    private fun showUploadDialogByVersion(apkInfo: ApkInfo) {
        upgradeDialog = UpgradeDialog(mContext, apkInfo.versionInfo)
        upgradeDialog.setOnCommitListener(View.OnClickListener { downloadApp(apkInfo) })
        upgradeDialog.setOnCloseListener(View.OnClickListener { appUpgradleListener.failed("用户取消升级") })
        when (apkInfo.isForceUpdate(BuildConfig.VERSION_NAME)) {
            AppVersionBean.CHANGE_UPDATE -> {
                upgradeDialog.setCloseable(true)
                upgradeDialog.show()
            }
            AppVersionBean.FORCE_UPDATE -> {
                upgradeDialog.setCloseable(false)
                upgradeDialog.show()
            }
            AppVersionBean.UN_UPDATE -> appUpgradleListener.failed("不需要升级")
        }
    }

    private fun downloadApp(apkInfo: ApkInfo) {
        val file = File(mContext.externalCacheDir, "wpai.apk")
        file.deleteOnExit()
        val progressListener = object : Downloader.ProgressListener {
            override fun update(bytesRead: Long, contentLength: Long) {
                upgradeDialog.setProgress((bytesRead * 100 / contentLength).toInt())
            }
        }
        Downloader.downLoadFile(apkInfo.downloadUrl, file.path, progressListener)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<File>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {
                        appUpgradleListener.failed(e.message)
                        Toast.makeText(mContext, "下载app失败", Toast.LENGTH_SHORT).show()
                    }

                    override fun onNext(file: File) {
                        if (upgradeDialog != null) {
                            upgradeDialog.cancel()
                        }
                        mContext.finish()
                        installApk(mContext, file.path)
                    }
                })
    }

    private fun installApk(context: Context, filePath: String) {
        val apkFile = File(filePath)
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive")
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
    }

    interface AppUpgradleListener {
        fun failed(msg: String?)
    }
}
