package com.weidai.wpai.ui.fragment

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.bean.*
import com.weidai.wpai.ui.activity.AllRecordActivity
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.ui.activity.MyCouponActivity
import com.weidai.wpai.ui.adapter.AuctionBannerAdapter
import com.weidai.wpai.ui.dialog.AuctionBidDiaog
import com.weidai.wpai.ui.dialog.AuctionHideBidDialog
import com.weidai.wpai.ui.evaluate.activity.EvaluateActivity
import com.weidai.wpai.util.CallUtil
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.fragment_auction.*


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/21
 */
class AuctionFragment : BaseFragment() {

    lateinit var helper: AuctionHelper
    lateinit var layoutInflater: LayoutInflater
    var auctionBean: AuctionBean? = null
    var isDeposed = false
    var isLogin = false
    var isBindCard = false
    var isSetPayPwd = false
    var useableBalance = 0.0
    var curPrice = 0.0
    var userLastPrice = 0.0
    var lastEndTime: Long = 0
    var orderNo: String? = null
    var auctionBidDiaog: AuctionBidDiaog? = null
    var hideBidDialog: AuctionHideBidDialog? = null
    lateinit var bidLL: View
    lateinit var bidTV: TextView
    lateinit var fixedTV: TextView

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_auction, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        layoutInflater = LayoutInflater.from(context)
        helper = AuctionHelper(this)
        helper.requestAuctionBase()
        refreshUserInfo()
        if (isLogin && !isBindCard) {
            UserManager.instance.reqeustBindCardInfo()
        }
        if (isBindCard && isSetPayPwd) {
            UserManager.instance.reqeustUserBalance()
        }
        bidLL = (context as AuctionActivity).getBidLL()
        bidTV = (context as AuctionActivity).getBidTV()
        fixedTV = (context as AuctionActivity).getFixedTV()
        showAllTV.setOnClickListener {
            auctionBean?.let {
                AllRecordActivity.gotoThis(context, auctionBean!!.auctionNo)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LogUtil.d("AuctionFragment", "onDestroy")
        helper.stopWatch()
    }

    fun refreshUserInfo() {
        isLogin = UserManager.instance.isUserLogin
        isBindCard = UserManager.instance.hasBindCard()
        isSetPayPwd = UserManager.instance.hasPayPwd()
        if (auctionBean != null) {
            refreshBidBtn(auctionBean!!)
        }
    }

    fun refreshView(auctionBean: AuctionBean) {
        this.auctionBean = auctionBean
        isDeposed = !TextUtils.isEmpty(auctionBean.orderNO)
        lastEndTime = DateUtil.parse(auctionBean.endTime)
        orderNo = auctionBean.orderNO
        curPrice = auctionBean.curPrice
        userLastPrice = auctionBean.userLastPrice
        if (isLogin) {
            refreshUserInfo()
        } else {
            refreshBidBtn(auctionBean)
        }
        inputData(auctionBean)
        refreshByStatus(auctionBean)
        refreshByMode()
        showCoupon()
    }

    fun inputData(auctionBean: AuctionBean) {
        updateBanners(auctionBean.picPath)
        titleTV.text = auctionBean.title
        currentPriceTV.text = FormatUtil.getChineseMoney(auctionBean.curPrice)
        startPriceTV.text = FormatUtil.getChineseMoney(auctionBean.startPrice)
        incrementTV.text = FormatUtil.getChineseMoney(auctionBean.increment)
        depositTV.text = FormatUtil.getChineseMoney(auctionBean.deposit)
        delaytimeTV.text = auctionBean.delaytime.toString() + "分钟/次"
        guidePriceTV.text = FormatUtil.getWan00(auctionBean.guidePrice)
        assessPriceTV.text = FormatUtil.getWan00(auctionBean.assessPrice)
        val hour = auctionBean.auctionDuration / 60
        val minute = auctionBean.auctionDuration % 60
        var auctionDuration = ""
        if (hour > 0) {
            auctionDuration += "${hour}小时"
        }
        if (minute > 0) {
            auctionDuration += "${minute}分"
        }
        auctionDurationTV.text = auctionDuration
        hasLimitPriceTV.text = if (auctionBean.hasLimitPrice) "有" else "无"
        if (auctionBean.fixedPrice > 0) {
            fixedPriceLL.visibility = View.VISIBLE
            fixedPriceTV.text = FormatUtil.getChineseMoney(auctionBean.fixedPrice)
        } else {
            fixedPriceLL.visibility = View.GONE
        }
        refreshRecords(auctionBean)
        refreshRecordInfo(auctionBean.peopleNumber, auctionBean.auctionNumber)
    }

    fun refreshByWatch(watchBean: AuctionBean) {
        orderNo = watchBean.orderNO
        curPrice = watchBean.curPrice
        currentPriceTV.text = "￥" + FormatUtil.getFormateMoney(watchBean.curPrice)
        if (auctionBidDiaog != null) {
            auctionBidDiaog!!.setBasePrice(watchBean.curPrice)
        }
        if (watchBean.auctionDetailStatus != AuctionBean.STATUS_AUCTIONING) {
            helper.requestAuctionBase()
        }
        val endTime = DateUtil.parse(watchBean.endTime)
        val interval = endTime - lastEndTime
        if (interval > 10 * 1000 && lastEndTime !== 0L) {
            val remainTime = countDownView.remainTime
            countDownView.start(remainTime + interval)
        }
        lastEndTime = endTime

        refreshRecords(watchBean)
        refreshByMode()
        refreshRecordInfo(watchBean.peopleNumber, watchBean.auctionNumber)
    }

    internal fun bidSuccess(price: Double) {
        if (auctionBean!!.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
            hideBidDialog?.let {
                hideBidDialog!!.cancel()
                hideBidDialog = null
            }
            userLastPrice = price
        }
        auctionBidDiaog?.let {
            if (auctionBidDiaog!!.isShowing) {
                auctionBidDiaog!!.cancel()
            }
        }
    }

    private fun refreshByMode() {
        if (auctionBean!!.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
            currentPriceTV.text = "￥"
            priceCoverIV.visibility = View.VISIBLE
            delaytimeTV.text = "无"
            addRangeLL.visibility = View.GONE
        } else {
            priceCoverIV.visibility = View.GONE
            addRangeLL.visibility = View.VISIBLE
        }
    }

    private fun showCoupon() {
        couponLL.visibility = View.GONE
        if (isLogin && auctionBean!!.unusedCouponCount > 0) {
            when (auctionBean!!.auctionDetailStatus) {
                AuctionBean.STATUS_AUCTIONING -> showCouponInfo()
                AuctionBean.STATUS_NOT_START -> showCouponInfo()
                AuctionBean.STATUS_AUCTION_WIN -> {
                    if (TextUtils.isEmpty(auctionBean!!.couponInfo)) {
                        showCouponInfo()
                    }
                }
            }
        }
    }

    private fun showCouponInfo() {
        couponLL.visibility = View.VISIBLE
        var couponStr = "您有 ${auctionBean!!.unusedCouponCount} 张提车优惠券未使用"
        val len = auctionBean!!.unusedCouponCount.toString().length
        val span = SpannableString(couponStr)
        val fColorSpan = ForegroundColorSpan(Color.parseColor("#F9504A"))
        span.setSpan(fColorSpan, 3, 3 + len, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
        couponTV.text = span
        couponLL.setOnClickListener {
            startActivity(Intent(context, MyCouponActivity::class.java))
        }
    }

    private fun refreshBidBtn(auctionBean: AuctionBean) {
        fixedTV.visibility = View.GONE
        when (auctionBean.auctionDetailStatus) {
            AuctionBean.STATUS_NOT_START -> {
                bidTV.isSelected = false
                if (isDeposed) {
                    bidTV.text = "等待开拍"
                    if (auctionBean.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
                        bidTV.setBackgroundResource(R.color.text_dark_black)
                    }
                } else {
                    bidTV.text = "提前报名"
                    bidTV.isSelected = true
                    if (auctionBean.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
                        bidTV.setBackgroundResource(R.color.text_dark_black)
                        bidTV.text = "暗拍提前报名"
                    }
                }
            }
            AuctionBean.STATUS_AUCTIONING -> {
                bidTV.isSelected = true
                if (isDeposed) {
                    if (auctionBean.fixedPrice > 0) {
                        fixedTV.visibility = View.VISIBLE
                    }
                    bidTV.text = "出价"
                    if (auctionBean.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
                        bidTV.setBackgroundResource(R.color.text_dark_black)
                        bidTV.text = "暗拍报价"
                        if (userLastPrice > 0) {
                            bidTV.text = "更改报价"
                        }
                    }
                } else {
                    bidTV.text = "报名出价"
                    if (auctionBean.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
                        bidTV.setBackgroundResource(R.color.text_dark_black)
                        bidTV.text = "暗拍报名出价"
                    }
                }
            }
            AuctionBean.STATUS_AUCTION_FAILED -> {
                bidLL.visibility = View.GONE
            }
            AuctionBean.STATUS_AUCTION_END -> {
                bidLL.visibility = View.GONE
            }
            AuctionBean.STATUS_AUCTION_WIN -> {
                bidLL.visibility = View.VISIBLE
                bidTV.isSelected = true
                bidTV.text = "联系客服"
            }
            AuctionBean.STATUS_AUCTION_WIN_DOWN -> {
                bidLL.visibility = View.GONE
            }
            AuctionBean.STATUS_AUCTION_WIN_FAILED -> {
                bidLL.visibility = View.GONE
            }
        }
    }


    fun refreshByStatus(auctionBean: AuctionBean) {
        when (auctionBean.auctionDetailStatus) {
            AuctionBean.STATUS_NOT_START -> statusNotStart()
            AuctionBean.STATUS_AUCTIONING -> statusStarting()
            AuctionBean.STATUS_AUCTION_FAILED -> {
                hidePriceInfo()
                currentPriceHint.text = "最高价"
                if (TextUtils.isEmpty(auctionBean.orderNO)) {
                    statusFinished()
                    showOrderInfo(false)
                    timeRemainTV.text = "车辆流拍"
                } else {
                    showOrderInfo(true)
                    refreshByTradeStatus(auctionBean!!.auctionDetailStatus)
                }
                helper.stopWatch()
            }
            AuctionBean.STATUS_AUCTION_END -> {
                hidePriceInfo()
                currentPriceHint.text = "成交价"
                if (TextUtils.isEmpty(auctionBean.orderNO)) {
                    statusFinished()
                    showOrderInfo(false)
                    timeRemainTV.text = "车辆成交"
                } else {
                    showOrderInfo(true)
                    refreshByTradeStatus(auctionBean!!.auctionDetailStatus)
                }
                helper.stopWatch()
            }
            AuctionBean.STATUS_AUCTION_WIN -> {
                currentPriceHint.text = "成交价"
                hidePriceInfo()
                showOrderInfo(true)
                refreshByTradeStatus(auctionBean!!.auctionDetailStatus)
                helper.stopWatch()
            }
            AuctionBean.STATUS_AUCTION_WIN_DOWN -> {
                currentPriceHint.text = "成交价"
                hidePriceInfo()
                showOrderInfo(true)
                refreshByTradeStatus(auctionBean!!.auctionDetailStatus)
            }
            AuctionBean.STATUS_AUCTION_WIN_FAILED -> {
                currentPriceHint.text = "成交价"
                hidePriceInfo()
                showOrderInfo(true)
                refreshByTradeStatus(auctionBean!!.auctionDetailStatus)
            }
        }
    }

    private fun statusNotStart() {
        timeCountLL.setBackgroundResource(R.mipmap.bg_auction_not_start)
        if (auctionBean!!.remainingStartTime > THREE_HOUR) {
            timeInfoTV.text = "开始时间"
            countDownView.visibility = View.GONE
            timeRemainTV.visibility = View.VISIBLE
            timeRemainTV.text = DateUtil.getYYMdHm(auctionBean!!.startTime)
        } else {
            timeInfoTV.text = "即将开始"
            countDownView.visibility = View.VISIBLE
            timeRemainTV.visibility = View.GONE
            countDownView.start(auctionBean!!.remainingStartTime * 1000L)
            countDownView.setOnCountdownEndListener { helper.requestAuctionBase() }
        }
        showOrderInfo(false)
        (context as AuctionActivity).remindShow(true)
        (context as AuctionActivity).remindSelect(!auctionBean!!.addRemind)
    }

    private fun statusStarting() {
        timeCountLL.setBackgroundResource(R.mipmap.bg_auction_starting)
        timeInfoTV.text = "距离结束"
        countDownView.visibility = View.VISIBLE
        timeRemainTV.visibility = View.GONE
        countDownView.start(auctionBean!!.remainingEndTime * 1000L)
        countDownView.setOnCountdownEndListener { helper.requestAuctionBase() }
        helper.startWatch()
        showOrderInfo(false)
        (context as AuctionActivity).remindShow(false)
    }

    private fun statusFinished() {
        timeCountLL.setBackgroundResource(R.mipmap.bg_auction_finished)
        timeInfoTV.text = "已结束"
        countDownView.visibility = View.GONE
        timeRemainTV.setTextColor(resources.getColor(R.color.text_light_black))
    }

    private fun hidePriceInfo() {
        fixedPriceLL.visibility = View.GONE
        guidePriceLL.visibility = View.GONE
        assessPriceLL.visibility = View.GONE
    }

    private fun refreshByTradeStatus(status: Int) {
        tradeStatusTV.setBackgroundResource(R.drawable.bg_radiu_3_666666)
        tradeExplainTV.setTextColor(resources.getColor(R.color.text_light_black))
        tradeStatusLL.setBackgroundResource(R.color.E0E0E0)
        when (status) {
            AuctionBean.STATUS_AUCTION_FAILED -> {
                tradeStatusTV.text = "已结束"
                tradeExplainTV.text = "竞拍结束，您未能成功竞拍，保证金我们将原路退回给您，敬请留意。"
            }
            AuctionBean.STATUS_AUCTION_END -> {
                tradeStatusTV.text = "已结束"
                tradeExplainTV.text = "未达到保留价，车辆流拍。"
            }
            AuctionBean.STATUS_AUCTION_WIN -> {
                tradeExplainTV.setTextColor(resources.getColor(R.color.main_blue))
                tradeStatusTV.setBackgroundResource(R.drawable.bg_radiu_3_blue)
                tradeStatusLL.setBackgroundResource(R.color.ECF6FF)
                tradeStatusTV.text = "已成交"
                tradeExplainTV.text = "您的订单已生效，我们工作人员会尽快跟您联系。"
            }
            AuctionBean.STATUS_AUCTION_WIN_DOWN -> {
                tradeExplainTV.setTextColor(resources.getColor(R.color.main_blue))
                tradeStatusTV.setBackgroundResource(R.drawable.bg_radiu_3_blue)
                tradeStatusLL.setBackgroundResource(R.color.ECF6FF)
                tradeStatusTV.text = "交易完成"
                tradeExplainTV.text = "已提车"
            }
            AuctionBean.STATUS_AUCTION_WIN_FAILED -> {
                tradeStatusTV.text = "交易失败"
                tradeExplainTV.text = "提车未成功"
            }
        }
    }

    private fun initOrderInfo(auctionBean: AuctionBean) {
        val builder = StringBuilder()
        builder.append(auctionBean.auctionNo)
        builder.append("\n").append(auctionBean.endTime)
        builder.append("\n").append(FormatUtil.getChineseMoney(auctionBean.startPrice))
        orderNoTV.text = auctionBean.auctionNo
        endTimeTV.text = auctionBean.endTime
        firstPriceTV.text = FormatUtil.getChineseMoney(auctionBean.startPrice)
        depositInfoTV.text = FormatUtil.getChineseMoney(auctionBean.deposit)
        if (TextUtils.isEmpty(auctionBean.couponInfo)) {
            couponInfoLL.visibility = View.GONE
        } else {
            couponInfoLL.visibility = View.VISIBLE
            couponInfoTV.text = auctionBean.couponInfo
        }
        if (TextUtils.isEmpty(auctionBean.reducedPrice)) {
            reducedPriceLL.visibility = View.GONE
        } else {
            reducedPriceLL.visibility = View.VISIBLE
            reducedPriceTV.text = FormatUtil.getChineseMoney(auctionBean.reducedPrice)
        }
        if (TextUtils.isEmpty(auctionBean.takeCarPrice)) {
            takeCarPriceLL.visibility = View.GONE
        } else {
            takeCarPriceLL.visibility = View.VISIBLE
            takeCarPriceTV.text = FormatUtil.getChineseMoney(auctionBean.takeCarPrice)
        }
    }

    private fun showOrderInfo(isShow: Boolean) {
        if (isShow) {
            auctionInfoLL.visibility = View.GONE
            orderInfoLL.visibility = View.VISIBLE
            timeCountLL.visibility = View.GONE
            tradeStatusLL.visibility = View.VISIBLE
            initOrderInfo(auctionBean!!)
        } else {
            auctionInfoLL.visibility = View.VISIBLE
            orderInfoLL.visibility = View.GONE
            timeCountLL.visibility = View.VISIBLE
            tradeStatusLL.visibility = View.GONE
        }
    }

    private fun updateBanners(list: List<String>) {
        if (list != null && list.size > 0) {
            val adapter = AuctionBannerAdapter(context, list)
            bannerView.setAdapter(adapter, rg_Splash)
        }
    }

    private fun refreshRecords(recordsBean: AuctionBean) {
        if (recordsBean.newsRecord == null || recordsBean.newsRecord.size == 0) {
            recordLL.visibility = View.GONE
            recordEmptyView.visibility = View.VISIBLE
            recordInfoLL.visibility = View.INVISIBLE
        } else {
            recordLL.visibility = View.VISIBLE
            recordEmptyView.visibility = View.GONE
            recordInfoLL.visibility = View.VISIBLE
            showRecords(recordsBean.newsRecord)
        }
    }

    private fun refreshRecordInfo(peopleNumber: Int, auctionNumber: Int) {
        peopleNumberTV.text = peopleNumber.toString()
        auctionNumberTV.text = auctionNumber.toString()
    }

    private fun showRecords(recordList: List<NewRecordBean>) {
        var recordList = recordList
        recordContainer.removeAllViews()
        if (recordList.size > 3) {
            recordList = recordList.subList(0, 3)
        }
        recordList.forEach {
            val view = layoutInflater.inflate(R.layout.view_auction_record_item, recordContainer, false)
            val dateTV = view.findViewById(R.id.dateTV) as TextView
            val phoneTV = view.findViewById(R.id.phoneTV) as TextView
            val bidPriceTV = view.findViewById(R.id.bidPriceTV) as TextView
            dateTV.text = DateUtil.getMMddHHmm(it.time)
            phoneTV.text = FormatUtil.getDisplayMobile(it.userName)
            bidPriceTV.text = "出价: ￥" + it.priceString
            recordContainer.addView(view)
        }
    }

    fun onBidClick() {
        if (!isLogin) {
            UserManager.instance.turn2Login()
            return
        }
        if (auctionBean == null) {
            return
        }
        if (auctionBean!!.auctionDetailStatus == AuctionBean.STATUS_AUCTION_WIN) {
            contactCustomerService()
            return
        }
        if (auctionBean!!.auctionDetailStatus > AuctionBean.STATUS_AUCTIONING) {
            return
        }
        if (!isBindCard) {
            helper.showBindCardDialog()
            return
        }
        if (!isDeposed) {
            if (useableBalance < auctionBean!!.deposit) {
                helper.showRechargeDialog()
                return
            } else {
                helper.showDepositDialog()
                return
            }
        }
        if (auctionBean!!.auctionDetailStatus == AuctionBean.STATUS_AUCTIONING) {
            if (auctionBean!!.auctionMode == AuctionBean.AUCTION_MODE_HIDE) {
                showHideBidDialog()
            } else {
                showBidDialog()
            }
        }
    }

    fun onRemindClick() {
        if (isLogin) {
            helper.remind(auctionBean!!.auctionNo, !auctionBean!!.addRemind)
        } else {
            UserManager.instance.turn2Login()
        }
    }

    fun onFixedClick() {
        helper.showBidConfirmDialog(orderNo!!, auctionBean!!.fixedPrice, true)
    }

    private fun contactCustomerService() {
        CallUtil.callService(context as Activity)
    }

    private fun showBidDialog() {
        auctionBidDiaog = AuctionBidDiaog(context,
                curPrice, auctionBean!!.increment)
        auctionBidDiaog!!.show()
        auctionBidDiaog!!.setOnCommitLister(object : AuctionBidDiaog.OnCommitLister {
            override fun onCommit(price: Double) {
                helper.showBidConfirmDialog(orderNo!!, price)
            }
        })
    }

    private fun showHideBidDialog() {
        hideBidDialog = AuctionHideBidDialog(context,
                auctionBean!!.startPrice, userLastPrice)
        hideBidDialog!!.show()
        hideBidDialog!!.setOnCommitLister(object : AuctionHideBidDialog.OnCommitLister {
            override fun onCommit(price: Double) {
                helper.showBidConfirmDialog(orderNo!!, price)
            }
        })
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_LOGIN_SUCCESS)))
    fun onUserLogin(success: Boolean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onUserLogin " + success)
        refreshUserInfo()
        helper.requestAuctionBase()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_BIND_CARD_SUCCESS)))
    fun onBindCard(success: Boolean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onBindCard " + success)
        refreshUserInfo()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_GET_CARD_INFO)))
    fun onGetCardInfo(bankCard: BankCardBean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onGetCardInfo " + bankCard)
        refreshUserInfo()
        if (isLogin && isSetPayPwd && isBindCard) {
            UserManager.instance.reqeustUserBalance()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_GET_BALANCE)))
    fun onGetBalance(balanceBean: BalanceBean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onGetBalance " + balanceBean)
        useableBalance = balanceBean!!.availabeAmount
        refreshUserInfo()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_RECHARGE_RESULT)))
    fun onRecharge(result: Boolean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onRecharge " + result!!)
        if (result) {
            UserManager.instance.reqeustUserBalance()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CAR_DETAIL_INFO)))
    fun onCarInfo(result: CarInfoBean?) {
        LogUtil.d(EventKey.TAG, " AuctionFragment onCarInfo $result")
        result?.let {
            if (!TextUtils.isEmpty(result.vin)) {
                evaluateLL.visibility = View.VISIBLE
                evaluateLL.setOnClickListener {
                    startActivity(Intent(context, EvaluateActivity::class.java)
                            .putExtra("CarInfoBean", result))
                }
            } else {
                evaluateLL.visibility = View.GONE
            }
        }
    }

    companion object {
        private val THREE_HOUR = 3 * 3600
    }
}
