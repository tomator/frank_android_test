package com.weidai.wpai.ui.dialog

import android.content.Context
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.EventKey.KEY_FILTER_DIALOG_DISMISS
import com.weidai.wpai.ui.model.CarAge
import com.weidai.wpai.ui.view.RangeSeekbar
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.dialog_years_picker.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/13
 */
class YearsPickerDailog(context: Context, baseView: View)
    : BaseFilterDialog(context, baseView) {

    private val size: Int
    var markArray: Array<String>
    private val carAge = CarAge()
    private var left: Int = 0
    private var right: Int = 0
    private var oldLeft: Int = 0
    private var oldRight: Int = 0

    init {
        markArray = context.resources.getStringArray(R.array.markArray)
        size = markArray.size
        rangeSeekbar.setTextMarks(*markArray)
        left = 0
        right = size - 1
        setPickString()
        rangeSeekbar.setOnCursorChangeListener(object : RangeSeekbar.OnCursorChangeListener {
            override fun onLeftCursorChanged(location: Int, textMark: String) {
                left = location
                setPickString()
            }

            override fun onRightCursorChanged(location: Int, textMark: String) {
                right = location
                setPickString()
            }
        })
        setOnShowListener {
            oldLeft = left
            oldRight = right
            rangeSeekbar.setLeftSelection(left)
            rangeSeekbar.setRightSelection(right)
            setPickString()
            LogUtil.d("onShow : $oldLeft , $oldRight , $left , $right")
        }

        setOnDismissListener {
            RxBus.get().post(KEY_FILTER_DIALOG_DISMISS, dialogThis)
            left = oldLeft
            right = oldRight
            LogUtil.d("onDismiss : $oldLeft , $oldRight , $left , $right")
        }
        onViewClicked()
    }

    private fun setPickString() {
        val pickString: String
        if (left == 0) {
            if (right == size - 1) {
                pickString = "不限"
            } else {
                pickString = markArray[right] + "年以内"
            }
        } else {
            if (right == size - 1) {
                pickString = markArray[left] + "年以上"
            } else {
                pickString = markArray[left] + "-" + markArray[right] + "年"
            }
        }
        carAge.left = markArray[left]
        if (right == size - 1) {
            carAge.right = "0"
        } else {
            carAge.right = markArray[right]
        }
        carAge.name = pickString
        pickedTV.text = pickString
    }

    override fun getLayoutRes(): Int {
        return R.layout.dialog_years_picker
    }

    override fun initView() {

    }

    fun onViewClicked() {
        confirmBtn.setOnClickListener {
            oldLeft = left
            oldRight = right
            RxBus.get().post(EventKey.KEY_CHOOSE_CAR_AGE, carAge)
        }
        shadowView.setOnClickListener { dismiss() }
    }
}
