package com.weidai.wpai.util;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;

import com.weidai.wpai.util.preferences.SpfUtils;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/24
 */
public class CallUtil {

    public static void call(final Activity activity, final String phoneNumber) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CALL_PHONE}, 100);
        } else {
            Uri uri = Uri.parse("tel:" + phoneNumber);
            Intent intent = new Intent(Intent.ACTION_CALL, uri);
            activity.startActivity(intent);
        }
    }

    public static void callService(Activity activity) {
        String serviceNo = SpfUtils.getInstance().getServiceNo();
        call(activity, serviceNo);
    }
}
