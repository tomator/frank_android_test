package com.weidai.wpai.ui.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v4.view.ViewPager
import android.text.TextUtils
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.appUpdate.UpgradeManager
import com.weidai.wpai.http.bean.NoticeTipBean
import com.weidai.wpai.ui.adapter.HomeViewPagerAdapter
import com.weidai.wpai.ui.model.PushBean
import com.weidai.wpai.ui.view.HomeTabbar
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : BaseActivity() {

    var homeViewPagerAdapter: HomeViewPagerAdapter? = null
    private var noticeTip: NoticeTipBean? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        setStatusBar()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initTabBar()
        homeViewPagerAdapter = HomeViewPagerAdapter(supportFragmentManager, this)
        viewpager.adapter = homeViewPagerAdapter
        viewpager.offscreenPageLimit = 3
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                tabbar.setItemSelected(position)
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        checkPermission()
        needShowMyPoint(noticeTip)
        App.instance.requestNewMessage()
        judgeApk2Update()
        checkTarget(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        judgeApk2Update()
        intent?.let {
            checkTarget(intent)
        }
    }

    fun checkTarget(intent: Intent) {
        var target = intent.getStringExtra("target")
        if (!TextUtils.isEmpty(target)) {
            when (target) {
                "native://notice" -> startActivity(Intent(this, MessageActivity::class.java))
                "tab://1" -> setCurrentItem(1)
                "native://myCoupon" -> startActivity(Intent(this, MyCouponActivity::class.java))
            }
            if (target.startsWith("native://auctionDetail")) {
                var index = target.lastIndexOf("=") + 1
                var auctionNo = target.substring(index)
                AuctionActivity.gotoThis(this, auctionNo)
            }
            if(target.startsWith("http")){
                WPWebActivty.open(this, target)
            }
        }
    }

    fun setStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            StatusBarCompat.translucentStatusBar(this)
        }
    }

    private fun initTabBar() {
        tabbar.addDefaultItems()
        tabbar.setItemSelected(0)
        tabbar.setOnItemClickListener(object : HomeTabbar.OnItemClickListener {
            override fun onItemClick(position: Int) {
                viewpager.currentItem = position
            }
        })

    }

    override fun onResume() {
        super.onResume()
    }

    private fun checkPermission() {
        val permission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val readPhoneState = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
        if (permission == PackageManager.PERMISSION_DENIED
                || readPhoneState == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.READ_PHONE_STATE), 1000)
        }
    }

    fun setCurrentItem(index: Int) {
        viewpager.currentItem = index
        tabbar.setItemSelected(index)
    }

    fun showPoint(position: Int, isShow: Boolean) {
        tabbar.showHideDot(position, isShow)
    }

    fun needShowMyPoint(noticeTipBean: NoticeTipBean?) {
        var show = !SpfUtils.getInstance().getBoolean(SpfKey.MAINTENANCE_HAS_READED, false)
        show = show || !SpfUtils.getInstance().getBoolean(SpfKey.EVALUATE_HAS_READED, false)
        if (noticeTipBean != null) {
            this.noticeTip = noticeTipBean
        }
        if (noticeTip != null) {
            show = show || noticeTip!!.hasSysNotice
                    || noticeTip!!.hasUserNotice
                    || noticeTip!!.hasCouponNotice
        }
        tabbar.showHideDot(2, show)
    }

    private fun judgeApk2Update() {
        val upgradeManager = UpgradeManager(this, object : UpgradeManager.AppUpgradleListener {
            override fun failed(msg: String?) {

            }
        })
        upgradeManager.checkVersion()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_NOTICE_TIP)))
    fun onNoticeTip(noticeTip: NoticeTipBean) {
        LogUtil.d(EventKey.TAG, "onNoticeTip " + noticeTip)
        needShowMyPoint(noticeTip)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_PUSH_DATA)))
    fun onPushData(pushBean: PushBean) {
        tabbar.showHideDot(2, true)
    }
}
