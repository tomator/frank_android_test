package com.weidai.wpai.ui.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.hwangjr.rxbus.RxBus;
import com.hwangjr.rxbus.annotation.Subscribe;
import com.hwangjr.rxbus.annotation.Tag;
import com.weidai.wpai.App;
import com.weidai.wpai.R;
import com.weidai.wpai.common.EventKey;
import com.weidai.wpai.component.cityPick.LocateState;
import com.weidai.wpai.component.cityPick.adapter.ProvinceListAdapter;
import com.weidai.wpai.component.cityPick.db.City;
import com.weidai.wpai.component.cityPick.db.DBManager;
import com.weidai.wpai.util.LogUtil;
import com.weidai.wpai.util.preferences.SpfKey;
import com.weidai.wpai.util.preferences.SpfUtils;
import com.zaaach.citypicker.view.SideLetterBar;

import java.util.ArrayList;
import java.util.List;

import static com.weidai.wpai.common.EventKey.KEY_FILTER_DIALOG_DISMISS;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/10
 */
public class CityPickerDialog extends BaseFilterDialog {
    private ListView mListView;
    private ProvinceListAdapter mCityAdapter;
    private SideLetterBar mLetterBar;
    private List<City> mAllCities = new ArrayList<>();
    private List<City> mHotCities = new ArrayList<>();
    private DBManager dbManager;
    private OnDismissListener defaultLister = new OnDismissListener() {
        @Override
        public void onDismiss(DialogInterface dialog) {
            RxBus.get().post(KEY_FILTER_DIALOG_DISMISS, dialogThis);
        }
    };

    public CityPickerDialog(@NonNull Context context, View baseView) {
        super(context, baseView);
        RxBus.get().register(CityPickerDialog.this);
    }

    @Override
    protected int getLayoutRes() {
        return R.layout.cp_dialog_city_list;
    }

    @Override
    protected void initView() {
        refresh();
        if (App.Companion.getInstance().getLocationCity() == null) {
            App.Companion.getInstance().startLocation();
        } else {
            mCityAdapter.updateLocateState(LocateState.SUCCESS, App.Companion.getInstance().getLocationCity());
        }
        setOnDismissListener(defaultLister);
    }

    private void refresh() {
        initData();
        initList();
    }

    private void initList() {
        mListView = (ListView) findViewById(R.id.listview_all_city);
        mListView.setAdapter(mCityAdapter);
        TextView overlay = (TextView) findViewById(R.id.tv_letter_overlay);
        mLetterBar = (SideLetterBar) findViewById(R.id.side_letter_bar);
        mLetterBar.setOverlay(overlay);
        mLetterBar.setOnLetterChangedListener(new SideLetterBar.OnLetterChangedListener() {
            @Override
            public void onLetterChanged(String letter) {
                int position = mCityAdapter.getLetterPosition(letter);
                mListView.setSelection(position);
            }
        });
        findViewById(R.id.cancel_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    private void initData() {
        dbManager = new DBManager(getContext());
        mAllCities = dbManager.getProvinces();
        mHotCities = dbManager.getCitys(SpfUtils.getInstance().getStringList(SpfKey.HOT_CITY_COMMON));
        mCityAdapter = new ProvinceListAdapter(getContext(), mAllCities, mHotCities);
        mCityAdapter.setOnCityClickListener(new ProvinceListAdapter.OnCityClickListener() {
            @Override
            public void onCityClick(City city) {
                RxBus.get().post(EventKey.KEY_CHOOSE_CITY, city);
            }

            @Override
            public void onLocateClick() {
                mCityAdapter.updateLocateState(LocateState.LOCATING, null);
                App.Companion.getInstance().startLocation();
            }
        });
    }

    @Subscribe(tags = {@Tag(EventKey.KEY_GET_CITYS_RESULT)})
    public void onGetCitys(Boolean success) {
        LogUtil.d(EventKey.TAG, "onGetCitys " + success);
        if (success) {
            refresh();
        }
    }

    @Subscribe(tags = {@Tag(EventKey.KEY_LOCATION_CITY)})
    public void onGetLocationCity(City city) {
        LogUtil.d(EventKey.TAG, "onGetLocationCity " + city);
        if (city == null || City.Companion.getID_NULL().equals(city.getId())) {
            mCityAdapter.updateLocateState(LocateState.FAILED, null);
        } else {
            mCityAdapter.updateLocateState(LocateState.SUCCESS, city);
        }
    }

}
