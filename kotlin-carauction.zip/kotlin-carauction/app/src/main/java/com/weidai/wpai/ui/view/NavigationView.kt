package com.weidai.wpai.ui.view

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.support.annotation.DrawableRes
import android.support.annotation.StringRes
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.RelativeLayout
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.view_navigation.view.*

/**
 * Created by bici on 16/4/18.
 */
class NavigationView @JvmOverloads constructor(context: Context, attributeSet: AttributeSet? = null) : RelativeLayout(context, attributeSet) {

    init {
        init()
    }

    private fun init() {
        LayoutInflater.from(context).inflate(R.layout.view_navigation, this)
        backBtn.setOnClickListener {
            try {
                (context as Activity).onBackPressed()
            } catch (e: Exception) {
            }
        }
    }

    fun setThemeColor(resId: Int) {
        containerView.setBackgroundResource(resId)
        backBtn.setImageResource(R.mipmap.ic_nav_back_white)
        titleView.setTextColor(Color.WHITE)
        nextTV.setTextColor(Color.WHITE)
    }

    fun setTitle(@StringRes resId: Int) {
        setTitle(context.getString(resId))
    }

    fun setTitle(title: String) {
        titleView.text = title
    }

    fun setNextRes(@DrawableRes resId: Int) {
        nextBtn.visibility = View.VISIBLE
        nextBtn.setImageResource(resId)
    }

    fun setNextText(text: String, onClickListener: View.OnClickListener) {
        nextTV.visibility = View.VISIBLE
        nextTV.text = text
        nextTV.setOnClickListener(onClickListener)
    }

    fun setOnBackClickListener(onClickListener: View.OnClickListener) {
        backBtn.setOnClickListener(onClickListener)
    }

    fun setOnNextClickListener(onClickListener: View.OnClickListener) {
        nextBtn.setOnClickListener(onClickListener)
    }

    fun setOnIncomeClickListener(onClickListener: View.OnClickListener) {
        tvIncomeDetail.setOnClickListener(onClickListener)
    }

    fun hideBack() {
        backBtn.visibility = View.GONE
    }

    fun setIncomeVisable(isVisiable: Boolean) {
        tvIncomeDetail.visibility = if (isVisiable) View.VISIBLE else View.GONE
    }

}
