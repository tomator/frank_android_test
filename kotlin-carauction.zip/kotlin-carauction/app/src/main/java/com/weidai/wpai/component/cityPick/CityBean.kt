package com.weidai.wpai.component.cityPick

import com.weidai.wpai.component.cityPick.db.City

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/22
 */

/**
{
"code": 110000,
"parentCode": 0,
"codePath": "0_110000",
"level": 1,
"name": "北京",
"shortName": "北京",
"sort": 1,
"pinyin": "BeiJing",
"py": "BJ"
}
 */
data class CityBean(var code: String,
                    var parentCode: String,
                    var codePath: String,
                    var level: Int,
                    var name: String,
                    var shortName: String,
                    var sort: Int,
                    var pinyin: String,
                    var py: String) {

    fun toDbCity(): City {
        var city = City()
        city.id = code
        city.name = shortName
        city.parentId = parentCode
        city.pinyin = pinyin
        city.level = level
        city.type = level
        city.py = py
        return city
    }

}