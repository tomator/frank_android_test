package com.weidai.wpai.ui.view;

import android.content.Context;
import android.support.annotation.DrawableRes;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.weidai.wpai.R;
import com.weidai.wpai.util.DensityUtil;

public class BannerDot extends LinearLayout {
    private static final int DEFAULT_SELECT_IMAGE = R.drawable.bg_home_banner_dot_select;
    private static final int DEFAULT_NORMAL_IMAGE = R.drawable.bg_home_banner_dot;

    private final static int DOT_SOLO = 1;
    private int imageNormal = DEFAULT_NORMAL_IMAGE;
    private int imageSelect = DEFAULT_SELECT_IMAGE;

    public BannerDot(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setDot(int size) {
        removeAllViews();
        if (size != DOT_SOLO) {
            for (int i = 0; i < size; i++) {
                addView(getDotView());
            }
            setDotLight(0);
        }
    }

    public void setDotLight(int position) {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            if (position == i) {
                ((ImageView) getChildAt(i)).setImageResource(imageSelect);
            } else {
                ((ImageView) getChildAt(i)).setImageResource(imageNormal);
            }
        }
    }

    public void setImage(@DrawableRes int normal, @DrawableRes int select) {
        imageNormal = normal;
        imageSelect = select;
    }

    private View getDotView() {
        ImageView imageView = new ImageView(getContext());
        LayoutParams layoutParams = new LayoutParams(DensityUtil.dip2px(6), DensityUtil.dip2px(6));
        layoutParams.setMargins(DensityUtil.dip2px(4), 0, DensityUtil.dip2px(4), 0);
        imageView.setLayoutParams(layoutParams);
        return imageView;
    }

    public void resetDot() {
        removeAllViews();
    }

}
