package com.weidai.wpai.component.cityPick.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

internal class DBOpenHelper @JvmOverloads constructor(
        context: Context,
        name: String = DBOpenHelper.DB_NAME,
        factory: SQLiteDatabase.CursorFactory? = null,
        version: Int = DBOpenHelper.DB_VERSION)
    : SQLiteOpenHelper(context, name, factory, version) {

    override fun onCreate(db: SQLiteDatabase) {
        Log.i("database", "onCreate : " + City.CREATE_TABLE)
        db.execSQL(City.CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        val DB_NAME = "wpai_city.db"
        private val DB_VERSION = 1
    }
}
