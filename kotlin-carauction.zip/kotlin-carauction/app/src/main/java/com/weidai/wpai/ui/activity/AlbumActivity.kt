package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.ui.view.TouchImageView
import com.weidai.wpai.util.DensityUtil
import kotlinx.android.synthetic.main.activity_album.*
import rx.Observable
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/27
 */
class AlbumActivity : BaseActivity() {

    private var urlList = ArrayList<String>()
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_album)
        navigationView.visibility = View.GONE
        urlList = intent.getStringArrayListExtra("urlList")
        index = intent.getIntExtra("index", 0)
        val showIndex = index + 1
        indexTV.text = "$showIndex / ${urlList.size}"
        viewpager.adapter = object : PagerAdapter() {
            override fun getCount(): Int {
                return urlList.size
            }

            override fun isViewFromObject(view: View, `object`: Any): Boolean {
                return view === `object`
            }

            override fun instantiateItem(container: ViewGroup, position: Int): Any {
                val imageView = TouchImageView(this@AlbumActivity)
                imageView.setImageResource(R.mipmap.ic_product_loading)
                dispayImage(imageView, urlList[position])
                container.addView(imageView)
                imageView.setOnClickListener {
                    close()
                }
                return imageView
            }

            override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
                if (`object` is TouchImageView) {
                    container.removeView(`object`)
                }
            }
        }
        viewpager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

            }

            override fun onPageSelected(position: Int) {
                val showIndex = position + 1
                indexTV.text = showIndex.toString() + " / " + urlList.size
            }

            override fun onPageScrollStateChanged(state: Int) {

            }
        })
        if (index <= urlList.size) {
            viewpager.currentItem = index
        }
    }

    private fun dispayImage(imageView: ImageView, url: String) {
        if (TextUtils.isEmpty(url)) {
            return
        }
        Observable.create(Observable.OnSubscribe<Bitmap> { subscriber ->
            val bitmap = ImageLoader.instance.getLargeClient().load(url).get()
            if (bitmap != null) {
                subscriber.onNext(bitmap)
            } else {
                subscriber.onError(Exception())
            }
        }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<Bitmap>() {
                    override fun onCompleted() {

                    }

                    override fun onError(e: Throwable) {

                    }

                    override fun onNext(bitmap: Bitmap) {
                        val width = DensityUtil.getScreenWidth(this@AlbumActivity)
                        val height = width * bitmap.height / bitmap.width
                        val layoutParams = imageView.layoutParams as ViewPager.LayoutParams
                        layoutParams.width = width
                        layoutParams.height = height
                        imageView.setImageBitmap(bitmap)
                    }
                })
    }

    override fun onBackPressed() {
        close()
    }

    private fun close() {
        finish()
        overridePendingTransition(R.anim.fade_in_album, R.anim.fade_out_album)
    }


    companion object {

        fun gotoThis(context: Context, urlList: List<String>, index: Int) {
            val intent = Intent(context, AlbumActivity::class.java)
            intent.putStringArrayListExtra("urlList", ArrayList(urlList))
            intent.putExtra("index", index)
            context.startActivity(intent)
        }
    }
}
