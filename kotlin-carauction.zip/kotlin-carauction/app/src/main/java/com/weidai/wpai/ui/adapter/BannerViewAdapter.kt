package com.weidai.wpai.ui.adapter

import android.content.Context
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ImageView.ScaleType
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.http.bean.BannerBean
import com.weidai.wpai.ui.activity.WPWebActivty
import com.weidai.wpai.ui.view.AutoSwitchViewPager
import java.util.*

class BannerViewAdapter(private val mContext: Context, imageUrlList: List<BannerBean>?) : AutoSwitchViewPager.AutoSwitchPagerAdapter() {
    private var mBannerList: List<BannerBean> = ArrayList()
    private var mUrlListSize = 0

    init {
        if (null == imageUrlList) {
            mBannerList = ArrayList<BannerBean>()
        } else {
            mBannerList = imageUrlList
            mUrlListSize = imageUrlList.size
        }
    }

    override fun getCountOfContents(): Int {
        return mUrlListSize
    }

    override fun instantiateView(container: ViewGroup, position: Int): View? {
        if (0 == count) {
            return null
        }
        val view = createBannerView(mBannerList[position % mUrlListSize])
        container.addView(view)
        return view
    }

    override fun destroyView(container: ViewGroup, position: Int, `object`: Any) {
        container.removeView(`object` as View)
    }

    override fun isViewFromObject(arg0: View, arg1: Any): Boolean {
        return arg0 === arg1
    }

    private fun createBannerView(bean: BannerBean): View {
        val imageView = ImageView(mContext)
        ImageLoader.instance.display(bean.bannerImgUrl, imageView, R.mipmap.bg_default_banner)
        imageView.scaleType = ScaleType.CENTER_CROP
        imageView.tag = bean.bannerUrl
        imageView.setOnClickListener(createClickListener())
        return imageView
    }

    private fun createClickListener(): View.OnClickListener {
        return View.OnClickListener { v ->
            val linkUrl = v.tag as String
            if (!TextUtils.isEmpty(linkUrl)) {
                WPWebActivty.open(mContext, linkUrl)
            }
        }
    }
}