package com.weidai.wpai.ui.activity

import android.support.v4.app.Fragment

import com.weidai.wpai.R
import com.weidai.wpai.ui.fragment.MessageFragment
import kotlinx.android.synthetic.main.activity_base_tab.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/24
 */
class MessageActivity : SimpleTabActivity() {

    override val tabContents: Array<String>
        get() = resources.getStringArray(R.array.tabMessage)

    override val fragments: Array<Fragment>
        get() {
            navigationView.setTitle("消息通知")
            val noticeFragment = MessageFragment.newInstance(MessageFragment.TYPE_NOTICE)
            val userFragment = MessageFragment.newInstance(MessageFragment.TYPE_USER)
            return arrayOf(noticeFragment, userFragment)
        }
}
