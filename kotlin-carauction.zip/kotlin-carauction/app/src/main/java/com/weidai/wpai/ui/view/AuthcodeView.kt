package com.weidai.wpai.ui.view

import android.content.Context
import android.os.CountDownTimer
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.RechargeBean
import com.weidai.wpai.http.param.SendMsgVQO
import com.weidai.wpai.http.param.SendVerifyCodeVQO
import com.weidai.wpai.ui.dialog.ImageAuthDialog
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import kotlinx.android.synthetic.main.dialog_auction_hide_bid.*
import kotlinx.android.synthetic.main.view_auth_code.view.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers


/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/12
 */
class AuthcodeView(context: Context, attrs: AttributeSet?) : FrameLayout(context, attrs) {

    private var myCountDownTimer: MyCountDownTimer? = null
    private var phoneNumber: String? = null
    private var type = SendMsgVQO.TYPE_REGISTER
    private var mode = MODE_NORMAL
    private var imageCode: String? = null
    var rechargeBean: RechargeBean? = null

    init {
        init()
    }

    private fun init() {
        LayoutInflater.from(context).inflate(R.layout.view_auth_code, this)
        sendBtn.setOnClickListener {
            if (!sendBtn.isSelected) {
                if (!ValidityUtils.checkPhone(phoneNumber)) {
                    ToastUtil.show("请输入正确的手机号码")
                    return@setOnClickListener
                }
                if (mode == MODE_IMAGE) {
                    showImageDialog()
                } else {
                    if (type == SendMsgVQO.TYPE_RECHARGE) {
                        rechargeBean?.let {
                            sendVerifyCode(rechargeBean!!)
                        }
                    } else {
                        sendAuthCode()
                    }
                }
            }
        }
    }

    private fun showImageDialog() {
        val imageAuthDialog = ImageAuthDialog(context)
        imageAuthDialog.show()
        imageAuthDialog.numberInputView.addInputListener(object : NumberInputView.OnInputListener {
            override fun onInput(input: String, last: String) {
                if (input.length >= 4) {
                    imageCode = input.substring(0, 4)
                    imageAuthDialog.cancel()
                    sendAuthCodeWithImageCode()
                } else {
                    imageCode = ""
                }
            }
        })
    }

    private fun sendAuthCode() {
        sendBtn.isSelected = true
        sendBtn.text = "正在发送..."
        Client.getService().sendAuthCode(SendMsgVQO(type, phoneNumber!!))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>() {
                    override fun onSuccess(result: Result<*>) {
                        myCountDownTimer = MyCountDownTimer(AUTHCODE_INTERVAL, 1000)
                        myCountDownTimer!!.start()
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        resetSendBtn()
                    }

                    override fun onFailed(e: Throwable?, msg: String?) {
                        super.onFailed(e, msg)
                        resetSendBtn()
                    }
                })
    }

    private fun sendVerifyCode(rechargeBean: RechargeBean) {
        sendBtn.isSelected = true
        sendBtn.text = "正在发送..."
        Client.getService().sendVerifyCode(SendVerifyCodeVQO(rechargeBean.outBillNo,
                rechargeBean.channelCode, rechargeBean.instCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>() {
                    override fun onSuccess(result: Result<*>) {
                        myCountDownTimer = MyCountDownTimer(AUTHCODE_INTERVAL, 1000)
                        myCountDownTimer!!.start()
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        resetSendBtn()
                    }

                    override fun onFailed(e: Throwable?, msg: String?) {
                        super.onFailed(e, msg)
                        resetSendBtn()
                    }
                })
    }

    private fun sendAuthCodeWithImageCode() {
        sendBtn.isSelected = true
        sendBtn.text = "正在发送..."
        Client.getService().sendAuthCodeWithImage(SendMsgVQO(type, phoneNumber!!, imageCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<*>>() {
                    override fun onSuccess(result: Result<*>) {
                        myCountDownTimer = MyCountDownTimer(AUTHCODE_INTERVAL, 1000)
                        myCountDownTimer!!.start()
                    }

                    override fun onFailed(result: Result<*>) {
                        super.onFailed(result)
                        resetSendBtn()
                    }

                    override fun onFailed(e: Throwable?, msg: String?) {
                        super.onFailed(e, msg)
                        resetSendBtn()
                    }
                })
    }


    private fun resetSendBtn() {
        sendBtn.isSelected = false
        sendBtn.text = "重发验证码"
    }

    fun getAuthcodeAET(): AccountEditText {
        return authcodeAET
    }

    fun setPhoneNumber(phoneNumber: String?) {
        this.phoneNumber = phoneNumber
    }

    fun setType(type: Int) {
        this.type = type
    }

    fun setMode(mode: Int) {
        this.mode = mode
    }

    val text: CharSequence
        get() = authcodeAET.text

    internal inner class MyCountDownTimer(millisInFuture: Long, countDownInterval: Long)
        : CountDownTimer(millisInFuture, countDownInterval) {

        override fun onTick(millisUntilFinished: Long) {
            val currentNum = millisUntilFinished / 1000
            sendBtn.text = currentNum.toString() + "S"
        }

        override fun onFinish() {
            resetSendBtn()
        }
    }

    companion object {
        val AUTHCODE_INTERVAL = 60 * 1000L
        val MODE_NORMAL = 0
        val MODE_IMAGE = 1 // 需要图片验证码
    }

}
