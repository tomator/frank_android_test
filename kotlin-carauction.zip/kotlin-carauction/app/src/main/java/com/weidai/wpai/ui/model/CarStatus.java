package com.weidai.wpai.ui.model;

import com.weidai.wpai.http.base.Bean;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/16
 */
public class CarStatus implements Bean {
    private String name;
    private String value;

    public CarStatus() {
    }

    public CarStatus(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public CarStatus setName(String name) {
        this.name = name;
        return this;
    }

    public String getValue() {
        return value;
    }

    public CarStatus setValue(String value) {
        this.value = value;
        return this;
    }
}
