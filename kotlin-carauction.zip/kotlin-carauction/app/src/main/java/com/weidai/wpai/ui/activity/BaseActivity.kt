package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity

import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.App
import com.weidai.wpai.component.StatisticalManager

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/7
 */
open class BaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RxBus.get().register(this)
        App.instance.addActivity(javaClass.simpleName, this)
    }

    override fun onResume() {
        super.onResume()
        StatisticalManager.onPageResume(this)
        App.instance.currentActivity = this
    }

    override fun onPause() {
        super.onPause()
        StatisticalManager.onPagePause(this)
    }

    override fun onStop() {
        super.onStop()
    }

    override fun onDestroy() {
        RxBus.get().unregister(this)
        App.instance.removeActivity(javaClass.simpleName)
        super.onDestroy()
    }
}
