package com.weidai.wpai.http.bean

import java.io.Serializable

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/15
 */


/**
detailModelSlug:公平价车型id（爬虫）
levelId:力洋车型id
brandName:品牌
modelType:车型
modelName:车名称
outYear:年款
modelDetail:车详情
maxRegYear:最大上牌年份
minRegYear:最小上牌年份
emissionStandard:排放标准
transmission:自动手动
guidePrice:指导价，单位:万
output:排量
sourceType:进口国产合资
depRatioGpj:公平价折旧率
depRatioCar300:车300折旧率
carCity:城市
provinceName:省份
mileage:公里数（单位：万）
ppDate:上牌日期
flag:来源（0：根据车架号估计，1：根据品牌估价）
 */

class EvaluateCar : Serializable {

    var brandName: String? = null
    var depRatioCar300: Double? = 0.0
    var depRatioGpj: Double? = 0.0
    var detailModelSlug: String? = null
    var emissionStandard: String? = null
    var flag: Int? = 1
    var guidePrice: String? = null
    var levelId: String? = null
    var maxRegYear: String? = null
    var minRegYear: String? = null
    var modelDetail: String? = null
    var modelName: String? = null
    var modelType: String? = null
    var transmission: String? = null
    var outYear: String? = null
    var output: String? = null
    var outputTye: String? = null
    var sourceType: String? = null
    var carCity: String? = null
    var provinceName: String? = null
    var mileage: String? = null
    var ppDate: String? = null

    companion object {
        const val FLAG_VIN = 0
        const val FLAG_MODEL = 1
    }
}