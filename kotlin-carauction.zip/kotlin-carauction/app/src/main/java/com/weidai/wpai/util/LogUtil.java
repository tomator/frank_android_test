package com.weidai.wpai.util;

import android.util.Log;

import com.weidai.wpai.BuildConfig;

/**
 * Describe: Log输出
 * User: LiYajun
 * Date: 2016-06-12
 */

public class LogUtil {
    private static final String TAG = "CAR_LOG";

    public static void d(String msg) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, msg);

        }
    }

    public static void i(String msg) {
        if (BuildConfig.DEBUG) {
            Log.i(TAG, msg);
        }
    }

    public static void e(String msg) {
        if (BuildConfig.DEBUG) {
            Log.e(TAG, msg);
        }
    }

    public static void e(String msg, Throwable e) {
        if (BuildConfig.DEBUG) {
            e.printStackTrace();
            Log.e(TAG, msg, e);
        }
    }

    public static void v(String msg) {
        if (BuildConfig.DEBUG) {
            Log.v(TAG, msg);
        }

    }

    public static void w(String msg) {
        if (BuildConfig.DEBUG) {
            Log.w(TAG, msg);
        }
    }

    public static void d(String from, String msg) {
        if (BuildConfig.DEBUG) {
            StringBuffer sb = new StringBuffer(from).append(":").append(msg);
            Log.d(TAG, sb.toString());
        }

    }

    public static void i(String from, String msg) {
        if (BuildConfig.DEBUG) {
            StringBuffer sb = new StringBuffer(from).append(":").append(msg);
            Log.i(TAG, sb.toString());
        }
    }

    public static void e(String from, String msg) {
        if (BuildConfig.DEBUG) {
            StringBuffer sb = new StringBuffer(from).append(":").append(msg);
            Log.e(TAG, sb.toString());
        }
    }

    public static void v(String from, String msg) {
        if (BuildConfig.DEBUG) {
            StringBuffer sb = new StringBuffer(from).append(":").append(msg);
            Log.v(TAG, sb.toString());
        }
    }

    public static void w(String from, String msg) {
        if (BuildConfig.DEBUG) {
            StringBuffer sb = new StringBuffer(from).append(":").append(msg);
            Log.w(TAG, sb.toString());
        }
    }
}
