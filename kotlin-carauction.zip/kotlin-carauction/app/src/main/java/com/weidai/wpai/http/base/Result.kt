package com.weidai.wpai.http.base

/**
 * Created by bici on 16/12/8.
 */

class Result<T> : Bean {

    var code: Int = 0  // 判断是否成功的唯一标志
    var message: String? = null
    var data: T? = null

    companion object {

        const val CODE_SUCEESS = 0

//        const val CODE_ALREADY_ENTRY = 1
        /*** 未登录  */
        const val CODE_LOGIN = 10001
        /*** 系统异常  */
        const val CODE_EXCEPTION = -1
        /*** 图片验证码错误  */
        const val CODE_VALID_IMG = 1001
        /*** 手机验证码错误  */
        const val CODE_VALID_MOBILE = 1002
        /*** 手机号码错误  */
        const val CODE_MOBILE = 101
        /*** 未开通钱包  */
        const val CODE_NO_ACCOUNT = 11
        /*** 未绑卡  */
        const val CODE_NO_BANK = 12
        /*** 金额不足  */
        const val CODE_NO_AMOUNT = 13
        /*** 未设置支付密码  */
        const val CODE_NO_PAYPWD = 14
        /*** 提现中  */
        const val CODE_RECHARGE_OR_WITHDRAW_WAIT = 15
        /*** 与登录密码重复  */
        const val CODE_SAMEPWD = 1003
    }
}
