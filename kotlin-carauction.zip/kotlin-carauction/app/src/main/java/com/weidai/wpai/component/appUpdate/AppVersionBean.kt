package com.weidai.wpai.component.appUpdate

/**
 * Describe:
 * User: 月月鸟
 * Date: 2017-05-17
 */
data class AppVersionBean(val m: String,
                          val r: String,
                          val d: ApkInfo) {

    fun getR(): Int {
        var intR = -2
        try {
            intR = Integer.parseInt(r)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return intR
    }
    
    companion object {
        val CHANGE_UPDATE = 1//选择更新；
        val FORCE_UPDATE = 2//强制更新；
        val UN_UPDATE = 3//不更新；

        fun compare(v1: String, v2: String): Int {
            val array1 = v1.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            val array2 = v2.split("\\.".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
            val len1 = array1.size
            val len2 = array2.size
            val len = if (len1 < len2) len1 else len2
            var result = 0
            for (i in 0..len - 1) {
                val value1 = getIntValue(array1[i])
                val value2 = getIntValue(array2[i])
                if (value1 > value2) {
                    result = 1
                    break
                }
                if (value1 < value2) {
                    result = -1
                    break
                }
            }
            if (result == 0) {
                if (len1 > len2) {
                    result = 1
                } else if (len1 == len2) {
                    result = 0
                } else {
                    result = -1
                }
            }
            return result
        }

        fun getIntValue(str: String): Int {
            var result = 0
            try {
                result = Integer.parseInt(str)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return result
        }
    }

}

data class ApkInfo(val downloadUrl: String, //渠道下载地址
                   val maxVersion: String, //最大版本
                   val minVersion: String, //最小版本
                   val versionInfo: String //最新版本说明
) {
    fun isForceUpdate(curVersion: String): Int {
        if (AppVersionBean.compare(curVersion, maxVersion) >= 0) {
            return AppVersionBean.UN_UPDATE
        }
        if (AppVersionBean.compare(curVersion, minVersion) < 0) {
            return AppVersionBean.FORCE_UPDATE
        }
        return AppVersionBean.CHANGE_UPDATE
    }
}
