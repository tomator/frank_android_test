package com.weidai.wpai.ui.activity

import android.os.Bundle
import com.weidai.wpai.R
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.PwdModfiyVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_pwd_modify.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class PwdModifyActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pwd_modify)
        navigationView.setTitle("修改账号密码")
        oldAET.setOnTextChange { checkCommitEnable() }
        repeatAET.setOnTextChange { checkCommitEnable() }
        newAET.setOnTextChange { checkCommitEnable() }
        confirmBtn.setOnClickListener {
            if (confirmBtn.isSelected) {
                submit()
            }
        }
    }

    private fun checkCommitEnable() {
        val oldPwd = oldAET.text.toString()
        val newPwd = newAET.text.toString()
        val repeat = repeatAET.text.toString()
        confirmBtn.isSelected = ValidityUtils.checkPassword(oldPwd)
                && ValidityUtils.checkPassword(repeat)
                && ValidityUtils.checkPassword(newPwd)
    }

    private fun submit() {
        val oldPwd = oldAET.text.toString()
        val newPwd = newAET.text.toString()
        val repeat = repeatAET.text.toString()
        if (newPwd == repeat) {
            val progressDialog = ProgressDialog(this)
            progressDialog.show()
            Client.getService().modifyPwd(PwdModfiyVQO(PasswordUtil.encode(newPwd), PasswordUtil.encode(oldPwd)))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SimpleSubscriber<Result<*>>(progressDialog) {
                        override fun onSuccess(result: Result<*>) {
                            super.onSuccess(result)
                            ToastUtil.show("设置成功")
                            UserManager.instance.setPayPwd(true)
                            finish()
                        }
                    })
        } else {
            ToastUtil.show("两次密码输入不一致，请重新输入")
        }
    }
}
