package com.weidai.wpai.http

import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.text.TextUtils
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.base.ResultException
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import retrofit2.adapter.rxjava.HttpException
import rx.Subscriber
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/12
 */
open class SimpleSubscriber<T> : Subscriber<T> {
    private var progressDialog: ProgressDialog? = null
    private var ptrFrameLayout: PtrFrameLayout? = null
    private var needToLogin = true

    constructor() {}

    constructor(needToLogin: Boolean) {
        this.needToLogin = needToLogin
    }

    constructor(progressDialog: ProgressDialog) {
        this.progressDialog = progressDialog
    }

    constructor(ptrFrameLayout: PtrFrameLayout) {
        this.ptrFrameLayout = ptrFrameLayout
    }

    override fun onCompleted() {
        closeLoadingView()
    }

    override fun onError(e: Throwable) {
        closeLoadingView()
        onFailed(e, e.message)
    }

    override fun onNext(o: T) {
        closeLoadingView()
        if (o is Result<*>) {
            val result = o
            when (result.code) {
                Result.CODE_SUCEESS -> onSuccess(o)
                1 -> {
                    onFailed(result)
                    if (TextUtils.isEmpty(result.message)) {
                        ToastUtil.show("操作失败")
                    }
                }
                Result.CODE_LOGIN -> {
                    if (needToLogin) {
                        UserManager.instance.turn2Login()
                    }else{
                        UserManager.instance.cleanUserInfo()
                    }
                    RxBus.get().post(EventKey.KEY_USER_NOT_LOGIN, true)
                    onFailed(result)
                }
                Result.CODE_NO_BANK -> {
                    UserManager.instance.saveBindCrad(null)
                    onFailed(result)
                }
                Result.CODE_NO_PAYPWD -> {
                    UserManager.instance.setPayPwd(false)
                    onFailed(result)
                }
                Result.CODE_RECHARGE_OR_WITHDRAW_WAIT -> onSuccess(o)
                else -> onFailed(result)
            }
        } else {
            onFailed(null, "未知对象 : " + o)
        }
    }

    open fun onSuccess(result: T) {

    }

    open fun onFailed() {

    }

    open fun onFailed(result: Result<*>) {
        if (!TextUtils.isEmpty(result.message)) {
            ToastUtil.show(result.message)
        }
        onFailed()
    }

    open fun onFailed(e: Throwable?, msg: String?) {
        if (e == null) {
            if (!TextUtils.isEmpty(msg)) {
                ToastUtil.show(msg)
            }
        } else {
            if (e is HttpException
                    || e is UnknownHostException
                    || e is SocketException) {
                ToastUtil.show("网络错误，请检查网络后再试")
            }
            if (e is ResultException) {
                ToastUtil.show(e.message)
            }
            if (e is SocketTimeoutException) {
                ToastUtil.show("请求超时，请稍后再试")
            }
            LogUtil.e("SimpleSubscriber", e)
        }
        onFailed()
    }

    private fun closeLoadingView() {
        progressDialog?.dismiss()
        ptrFrameLayout?.refreshComplete()
    }
}
