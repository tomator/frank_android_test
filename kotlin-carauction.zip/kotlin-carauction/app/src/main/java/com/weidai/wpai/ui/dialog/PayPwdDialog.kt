package com.weidai.wpai.ui.dialog

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import com.jungly.gridpasswordview.GridPasswordView
import com.weidai.wpai.R
import com.weidai.wpai.ui.activity.PayPwdResetActivity
import com.weidai.wpai.util.FormatUtil
import kotlinx.android.synthetic.main.dialog_pay_pwd.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/17
 */
class PayPwdDialog(context: Context, val money: Double, val type: Int) : Dialog(context, R.style.Dialog_Alert) {

    init {
        init()
    }

    private fun init() {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_pay_pwd, null)
        setContentView(view)
        if (type == TYPE_RECHARE) {
            payTipsTV.text = "充值账户余额"
        } else if (type == TYPE_WITHDRAW) {
            payTipsTV.text = "账户提现"
        } else {
            payTipsTV.text = "支付金额"
        }
        accountBalanceTV.text = FormatUtil.MONEY_UNIT_SYMBOL + " " + FormatUtil.getFormateMoney(money)
        setOnShowListener {
            payPwdView.findFocus()
            payPwdView.performClick()
        }
        closeBtn.setOnClickListener { cancel() }
        forgatPwdTV.setOnClickListener { context.startActivity(Intent(context, PayPwdResetActivity::class.java)) }
    }

    fun setOnPasswordChangedListener(onPasswordChangedListener: GridPasswordView.OnPasswordChangedListener) {
        payPwdView.setOnPasswordChangedListener(onPasswordChangedListener)
    }

    companion object {
        val TYPE_RECHARE = 1
        val TYPE_WITHDRAW = 2
        val TYPE_PAY = 3
    }
}
