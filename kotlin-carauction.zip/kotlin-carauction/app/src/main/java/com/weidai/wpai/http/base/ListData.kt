package com.weidai.wpai.http.base

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/12
 */
class ListData<T> : Bean {

    var total: Int = 0
    var data: List<T>? = null
}
