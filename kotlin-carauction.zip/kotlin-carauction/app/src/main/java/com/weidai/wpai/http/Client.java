package com.weidai.wpai.http;

import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by bici on 16/8/5.
 */
public class Client {
    public static final String TAG = "Client";
    private static ApiService apiService;

    public static void init() {
        apiService = createCliet();
    }

    private static ApiService createCliet() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(HostConfig.API_HOST)
                .client(ApiHelper.createOkHttpClient())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit.create(ApiService.class);
    }

    public static ApiService getService() {
        return apiService;
    }
}

