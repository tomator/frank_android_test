package com.weidai.wpai.ui.view

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.Coupon
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.view_coupon.view.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/31
 */
class CouponView : FrameLayout {

    private var status = Coupon.STATUS_NOT_USE
    lateinit var rotate: ObjectAnimator
    lateinit var rotateBack: ObjectAnimator
    private var coupon: Coupon? = null
    var onSelectListener: OnSelectListener? = null

    constructor(context: Context) : super(context) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        initView()
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initView()
    }

    fun initView() {
        LayoutInflater.from(context).inflate(R.layout.view_coupon, this)
        initAnimator()
        bottomView.setOnClickListener {
            moreIV.isSelected = !moreIV.isSelected
            if (moreIV.isSelected) {
                descriptionTV.visibility = View.VISIBLE
                rotate.start()
            } else {
                descriptionTV.visibility = View.GONE
                rotateBack.start()
            }
        }
    }

    fun initAnimator() {
        rotate = ObjectAnimator.ofFloat(moreIV, "rotation", 0f, 90f)
        rotate.repeatCount = Animation.ABSOLUTE
        rotate.repeatMode = ValueAnimator.INFINITE
        rotate.interpolator = LinearInterpolator()
        rotateBack = ObjectAnimator.ofFloat(moreIV, "rotation", 90f, 0f)
        rotateBack.repeatCount = Animation.ABSOLUTE
        rotateBack.repeatMode = ValueAnimator.INFINITE
        rotateBack.interpolator = LinearInterpolator()
    }

    fun setData(value: Int, coupon: Coupon) {
        this.status = value
        this.coupon = coupon
        refreshStatus()
        idTV.text = coupon.code
        if (coupon.type == Coupon.TYPE_ZHEKOU) {
            priceTV.text = "${FormatUtil.getDouble2(coupon.value)}折"
            nameTV.text = "提车折扣券"
        } else {
            priceTV.text = "￥${FormatUtil.getDouble2(coupon.value)}"
            nameTV.text = "提车代金券"
        }
        if (coupon.valueMin.toDouble() <= 0.0) {
            useRangeTV.text = "${FormatUtil.getDouble2(coupon.valueMax)}万以下可用"
        }
        if (coupon.valueMax.toDouble() <= 0.0) {
            useRangeTV.text = "${FormatUtil.getDouble2(coupon.valueMin)}万以上可用"
        }
        if (coupon.valueMin.toDouble() > 0 && coupon.valueMax.toDouble() > 0) {
            useRangeTV.text = "${FormatUtil.getDouble2(coupon.valueMin)}万" +
                    "-${FormatUtil.getDouble2(coupon.valueMax)}万可用"
        }
        if (coupon.valueMin.toDouble() <= 0.0 && coupon.valueMax.toDouble() <= 0.0) {
            useRangeTV.text = "所有车辆可用"
        }
        validityTV.text = "有效期: ${DateUtil.format(coupon.startTime, 12)}" +
                "-${DateUtil.format(coupon.endTime, 12)}"
        descriptionTV.text = coupon.usedDescribe
    }

    fun refreshStatus() {
        when (status) {
            Coupon.STATUS_NOT_USE -> statusNotUse()
            Coupon.STATUS_ALREADY_USED -> statusAlreadyUsed()
            Coupon.STATUS_OVERDUE -> statusOverdue()
            Coupon.STATUS_CHOOSE_USABLE -> statusChooseUsable()
            Coupon.STATUS_CHOOSE_DISABLE -> statusChooseDisable()
        }
    }

    fun statusNotUse() {
        priceTV.isSelected = true
        nameTV.isSelected = true
        useRangeTV.isSelected = true
        validityTV.isSelected = true
        descriptionTV.isSelected = true
//        useTV.visibility = View.VISIBLE
    }

    fun statusAlreadyUsed() {
        priceTV.isSelected = true
        nameTV.isSelected = true
        useRangeTV.isSelected = true
        validityTV.isSelected = true
        descriptionTV.isSelected = true
        usedInfoLL.visibility = View.VISIBLE
        carModelTV.text = coupon!!.usedCarName
        topView.setOnClickListener {
            if (coupon != null && coupon!!.auctionNo != null) {
                AuctionActivity.gotoThis(context, coupon!!.auctionNo!!)
            } else {
                ToastUtil.show("获取车辆信息失败")
            }
        }
    }

    fun statusOverdue() {
        topView.setBackgroundResource(R.mipmap.bg_coupon_disable)
        bottomView.setBackgroundResource(R.drawable.bg_radiu_bottom_5_a9adb4)
        idTV.setTextColor(Color.parseColor("#D7DCE3"))
        priceTV.isSelected = false
        nameTV.isSelected = false
        useRangeTV.isSelected = false
        validityTV.isSelected = false
        descriptionTV.isSelected = false
        statusTV.visibility = View.VISIBLE
    }

    fun statusChooseUsable() {
        priceTV.isSelected = true
        nameTV.isSelected = true
        useRangeTV.isSelected = true
        validityTV.isSelected = true
        descriptionTV.isSelected = true
        selectIV.visibility = View.VISIBLE
        topView.setOnClickListener {
            selectIV.isSelected = !selectIV.isSelected
            onSelectListener?.let {
                onSelectListener!!.onSelect(selectIV.isSelected)
            }
        }
    }

    fun statusChooseDisable() {
        topView.alpha = 0.5f
        bottomView.alpha = 0.5f
        priceTV.isSelected = false
        nameTV.isSelected = false
        useRangeTV.isSelected = false
        validityTV.isSelected = false
        descriptionTV.isSelected = false
    }

    fun setTopSelect(isSelect: Boolean) {
        selectIV.isSelected = isSelect
    }

    interface OnSelectListener {
        fun onSelect(isSelect: Boolean)
    }

}
