package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.text.TextUtils
import android.view.View
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.RegisterVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.model.RegisterInfo
import com.weidai.wpai.ui.view.AuthcodeView
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_register.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class RegisterActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        navigationView.setTitle("注册")
        phoneAET.setOnTextChange { input ->
            authcodeView.setPhoneNumber(input.toString())
            checkRegisterEnable()
        }
        authcodeView.setMode(AuthcodeView.MODE_IMAGE)
        authcodeView.getAuthcodeAET().setOnTextChange { checkRegisterEnable() }
        passwordAET.setOnTextChange { checkRegisterEnable() }
        hasInvitationCodeTV.setOnClickListener {
            hasInvitationCodeTV.visibility = View.GONE
            invitationCodeAET.visibility = View.VISIBLE
        }
        registerBtn.setOnClickListener { register() }
        protocolBtn.setOnClickListener { WPWebActivty.openStaticPage(this, StaticPage.deal_register) }
    }

    private fun checkRegisterEnable() {
        val phone = phoneAET.text.toString()
        val authcode = authcodeView.text.toString()
        val password = passwordAET.text.toString()
        registerBtn.isSelected = ValidityUtils.checkPhone(phone)
                && ValidityUtils.checkAuthcode(authcode)
                && ValidityUtils.checkPassword(password)
    }

    private fun register() {
        val phone = phoneAET.text.toString()
        val authcode = authcodeView.text.toString()
        val password = passwordAET.text.toString()
        val encodePwd = PasswordUtil.encode(password)
        var invitationCode: String? = invitationCodeAET.text.toString()
        if (TextUtils.isEmpty(invitationCode)) {
            invitationCode = null
        }
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("正在注册...")
        progressDialog.show()
        Client.getService().fastRegister(RegisterVQO(encodePwd, phone, authcode, invitationCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                    override fun onSuccess(result: Result<Boolean>) {
                        super.onSuccess(result)
                        RxBus.get().post(EventKey.KEY_USER_REGISTER_SUCCESS, RegisterInfo(phone, password))
                        ToastUtil.show("注册成功")
                        finish()
                    }
                })
    }
}
