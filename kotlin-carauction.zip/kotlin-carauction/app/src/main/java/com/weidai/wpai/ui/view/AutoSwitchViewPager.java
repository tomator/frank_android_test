package com.weidai.wpai.ui.view;

import android.content.Context;
import android.os.Handler;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.weidai.wpai.R;


/**
 * 消费掉所有落在当前控件上的触摸操作，避免viewpager与scrollView滑动冲突
 * Created by 魏旭方 on 2016/6/5.
 */
public class AutoSwitchViewPager extends ViewPager {

    private Context mContext;
    private Handler mSwitchHandler;
    private Runnable mSwitchRunnable;
    private long mIntervalMillis;
    private boolean mIsStartAutoSwitch;
    private boolean canChangePage = true;

    public AutoSwitchViewPager(Context context) {
        super(context);
        mContext = context;
        mIntervalMillis = 3000;
    }

    public AutoSwitchViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
    }

    public void setAdapter(AutoSwitchPagerAdapter adapter, RadioGroup group) {
        setAdapter(adapter);
        setCurrentItem(adapter.getCountOfContents() * 100);
        if (null != group) {
            createViewPagerSplash(group, adapter.getCountOfContents());
            addOnPageChangeListener(createPageChangeListener(group));
        }
    }

    private RadioButton createRadioButton(Context context) {
        RadioButton radioButton = new RadioButton(context);
        radioButton.setButtonDrawable(R.drawable.selecteor_common_splash);
        RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(10, 0, 0, 0);
        radioButton.setLayoutParams(params);
        return radioButton;
    }

    public void createViewPagerSplash(RadioGroup group, int count) {
        RadioButton radioButton = createRadioButton(mContext);
        group.removeAllViews();
        group.addView(radioButton);
        for (int i = 0; i < count - 1; i++) {
            group.addView(createRadioButton(mContext));
        }
        radioButton.setChecked(true);
    }

    private OnPageChangeListener createPageChangeListener(final RadioGroup splashGroup) {
        return new OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                RadioButton radioButton = (RadioButton) splashGroup.getChildAt(position % splashGroup.getChildCount());
                radioButton.setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        };
    }

    /**
     * @warnning 开启自动切换，调用此函数后必须在界面销毁的时候调用stopAutoSwitch,否则会造成内存泄漏,仅供外部调用
     */
    public void startAutoSwitch(final long intervalMillis) {
        mIsStartAutoSwitch = true;
        startAutoSwitchInner(intervalMillis);
    }

    private void startAutoSwitchInner(final long intervalMillis) {
        mIntervalMillis = intervalMillis == 0 ? mIntervalMillis : intervalMillis;
        stopAutoSwitch();
        if (null == mSwitchHandler) {
            mSwitchHandler = new Handler();
        }
        if (null == mSwitchRunnable) {
            mSwitchRunnable = new Runnable() {
                @Override
                public void run() {
                    AutoSwitchViewPager pagerView = AutoSwitchViewPager.this;
                    pagerView.setCurrentItem(pagerView.getCurrentItem() + 1);
                    mSwitchHandler.postDelayed(this, mIntervalMillis);
                }
            };
        }
        mSwitchHandler.postDelayed(mSwitchRunnable, mIntervalMillis);
    }

    public void stopAutoSwitch() {
        if (null != mSwitchHandler) {
            mSwitchHandler.removeCallbacks(mSwitchRunnable);
            mSwitchHandler = null;
            mSwitchRunnable = null;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        //此句代码是为了通知他的父ViewPager现在进行的是本控件的操作，不要对我的操作进行干扰
        getParent().requestDisallowInterceptTouchEvent(true);
        return super.onTouchEvent(ev);
    }

    public void setCanChangePage(boolean canChangePage) {
        this.canChangePage = canChangePage;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (mIsStartAutoSwitch) {
                    stopAutoSwitch();
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (mIsStartAutoSwitch) {
                    startAutoSwitchInner(0);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (!canChangePage) {
                    return false;
                }
                break;

        }
        return super.dispatchTouchEvent(ev);
    }

    public static abstract class AutoSwitchPagerAdapter extends PagerAdapter {

        @Override
        final public int getCount() {
            return Integer.MAX_VALUE;
        }

        @Override
        final public Object instantiateItem(ViewGroup container, int position) {
            return instantiateView(container, position % getCountOfContents());
        }

        @Override
        final public void destroyItem(ViewGroup container, int position, Object object) {
            destroyView(container, position % getCountOfContents(), object);
        }

        /**
         * 获取当前实际内容的条目个数
         *
         * @return
         */
        public abstract int getCountOfContents();

        public abstract View instantiateView(ViewGroup container, int position);

        public abstract void destroyView(ViewGroup container, int position, Object object);
    }
}
