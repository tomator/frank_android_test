package com.weidai.wpai.ui.view

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.weidai.wpai.util.DensityUtil

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/24
 */
class CircleView : View {

    var currentAngle = 0f
    var startAngle = 240f
    var endAngle = 320f
    var mar = DensityUtil.dip2px(10f).toFloat()

    constructor(context: Context) : super(context) {}

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {}

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {}

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawLine(canvas)
        drawBackground(canvas)
        drawProgress(canvas)
    }

    fun drawLine(canvas: Canvas) {
        var paint = Paint()
        paint.style = Paint.Style.STROKE     //设置填充样式
        paint.isAntiAlias = true         //抗锯齿功能
        paint.strokeWidth = 1f //设置画笔宽度
        //设置笔刷的样式 Paint.Cap.Round ,Cap.SQUARE等分别为圆形、方形
        paint.strokeCap = Paint.Cap.SQUARE
        paint.color = Color.WHITE
        var diameter = right - left
        var rect = RectF(1f, 1f, diameter.toFloat() - 1, diameter.toFloat() - 1)
        canvas.drawArc(rect, 0f, 360f, false, paint)
    }

    fun drawBackground(canvas: Canvas) {
        var paint = Paint()
        paint.style = Paint.Style.STROKE     //设置填充样式
        paint.isAntiAlias = true         //抗锯齿功能
        paint.strokeWidth = mar //设置画笔宽度
        //设置笔刷的样式 Paint.Cap.Round ,Cap.SQUARE等分别为圆形、方形
        paint.strokeCap = Paint.Cap.SQUARE
        paint.color = Color.parseColor("#0076E0")
        var diameter = right - left
        var rect = RectF(mar, mar, diameter.toFloat() - mar, diameter.toFloat() - mar)
        canvas.drawArc(rect, 0f, 360f, false, paint)
    }

    fun drawProgress(canvas: Canvas) {
        var paintCurrent = Paint()
        paintCurrent.style = Paint.Style.STROKE     //设置填充样式
        paintCurrent.isAntiAlias = true         //抗锯齿功能
        paintCurrent.strokeWidth = mar //设置画笔宽度
        //设置笔刷的样式 Paint.Cap.Round ,Cap.SQUARE等分别为圆形、方形
        paintCurrent.strokeCap = Paint.Cap.ROUND

        var diameter = right - left
        var colors = arrayOf(Color.parseColor("#eaf5ff"),
                Color.parseColor("#aedbfa")).toIntArray()
        var lg = LinearGradient(diameter * 0.35f, diameter * 0.1f,
                diameter * 0.1f, diameter * 0.45f, colors, null, Shader.TileMode.CLAMP)  //渐变颜色
        paintCurrent.shader = lg
        var rect = RectF(mar, mar, diameter.toFloat() - mar, diameter.toFloat() - mar)
        canvas.drawArc(rect, startAngle, currentAngle, false, paintCurrent)
    }

    fun startAnimation() {
        var progressAnimator = ValueAnimator.ofFloat(0f, endAngle)
        progressAnimator.duration = 1000L
        progressAnimator.addUpdateListener {
            currentAngle = it.animatedValue as Float
            invalidate()
        }
        progressAnimator.start()
    }
}
