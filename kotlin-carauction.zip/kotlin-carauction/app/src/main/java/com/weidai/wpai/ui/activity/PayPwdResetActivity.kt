package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.text.TextUtils
import com.weidai.wpai.R
import com.weidai.wpai.component.UserManager
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.ForgetPayPwdVQO
import com.weidai.wpai.http.param.SendMsgVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_pay_pwd_reset.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class PayPwdResetActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pay_pwd_reset)
        navigationView.setTitle("修改支付密码")
        val mobile = UserManager.instance.userMobile
        if (TextUtils.isEmpty(mobile)) {
            finish()
            return
        }
        phoneTV.text = FormatUtil.getDisplayMobile(mobile)
        authcodeView.setPhoneNumber(mobile)
        authcodeView.setType(SendMsgVQO.TYPE_FORGET_PAY_PWD)
        passwordAET.setOnTextChange { checkCommitEnable() }
        repeatAET.setOnTextChange { checkCommitEnable() }
        authcodeView.getAuthcodeAET().setOnTextChange { checkCommitEnable() }
        confirmBtn.setOnClickListener {
            if (confirmBtn.isSelected) {
                submit()
            }
        }
    }

    private fun checkCommitEnable() {
        val password = passwordAET.text.toString()
        val repeat = repeatAET.text.toString()
        val authcode = authcodeView.text.toString()
        confirmBtn.isSelected = ValidityUtils.checkAuthcode(authcode)
                && ValidityUtils.checkPayPwd(repeat)
                && ValidityUtils.checkPayPwd(password)
    }

    private fun submit() {
        val password = passwordAET.text.toString()
        val repeat = repeatAET.text.toString()
        val authcode = authcodeView.text.toString()
        if (password == repeat) {
            val progressDialog = ProgressDialog(this)
            progressDialog.show()
            Client.getService().resetPayPwd(ForgetPayPwdVQO(PasswordUtil.encode(password),
                    authcode, UserManager.instance.userMobile!!))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                        override fun onSuccess(result: Result<Boolean>) {
                            super.onSuccess(result)
                            ToastUtil.show("设置成功")
                            UserManager.instance.setPayPwd(true)
                            finish()
                        }
                    })
        } else {
            ToastUtil.show("两次密码输入不一致，请重新输入")
        }
    }
}
