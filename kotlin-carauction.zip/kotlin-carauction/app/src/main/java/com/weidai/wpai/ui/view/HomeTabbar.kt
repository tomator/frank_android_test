package com.weidai.wpai.ui.view

import android.content.Context
import android.support.annotation.DrawableRes
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.view_tabbar.view.*
import kotlinx.android.synthetic.main.view_tabbar_item.view.*
import java.util.*

/**
 * Created by bici on 16/6/13.
 */
class HomeTabbar : LinearLayout {

    private val itemViews = ArrayList<View>()
    private var onItemClickListener: OnItemClickListener? = null
    private var onCenterClickListener: OnCenterClickListener? = null
    private var currentPosition: Int = 0

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        LayoutInflater.from(context).inflate(R.layout.view_tabbar, this)
    }

    fun addDefaultItems() {
        addItem("首页", R.drawable.main_tab_selector_1)
        addItem("竞拍中心", R.drawable.main_tab_selector_2)
        addItem("我的", R.drawable.main_tab_selector_3)
    }

    fun addItem(text: String, @DrawableRes imageId: Int) {
        val item = LayoutInflater.from(context).inflate(R.layout.view_tabbar_item, containerView, false)
        item.setOnClickListener(onClickListener)
//        val imageView: ImageView = item.imageView
//        val textView: TextView = item.textView
        item.imageView.setImageResource(imageId)
        item.textView.text = text
        containerView.addView(item)
        item.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        itemViews.add(item)
    }

    private val onClickListener = View.OnClickListener { v ->
        if (onItemClickListener != null) {
            for (view in itemViews) {
                if (view === v) {
                    onItemClickListener!!.onItemClick(itemViews.indexOf(view))
                    setItemSelected(view, true)
                } else {
                    setItemSelected(view, false)
                }
            }
        }
    }

    fun showHideDot(position: Int, show: Boolean) {
        if (position < itemViews.size) {
            val dotView = itemViews[position].findViewById(R.id.dotView)
            if (show) {
                dotView.visibility = View.VISIBLE
            } else {
                dotView.visibility = View.INVISIBLE
            }
        }
    }

    private fun setItemSelected(view: View, selected: Boolean) {
        view.imageView.isSelected = selected
        view.textView.isSelected = selected
    }

    fun setItemSelected(position: Int) {
        for (i in itemViews.indices) {
            setItemSelected(itemViews[i], position == i)
        }
        currentPosition = position
    }

    fun setOnItemClickListener(onItemClickListener: OnItemClickListener) {
        this.onItemClickListener = onItemClickListener
    }

    fun setOnCenterClickListener(onCenterClickListener: OnCenterClickListener) {
        this.onCenterClickListener = onCenterClickListener
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    interface OnCenterClickListener {
        fun onCenterClick(view: View)
    }
}
