package com.weidai.wpai.component

import android.app.Application
import android.content.Context
import com.google.gson.Gson
import com.growingio.android.sdk.collection.Configuration
import com.growingio.android.sdk.collection.GrowingIO
import com.umeng.analytics.MobclickAgent
import com.weidai.wpai.BuildConfig
import com.weidai.wpai.component.appUpdate.HttpUtil
import com.weidai.wpai.http.param.ReportData
import com.weidai.wpai.util.ChannelUtil
import okhttp3.Response
import rx.Subscriber

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/7/4
 */
object StatisticalManager {

    fun init(context: Application) {
        initUmengStatistics(context)
        if (!BuildConfig.DEBUG) {
            initGrowingIO(context)
        }
    }

    private fun initGrowingIO(context: Application) {
        GrowingIO.startWithConfiguration(context, Configuration()
                .useID()
                .trackAllFragments()
                .setChannel(ChannelUtil.getChannel(context)))
    }


    private fun initUmengStatistics(context: Context) {
        val config = MobclickAgent.UMAnalyticsConfig(context,
                BuildConfig.UMENG_APP_KEY,
                ChannelUtil.getChannel(context))
        MobclickAgent.startWithConfigure(config)
    }

    fun onPageResume(context: Context) {
        MobclickAgent.onResume(context)
    }

    fun onPagePause(context: Context) {
        MobclickAgent.onPause(context)
    }

    fun onPageStart(pageName: String) {
        MobclickAgent.onPageStart(pageName)
    }

    fun onPageEnd(pageName: String) {
        MobclickAgent.onPageEnd(pageName)
    }

    fun reportAuctionDetail(auctionNo: String) {
        var data = ReportData.create()
        data.page_info = "竞拍详情页"
        data.request_url = "/auction/detail"
        data.data_code = auctionNo
        reportEventToWD(data)
    }

    fun reportEventToWD(data: ReportData) {
        var url = "https://apprd.weidai.com.cn/v1/servlet/ReceiveAdv"
        HttpUtil.requestPost(url, Gson().toJson(data), object : Subscriber<Response>() {
            override fun onNext(t: Response?) {
            }

            override fun onError(e: Throwable?) {
            }

            override fun onCompleted() {
            }
        })
    }
}
