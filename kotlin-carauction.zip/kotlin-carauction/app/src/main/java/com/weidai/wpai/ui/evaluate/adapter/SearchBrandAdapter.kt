package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.bean.CarSearchBean
import com.weidai.wpai.ui.evaluate.dialog.CarModelDialog
import com.weidai.wpai.ui.view.StatusBarCompat
import kotlinx.android.synthetic.main.car_view_item_search_result.view.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/21
 */
class SearchBrandAdapter(val context: Context, val baseView: View) : RecyclerView.Adapter<SearchBrandAdapter.ViewHolder>() {
    var dataList: MutableList<CarSearchBean.CarBrands> = ArrayList()
    var inflater: LayoutInflater = LayoutInflater.from(context)

    fun refreshDatas(datas: List<CarSearchBean.CarBrands>?) {
        this.dataList.clear()
        if (datas != null && datas.size > 0) {
            this.dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = inflater.inflate(R.layout.car_view_item_search_result, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            var data = dataList[position]
            itemView.textView.text = data.brandName
            itemView.textView.setOnClickListener {
                var top = baseView.bottom + StatusBarCompat.getStatusBarHeight(context) + 1
                var dialog = CarModelDialog(context, top, data.brandName)
                dialog.show()
            }
        }
    }
}

