package com.weidai.wpai.component.cityPick.db

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.text.TextUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.weidai.wpai.component.cityPick.CityBean
import com.weidai.wpai.component.cityPick.db.City.Companion.ID
import com.weidai.wpai.component.cityPick.db.City.Companion.LEVEL
import com.weidai.wpai.component.cityPick.db.City.Companion.NAME
import com.weidai.wpai.component.cityPick.db.City.Companion.PARENT_ID
import com.weidai.wpai.component.cityPick.db.City.Companion.PARENT_NAME
import com.weidai.wpai.component.cityPick.db.City.Companion.PINYIN
import com.weidai.wpai.component.cityPick.db.City.Companion.PY
import com.weidai.wpai.component.cityPick.db.City.Companion.TABLE_NAME
import com.weidai.wpai.extensions.equalsIgnoreUpLow
import com.weidai.wpai.util.LogUtil
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.*
import kotlin.collections.ArrayList


class DBManager(val context: Context) {
    internal var dbOpenHelper: DBOpenHelper = DBOpenHelper(context)

    val cityCount: Long
        get() {
            val db = dbOpenHelper.readableDatabase
            var sql = "select count(*) from ${City.TABLE_NAME}"
            var count = db.compileStatement(sql).simpleQueryForLong()
            db.close()
            LogUtil.d("DBManager cityCount = " + count)
            return count
        }

    fun importCity() {
        var reader = BufferedReader(InputStreamReader(context.assets.open("city")))
        var cityList = Gson().fromJson<List<CityBean>>(reader,
                object : TypeToken<List<CityBean>>() {}.type)
        LogUtil.d("DBManager cityList size = " + cityList.size)
        var dbList = ArrayList<City>()
        cityList.forEachIndexed { index, cityBean ->
            var city = cityBean.toDbCity()
            cityList.forEach {
                if (it.code.equals(city.parentId)) {
                    city.parentName = it.shortName
                }
            }
            dbList.add(city)
        }
        saveCitys(dbList)
    }

    fun saveCitys(cityList: List<City>): Boolean {
        val db = dbOpenHelper.writableDatabase
        db.beginTransaction()
        try {
            db.delete(TABLE_NAME, null, null)
            for (city in cityList) {
                val values = ContentValues()
                values.put(ID, city.id)
                values.put(NAME, city.name)
                values.put(PARENT_ID, city.parentId)
                values.put(PINYIN, city.pinyin)
                values.put(PARENT_NAME, city.parentName)
                values.put(PY, city.py)
                values.put(LEVEL, city.level)
                db.insert(TABLE_NAME, null, values)
            }
            db.setTransactionSuccessful()
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            db.endTransaction()
            db.close()
        }
    }

    fun getProvinces(): List<City> {
        val db = dbOpenHelper.readableDatabase
        val cursor = db.rawQuery("select * from $TABLE_NAME where $LEVEL = ${City.LEVEL_PROVINCE}", null)
        val result = ArrayList<City>()
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor))
        }
        cursor.close()
        db.close()
        Collections.sort(result, CityComparator())
        return result
    }

    fun getCitys(parentId: String): List<City> {
        val db = dbOpenHelper.readableDatabase
        val cursor = db.rawQuery("select * from $TABLE_NAME where $PARENT_ID = $parentId", null)
        val result = ArrayList<City>()
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor))
        }
        cursor.close()
        db.close()
        Collections.sort(result, CityComparator())
        return result
    }

    fun getAllCitys(): List<City> {
        val db = dbOpenHelper.readableDatabase
        val cursor = db.rawQuery("select * from $TABLE_NAME where $LEVEL = ${City.LEVEL_CITY}", null)
        val result = ArrayList<City>()
        while (cursor.moveToNext()) {
            result.add(buildCity(cursor))
        }
        cursor.close()
        db.close()
        return result
    }

    fun getLocalCity(cityName: String?): City? {
        var dbCity: City? = null
        if (TextUtils.isEmpty(cityName)) {
            return dbCity
        }
        getAllCitys().forEach {
            if (cityName!!.contains(it.name.toString())) {
                dbCity = it
            }
        }
        return dbCity
    }

    fun getAllSearchIndex(): List<String> {
        val db = dbOpenHelper.readableDatabase
        val cursor = db.rawQuery("select * from $TABLE_NAME where $LEVEL = ${City.LEVEL_CITY}", null)
        val result = ArrayList<String>()
        while (cursor.moveToNext()) {
            val name = cursor.getString(cursor.getColumnIndex(NAME))
            val pinyin = cursor.getString(cursor.getColumnIndex(PINYIN))
            result.add(name)
            result.add(pinyin)
        }
        cursor.close()
        db.close()
        return result
    }

    fun getCitys(ids: List<String>): List<City> {
        var result = ArrayList<City>()
        val db = dbOpenHelper.readableDatabase
        ids.forEach {
            var id = if (it.equals("all")) "0" else it
            val cursor = db.rawQuery(" select * from $TABLE_NAME where $ID = $id ", null)
            if (cursor.moveToNext()) {
                result.add(buildCity(cursor))
            }
            cursor.close()
        }
        db.close()
        return result
    }

    fun searchCitys(keyWord: String, choose: Boolean = false): List<City> {
        var result = ArrayList<City>()
        getAllCitys().forEach {
            if (choose) {
                if (it.name!!.equals(keyWord)) {
                    result.add(it)
                }
                if (it.pinyin!!.equals(keyWord)) {
                    result.add(it)
                }
            } else {
                if (it.name!!.contains(keyWord)) {
                    result.add(it)
                }
                if (it.pinyin!!.toUpperCase().contains(keyWord.toUpperCase())) {
                    result.add(it)
                }
                if (it.py!!.equalsIgnoreUpLow(keyWord)) {
                    result.add(it)
                }
            }
        }
        return result
    }

    private fun buildCity(cursor: Cursor): City {
        val city = City()
        val id = cursor.getString(cursor.getColumnIndex(ID))
        val name = cursor.getString(cursor.getColumnIndex(NAME))
        val pinyin = cursor.getString(cursor.getColumnIndex(PINYIN))
        val parentId = cursor.getString(cursor.getColumnIndex(PARENT_ID))
        val parentName = cursor.getString(cursor.getColumnIndex(PARENT_NAME))
        val py = cursor.getString(cursor.getColumnIndex(PY))
        val level = cursor.getInt(cursor.getColumnIndex(LEVEL))
        city.id = id
        city.name = name
        city.pinyin = pinyin
        city.parentId = parentId
        city.parentName = parentName
        city.py = py
        city.level = level
        city.type = level
        return city
    }

    /**
     * sort by a-z
     */
    private inner class CityComparator : Comparator<City> {
        override fun compare(lhs: City, rhs: City): Int {
            val a = lhs.pinyin!!.substring(0, 1)
            val b = rhs.pinyin!!.substring(0, 1)
            return a.compareTo(b)
        }
    }
}
