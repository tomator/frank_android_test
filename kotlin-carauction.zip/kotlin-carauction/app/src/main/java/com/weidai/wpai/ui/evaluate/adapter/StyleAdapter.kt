package com.weidai.wpai.ui.evaluate.adapter

import android.content.Context
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.bean.EvaluateCar
import kotlinx.android.synthetic.main.car_view_model_item.view.*
import java.util.*

/**
 * author zaaach on 2016/1/26.
 */
class StyleAdapter(context: Context) : RecyclerView.Adapter<StyleAdapter.ViewHolder>() {
    var dataList: MutableList<EvaluateCar> = ArrayList()
    var inflater: LayoutInflater = LayoutInflater.from(context)

    fun refreshDatas(datas: List<EvaluateCar>?) {
        this.dataList.clear()
        if (datas != null && datas.size > 0) {
            Collections.sort(datas) { o1, o2 ->
                -o1.outYear!!.compareTo(o2.outYear!!)
            }
            this.dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = inflater.inflate(R.layout.car_view_model_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(position)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        fun bindData(position: Int) {
            var data = dataList[position]
            itemView.groupTV.text = "${data.outYear}款"
            itemView.modelTV.text = data.modelDetail
            itemView.modelTV.setOnClickListener {
                RxBus.get().post(EventKey.KEY_CHOOSE_CAR_EVALUATE, data)
            }
            itemView.groupTV.visibility = View.VISIBLE
            if (position != 0) {
                var previous = dataList[position - 1]
                if (previous.outYear.equals(data.outYear)) {
                    itemView.groupTV.visibility = View.GONE
                }
            }
        }
    }
}
