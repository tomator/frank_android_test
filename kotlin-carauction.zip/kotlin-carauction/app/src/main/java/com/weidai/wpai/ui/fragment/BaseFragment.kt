package com.weidai.wpai.ui.fragment

import android.os.Bundle
import android.support.v4.app.Fragment

import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.component.StatisticalManager

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/8
 */
open class BaseFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RxBus.get().register(this)
    }

    override fun onResume() {
        super.onResume()
        StatisticalManager.onPageStart(javaClass.simpleName)
    }

    override fun onPause() {
        super.onPause()
        StatisticalManager.onPageEnd(javaClass.simpleName)
    }

    override fun onDestroy() {
        super.onDestroy()
        RxBus.get().unregister(this)
    }
}
