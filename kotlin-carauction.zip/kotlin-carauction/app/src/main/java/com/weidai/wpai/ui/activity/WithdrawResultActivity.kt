package com.weidai.wpai.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.weidai.wpai.R
import kotlinx.android.synthetic.main.activity_withdraw_result.*

class WithdrawResultActivity : BaseActivity() {

    private var type: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_withdraw_result)
        navigationView.setTitle("提现")
        type = intent.getIntExtra("type", TYPE_FAILED)
        resultIV.setImageResource(R.mipmap.ic_result_success)
        resultTV.text = "提现申请成功！"
        descriptionTV.text = "预计一个工作日内到账，敬请留意。"
        returnBtn.setOnClickListener { finish() }
    }

    companion object {
        val TYPE_FAILED = 1
        val TYPE_SUCCESS = 2
        val TYPE_SUCCESS_WAIT = 3

        fun gotoThis(context: Context, type: Int) {
            val intent = Intent(context, WithdrawResultActivity::class.java)
            intent.putExtra("type", type)
            context.startActivity(intent)
        }
    }
}
