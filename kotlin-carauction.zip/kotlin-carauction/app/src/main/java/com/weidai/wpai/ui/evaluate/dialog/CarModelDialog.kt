package com.weidai.wpai.ui.evaluate.dialog

import android.support.v7.widget.LinearLayoutManager
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.extensions.displayRoundAssets
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.http.bean.ModelBean
import com.weidai.wpai.ui.evaluate.adapter.BrandListAdapter
import com.weidai.wpai.ui.evaluate.adapter.ModelAdapter
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.car_dialog_model.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/16
 */

class CarModelDialog(context: android.content.Context, top: Int, val brand: String) : android.app.Dialog(context, com.weidai.wpai.R.style.Dialog_Fullscreen) {

    var adapter: ModelAdapter

    init {
        window!!.attributes.windowAnimations = com.weidai.wpai.R.style.DialogAnimRightIn
        setContentView(com.weidai.wpai.R.layout.car_dialog_model)
        var windowHeight = window!!.windowManager.defaultDisplay.height
        val realHeight = com.weidai.wpai.util.WindowUtil.getRealHeight(getContext())
        com.weidai.wpai.util.LogUtil.d("TOP_HEIGHT : realHeight = $realHeight, windowHeight = $windowHeight")
        windowHeight = if (realHeight > windowHeight) realHeight else windowHeight
        val params = window.attributes
        params.width = android.app.ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - top
        params.gravity = android.view.Gravity.BOTTOM
        window.attributes = params
        adapter = ModelAdapter(context)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(context)
        brandTV.text = brand
        brandIV.displayRoundAssets(brand)
        requestData()
        leftShadowView.setOnClickListener { cancel() }
        adapter.setItemClickListener(object : BrandListAdapter.ItemClickListener {
            override fun onItemClick(name: String) {
                CarStyleDialog(context, top, brand, name).show()
            }
        })
        setCanceledOnTouchOutside(true)
        RxBus.get().register(this)
        setOnDismissListener {
            RxBus.get().unregister(this)
        }
    }

    fun requestData() {
        com.weidai.wpai.http.Client.getService().carModelList(brand)
                .subscribeOn(rx.schedulers.Schedulers.io())
                .observeOn(rx.android.schedulers.AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Map<String, List<String>>>>() {
                    override fun onSuccess(result: Result<Map<String, List<String>>>) {
                        if (result.data != null) {
                            refreshView(result.data!!)
                        }
                    }
                })
    }

    fun refreshView(datas: Map<String, List<String>>) {
        var dataList = ArrayList<ModelBean>()
        for ((k, v) in datas) {
            dataList.add(ModelBean(k, 0))
            v.forEach {
                dataList.add(ModelBean(it, 1))
            }
        }
        adapter.refreshDatas(dataList)
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_EVALUATE)))
    fun onCarChoose(evaluateCar: EvaluateCar) {
        LogUtil.d(EventKey.TAG, "onCarChoose " + evaluateCar)
        cancel()
    }

}