package com.weidai.wpai.http;

import android.text.TextUtils;

import com.facebook.stetho.okhttp3.StethoInterceptor;
import com.franmontiel.persistentcookiejar.ClearableCookieJar;
import com.franmontiel.persistentcookiejar.PersistentCookieJar;
import com.franmontiel.persistentcookiejar.cache.SetCookieCache;
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor;
import com.weidai.wpai.App;
import com.weidai.wpai.BuildConfig;
import com.weidai.wpai.util.DeviceUtils;
import com.weidai.wpai.util.LogUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import okhttp3.Cache;
import okhttp3.CacheControl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

/**
 * Created by zhongyuan.jiang on 16/3/27 上午11:05.
 * Email jiang7637@gmail.com
 */
public class ApiHelper {
    private static final String HEADER_USER_SOURCE = "User-Source";
    private static final String HEADER_USER_VERSION = "User-Version";
    private static final String HEADER_USER_SOURCE_ANDROID = "wpai_andriod";
    private static final int HTTP_RESPONSE_DISK_CACHE_MAX_SIZE = 10 * 1024 * 1024;
    private static final long DEFAULT_TIMEOUT = 30;
    public static final String TAG = "ApiHelper";
    public static final String COOKIE_WPAI_TOKEN = "wpai_token";
    public static final String COOKIE_WPAI_CODE = "wpai_code";
    public static final String HEADER_ETAG = "ETag";
    public static final String HEADER_ETAG_BACK = "If-None-Match";

//    private static String wpai_token;
//    private static String wpai_code;
    private static String etag;

    static ClearableCookieJar cookieJar =
            new PersistentCookieJar(new SetCookieCache(), new SharedPrefsCookiePersistor(App.instance));

    static {
//        wpai_token = SpfUtils.getInstance().getString(SpfKey.COOKIE_WPAI_TOKEN, null);
//        wpai_code = SpfUtils.getInstance().getString(SpfKey.COOKIE_WPAI_CODE, null);
    }


    public static OkHttpClient createOkHttpClient() {
        OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .addNetworkInterceptor(createHeaderInterceptor())
                .addInterceptor(createCookieInterceptor())
                .addInterceptor(createCacheInterceptor())
                .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)//设置超时时间
                .writeTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);

        if (BuildConfig.DEBUG) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);
            okHttpBuilder.addInterceptor(logging);
            okHttpBuilder.addNetworkInterceptor(new StethoInterceptor());
        }
        File baseDir = App.Companion.getInstance().getCacheDir();
        if (baseDir != null) {
            final File cacheDir = new File(baseDir, "httpCache");
            okHttpBuilder.cache(new Cache(cacheDir, HTTP_RESPONSE_DISK_CACHE_MAX_SIZE));
        }
        return okHttpBuilder.build();
    }

    private static Interceptor createHeaderInterceptor() {
        Interceptor interceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();
                Request.Builder builder = request.newBuilder();
                builder.addHeader(HttpConstant.Header.ACCEPT, HttpConstant.Header.ACCEPT_CONTENT);
                builder.addHeader(HEADER_USER_SOURCE, HEADER_USER_SOURCE_ANDROID);
                builder.addHeader(HEADER_USER_VERSION, DeviceUtils.getVersionName(App.Companion.getInstance()));
//                if (!TextUtils.isEmpty(wpai_token)) {
//                    builder.addHeader(HttpConstant.Header.COOKIE, wpai_token);
//                }
//                if (!TextUtils.isEmpty(wpai_code)) {
//                    builder.addHeader(HttpConstant.Header.COOKIE, wpai_code);
//                }
                if ("GET".equalsIgnoreCase(request.method())
                        && !TextUtils.isEmpty(etag)
                        && TextUtils.isEmpty(request.header(HEADER_ETAG_BACK))) {
                    builder.addHeader(HEADER_ETAG_BACK, etag);
                }
                return chain.proceed(builder.build());
            }
        };

        return interceptor;
    }

    private static Interceptor createCacheInterceptor() {
        Interceptor cacheInterceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request();
                String cacheControl = request.cacheControl().toString();
                if (!DeviceUtils.isNetworkConnected(App.Companion.getInstance())) {
                    if (TextUtils.isEmpty(cacheControl)) {
                        request = request.newBuilder().cacheControl(CacheControl.FORCE_NETWORK).build();
                    } else {
                        request = request.newBuilder().cacheControl(CacheControl.FORCE_CACHE).build();
                    }
                }
                Response response = chain.proceed(request);
                if (DeviceUtils.isNetworkConnected(App.Companion.getInstance())) {
                    response.newBuilder()
                            .removeHeader("Pragma")
                            .header("Cache-Control", cacheControl)
                            .build();
                }
                return response;
            }
        };
        return cacheInterceptor;
    }

    private static Interceptor createCookieInterceptor() {
        Interceptor cacheInterceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Response response = chain.proceed(chain.request());
                if (response.code() == HttpURLConnection.HTTP_OK) {
                    List<String> cookies = response.headers().values("Set-Cookie");
//                    for (String cookieValue : cookies) {
////                        LogUtil.d(TAG, " cookieValue: " + cookieValue);
//                        if (cookieValue != null && cookieValue.contains(COOKIE_WPAI_TOKEN)) {
//                            wpai_token = cookieValue.substring(0, cookieValue.indexOf(";"));
//                            SpfUtils.getInstance().saveData(SpfKey.COOKIE_WPAI_TOKEN, wpai_token);
//                        }
//                        if (cookieValue != null && cookieValue.contains(COOKIE_WPAI_CODE)) {
//                            wpai_code = cookieValue.substring(0, cookieValue.indexOf(";"));
//                            SpfUtils.getInstance().saveData(SpfKey.COOKIE_WPAI_CODE, wpai_code);
//                        }
//                    }
                    if ("GET".equalsIgnoreCase(response.request().method())) {
                        etag = response.header(HEADER_ETAG);
                    }
                }
                return response;
            }
        };
        return cacheInterceptor;
    }

    public static OkHttpClient createImageLoaderClient() {
        OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder()
                .cookieJar(cookieJar)
                .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS);
        okHttpBuilder.addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request request = chain.request().newBuilder()
                        .addHeader("Cache-Control", "max-stale=3 * 24 * 3600") // 图片全局3天缓存
                        .build();
                return chain.proceed(request);
            }
        });
        File baseDir = App.Companion.getInstance().getCacheDir();
        if (baseDir != null) {
            final File cacheDir = new File(baseDir, "ImageCache");
            okHttpBuilder.cache(new Cache(cacheDir, HTTP_RESPONSE_DISK_CACHE_MAX_SIZE * 5));
        }
        return okHttpBuilder.build();
    }

    public static OkHttpClient createNoCacheClient() {
        OkHttpClient.Builder okHttpBuilder = new OkHttpClient.Builder()
                .cookieJar(cookieJar);
        return okHttpBuilder.build();
    }

    /**
     * 设置私有证书，目前只有客户端单向验证
     *
     * @param builder
     */
    public static void setCertificates(OkHttpClient.Builder builder) {
        if (HostConfig.API_HOST.indexOf("https://www.houbank.com") > -1) {
            setCertificates(builder, "https/server.crt", "https/servernew.crt");
        }
    }

    public static void setCertificates(OkHttpClient.Builder builder, String... assetsPaths) {
        List<InputStream> inputStreams = new ArrayList<>();
        try {
            for (String assetsPath : assetsPaths) {
                InputStream inputStream = App.Companion.getInstance().getAssets().open(assetsPath);
                inputStreams.add(inputStream);
            }
            SSLSocketFactory sslSocketFactory = loadCertificates(inputStreams);
            builder.sslSocketFactory(sslSocketFactory);
            LogUtil.d(TAG, " load certificates success !!! ");
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.e(TAG, "load certificates " + assetsPaths + " failed !!! ");
        }
    }

    public static SSLSocketFactory loadCertificates(List<InputStream> certificates) throws CertificateException,
            KeyStoreException, NoSuchAlgorithmException, IOException, KeyManagementException {
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null);
        int index = 0;
        for (InputStream certificate : certificates) {
            String certificateAlias = Integer.toString(index++);
            Certificate ca = certificateFactory.generateCertificate(certificate);
            keyStore.setCertificateEntry(certificateAlias, ca);
            if (certificate != null) {
                certificate.close();
            }
        }
        SSLContext sslContext = SSLContext.getInstance("TLS");
        TrustManagerFactory trustManagerFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());

        trustManagerFactory.init(keyStore);
        sslContext.init(null, trustManagerFactory.getTrustManagers(), new SecureRandom());
        return sslContext.getSocketFactory();
    }

}
