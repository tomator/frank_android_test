package com.weidai.wpai.http;

import android.text.TextUtils;

/**
 * Author: chenqian <br>
 * Date: 17/2/23 <br>
 * Desc: <br>
 * Copyright:© 2011-2017 Weidai(Hangzhou) Financial Information Services Co., Ltd. All rights reserved. <br>
 */

public class ApiException extends RuntimeException {

    /*错误码*/
    private int code;
    /*显示的信息*/
    private String displayMessage;

    public ApiException(int code, String showMsg) {
        super(showMsg);
        setCode(code);
        if (TextUtils.isEmpty(showMsg)){
            showMsg = "服务器异常，请稍后重试("+code+")";
        }
        setDisplayMessage(showMsg+"("+code+")");
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDisplayMessage() {
        return displayMessage;
    }

    public void setDisplayMessage(String displayMessage) {
        this.displayMessage = displayMessage;
    }
}
