package com.weidai.wpai.ui.activity

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.NewRecordBean
import com.weidai.wpai.http.param.SearchAuctionNewsVQO
import com.weidai.wpai.ui.adapter.AllRecordAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import kotlinx.android.synthetic.main.activity_all_record.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class AllRecordActivity : BaseActivity() {

    lateinit var adapter: AllRecordAdapter
    private var index = Bean.PAGE_INDEX
    private val PAGE_SIZE = 15
    lateinit var auctionNo: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_record)
        auctionNo = intent.getStringExtra("auctionNo")
        navigationView.setTitle("竞价记录")
        initRefresh()
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(this)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(this))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200)
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(this,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = AllRecordAdapter(this)
        recyclerView.adapter = adapter
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        Client.getService().auctionRecords(SearchAuctionNewsVQO(auctionNo, index, PAGE_SIZE))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<ListData<NewRecordBean>>>(ptrFrame) {
                    override fun onSuccess(result: Result<ListData<NewRecordBean>>) {
                        super.onSuccess(result)
                        val dataList = result.data!!.data!!
                        if (refresh) {
                            adapter.refreshDatas(dataList)
                        } else {
                            adapter.addDatas(dataList)
                        }
                        if (dataList.size >= Bean.PAGE_SIZE) {
                            ptrFrame.mode = PtrFrameLayout.Mode.BOTH
                            index++
                        } else {
                            ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
                        }
                    }
                })
    }

    companion object {

        fun gotoThis(context: Context, auctionNo: String) {
            val intent = Intent(context, AllRecordActivity::class.java)
            intent.putExtra("auctionNo", auctionNo)
            context.startActivity(intent)
        }
    }
}
