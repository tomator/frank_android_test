package com.weidai.wpai.ui.dialog

import android.app.ActionBar
import android.app.Dialog
import android.content.Context
import android.text.TextUtils
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.TextView
import com.squareup.picasso.MemoryPolicy
import com.squareup.picasso.Picasso
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.http.HostConfig
import com.weidai.wpai.ui.view.NumberInputView
import com.weidai.wpai.ui.view.StatusBarCompat
import kotlinx.android.synthetic.main.dialog_image_auth_input.*
import java.util.*

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/22
 */
class ImageAuthDialog(context: Context) : Dialog(context, R.style.Dialog_Fullscreen) {

    internal var list: MutableList<String> = ArrayList()
    lateinit internal var gridAdapter: GridAdapter
    internal var imageCodeUrl = HostConfig.API_HOST + "valid/genimg"
    private val picasso: Picasso

    init {
        init()
        initGridView()
        picasso = ImageLoader.instance.getNoCacheClient()
        picasso.load(imageCodeUrl).memoryPolicy(MemoryPolicy.NO_CACHE).into(imageAuthIV)
        refreshLL!!.setOnClickListener { picasso.load(imageCodeUrl).memoryPolicy(MemoryPolicy.NO_CACHE).into(imageAuthIV) }
        numberInputView!!.addInputListener(object : NumberInputView.OnInputListener {
            override fun onInput(input: String, last: String) {
                if (input.length <= IMAGE_CODE_LEN) {
                    for (i in 0..IMAGE_CODE_LEN - 1) {
                        list[i] = ""
                    }
                    for (i in 0..input.length - 1) {
                        list[i] = input[i].toString()
                    }
                    gridAdapter.notifyDataSetChanged()
                } else {
                    numberInputView!!.initValue(input.substring(0, 4))
                }
            }
        })
        closeIV!!.setOnClickListener { cancel() }
    }

    private fun init() {
        val window = window
        window!!.attributes.windowAnimations = R.style.DialogAnimFadeIn
        val windowHeight = window.windowManager.defaultDisplay.height
        val statusBarHeight = StatusBarCompat.getStatusBarHeight(context)
        val params = window.attributes
        params.width = ActionBar.LayoutParams.MATCH_PARENT
        params.height = windowHeight - statusBarHeight
        params.gravity = Gravity.BOTTOM
        window.attributes = params
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_image_auth_input, null)
        setContentView(view)
    }

    private fun initGridView() {
        for (i in 0..IMAGE_CODE_LEN - 1) {
            list.add("")
        }
        gridAdapter = GridAdapter()
        gridView!!.adapter = gridAdapter
    }

    inner class GridAdapter : BaseAdapter() {

        override fun getCount(): Int {
            return list.size
        }

        override fun getItem(position: Int): Any {
            return list[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view = LayoutInflater.from(context)
                    .inflate(R.layout.view_auth_input_item, parent, false)
            val height = parent!!.layoutParams.height
            val textView = view.findViewById(R.id.textView) as TextView
            view.layoutParams = AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, height)
            val text = list[position]
            textView.isSelected = !TextUtils.isEmpty(text)
            textView.text = text
            return view
        }
    }

    companion object {
        private val IMAGE_CODE_LEN = 4
    }

}
