package com.weidai.wpai.ui.activity

import android.os.Bundle
import android.view.View
import com.weidai.wpai.R
import com.weidai.wpai.component.share.ShareBean
import com.weidai.wpai.component.share.ShareUtils
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.InvitationInfoBean
import com.weidai.wpai.ui.dialog.ProgressDialog
import kotlinx.android.synthetic.main.activity_share.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class ShareActivity : BaseActivity() {

    var invitationUrl = "https://www.wpai.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share)
        navigationView.setTitle("邀请好友注册")
        requestInvitationInfo()
        requestInvitationUrl()
        wechatLL.setOnClickListener { v -> onViewClicked(v) }
        wechatGroupLL.setOnClickListener { v -> onViewClicked(v) }
    }

    private fun requestInvitationInfo() {
        Client.getService().invitationInfo()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<InvitationInfoBean>>() {
                    override fun onSuccess(result: Result<InvitationInfoBean>) {
                        refreshView(result.data!!)
                    }
                })
    }

    private fun requestInvitationUrl(){
        var progressDialog = ProgressDialog(this, "正在生成邀请链接...")
        progressDialog.show()
        Client.getService().invitationUrl()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<String>>(progressDialog){
                    override fun onSuccess(result: Result<String>) {
                        invitationUrl = result.data!!
                    }
                })
    }

    private fun refreshView(info: InvitationInfoBean) {
        val desc = "・好友注册成功后每天可获得${info.freeCountPerDay}次免费查维保机会，" +
                "\n・每邀请一个新好友，您可获得${info.freeCountPerInvitation}次免费查维保机会，" +
                "\n・奖励次数可累计，无时间限制。"
        descriptionTV.text = desc
        servicePhoneTV.text = "客服电话：${info.serviceTel}"
        invitationCountTV.text = "已邀请人数：${info.invitationNumber}"
        rewardCountTV.text = "累计获得次数：${info.cmQueryCount}"
    }

    fun onViewClicked(view: View) {
        val shareBean = ShareBean()
        shareBean.title = "领取免费查汽车4S店记录机会"
        shareBean.description = "上微车拍，免费查维保"
        shareBean.shareUrl = invitationUrl
        shareBean.imgRes = R.mipmap.ic_app_logo
        when (view.id) {
            R.id.wechatLL -> shareBean.type = ShareBean.TYPE_WECHAT
            R.id.wechatGroupLL -> shareBean.type = ShareBean.TYPE_WECHAT_GROUP
        }
        ShareUtils.shareToWeChat(this, shareBean)
    }
}
