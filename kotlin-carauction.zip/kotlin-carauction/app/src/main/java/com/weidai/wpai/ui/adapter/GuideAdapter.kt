package com.weidai.wpai.ui.adapter

/**
 * Created by Aeiric on 16-11-4.
 */

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.weidai.wpai.ui.fragment.GuideFragment
import java.util.*

class GuideAdapter(fm: FragmentManager) : FragmentPagerAdapter(fm) {
    private var list: MutableList<Fragment> = ArrayList()

    init {
        list.add(GuideFragment.newInstance(1))
        list.add(GuideFragment.newInstance(2))
        list.add(GuideFragment.newInstance(3))
        list.add(GuideFragment.newInstance(4))
    }

    val fragmentList: List<Fragment>
        get() = list

    fun setData(list: MutableList<Fragment>) {
        this.list = list
    }

    override fun getItem(arg0: Int): Fragment {
        return list[arg0]
    }

    override fun getCount(): Int {
        return list.size
    }
}
