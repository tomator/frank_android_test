package com.weidai.wpai.http.base

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/20
 */
class ResultException(var code: Int, msg: String?) : Throwable(msg), Bean {

    constructor(msg: String) : this(Result.CODE_EXCEPTION, msg)
}
