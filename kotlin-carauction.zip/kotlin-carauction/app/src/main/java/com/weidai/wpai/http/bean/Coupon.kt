package com.weidai.wpai.http.bean

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/31
 */

/**
configName	string	Y	优惠券名称
model	string	Y	型号
usedCarName	string	Y	使用车辆名
status	number	Y	状态,0-未领取,1-已领取,2-已使用,3-已失效
couponPrice	number	Y	优惠后价格
usedRange	number	Y	使用范围，0-竞拍提车，1-维保查询
currentPrice	number	Y	当前价
code	string	Y	优惠券编号
valueMax	number	Y	优惠券可用于最大价值
usedTime	Date	Y	使用时间
endTime	Date	Y	有效期结束时间
type	number	Y	优惠券类型，0-代金券，1-折扣券，2-抵价券
valueMin	number	Y	优惠券可用于最小价值
startTime	Date	Y	有效期开始时间
id	number	Y	自增长id
usedCarId	number	Y	使用车辆ID
receiveTime	Date	Y	领取时间
usedDescribe	string	Y	使用条件描述
value	number	Y	优惠券价值
brand	string	Y	车辆品牌
 */
data class Coupon(var configName: String,
                  var auctionNo: String,
                  var model: String,
                  var usedCarName: String,
                  var status: Int,
                  var couponPrice: String,
                  var usedRange: Int,
                  var currentPrice: String,
                  var code: String,
                  var valueMax: String,
                  var usedTime: String,
                  var endTime: String,
                  var type: Int,
                  var valueMin: String,
                  var startTime: String,
                  var id: Int,
                  var usedCarId: Int,
                  var receiveTime: String,
                  var usedDescribe: String,
                  var value: String,
                  var brand: String) {
    companion object {
        val STATUS_NOT_GET = 0
        val STATUS_NOT_USE = 1
        val STATUS_ALREADY_USED = 2
        val STATUS_OVERDUE = 3
        val STATUS_CHOOSE_USABLE = 10
        val STATUS_CHOOSE_DISABLE = 11

        val TYPE_DAIJING = 0
        val TYPE_ZHEKOU = 1
        val TYPE_DIJIA = 2
    }
}