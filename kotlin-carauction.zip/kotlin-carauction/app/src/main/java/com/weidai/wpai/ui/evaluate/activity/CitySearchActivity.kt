package com.weidai.wpai.ui.evaluate.activity

import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.text.TextUtils
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.component.cityPick.db.DBManager
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.evaluate.adapter.BrandListAdapter
import com.weidai.wpai.ui.evaluate.adapter.LabelAdapter
import com.weidai.wpai.ui.evaluate.adapter.SearchCityAdapter
import com.weidai.wpai.ui.view.FlowLayoutManager
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfKey
import com.weidai.wpai.util.preferences.SpfUtils
import kotlinx.android.synthetic.main.activity_city_search.*


class CitySearchActivity : BaseActivity() {

    lateinit var dbManager: DBManager
    lateinit var cityAdapter: SearchCityAdapter
    lateinit var histroyAdapter: LabelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_city_search)
        dbManager = DBManager(this)
        navigationView.searchView.edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        navigationView.searchView.edit.hint = "请输入搜索城市"
        navigationView.searchView.edit.setOnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                App.instance.hideSoftInput(navigationView.searchView.edit.windowToken)
                search()
            }
            false
        }
        navigationView.searchView.setOnTextChange { input ->
            if (TextUtils.isEmpty(input)) {
                recyclerView.visibility = View.GONE
                noSearchLL.visibility = View.VISIBLE
            }
        }

        navigationView.onSearchListener = View.OnClickListener {
            search()
        }

        cityAdapter = SearchCityAdapter(this)
        recyclerView.adapter = cityAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)
        initHistory()
        clearHistroyIV.setOnClickListener {
            SpfUtils.getInstance().saveData(SpfKey.SEARCH_HISTROY_CITY, null)
            refreshHistroy()
        }
    }

    fun initHistory() {
        histroyAdapter = LabelAdapter(this)
        histroyAdapter.itemClickListener = object : BrandListAdapter.ItemClickListener {
            override fun onItemClick(name: String) {
                onLabelClick(name)
            }
        }
        historyRecyclerView.adapter = histroyAdapter
        var layoutManager = FlowLayoutManager(this)
        historyRecyclerView.layoutManager = layoutManager
        refreshHistroy()
    }

    fun refreshHistroy() {
        var history = SpfUtils.getInstance().getStringList(SpfKey.SEARCH_HISTROY_CITY)
        histroyAdapter.refreshDatas(history)
    }

    fun onLabelClick(label: String) {
        navigationView.searchView.text = label
        search()
    }

    fun search(choose: Boolean = false) {
        var keyWord = navigationView.searchView.text.toString()
        if (!TextUtils.isEmpty(keyWord)) {
            var cityList = dbManager.searchCitys(keyWord, choose)
            if (cityList.size > 0) {
                SpfUtils.getInstance().addStringListItem(SpfKey.SEARCH_HISTROY_CITY, keyWord)
                refreshHistroy()
                recyclerView.visibility = View.VISIBLE
                noSearchLL.visibility = View.GONE
            } else {
                recyclerView.visibility = View.GONE
                noSearchLL.visibility = View.VISIBLE
            }
            cityAdapter.refreshDatas(cityList)
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CITY)))
    fun onCityChoose(city: City) {
        LogUtil.d(EventKey.TAG, "onCityChoose " + city)
        finish()
    }
}
