package com.weidai.wpai.ui.dialog;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.hwangjr.rxbus.RxBus;
import com.weidai.wpai.R;
import com.weidai.wpai.util.LogUtil;
import com.weidai.wpai.util.WindowUtil;

import static com.weidai.wpai.common.EventKey.KEY_FILTER_BAR_ON_CLICK;
import static com.weidai.wpai.common.EventKey.KEY_FILTER_DIALOG_DISMISS;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/11
 */
public abstract class BaseFilterDialog extends Dialog {
    protected int TOP_HEIGHT;
    protected int FILTER_BAR_HEIGHT;
    protected int windowHeight;
    protected int windowWidth;
    protected BaseFilterDialog dialogThis;
    protected View baseView;

    public BaseFilterDialog(@NonNull Context context, View baseView) {
        super(context, R.style.Dialog_Fullscreen);
        getWindow().getAttributes().windowAnimations = R.style.DialogAnimFadeIn;
        this.baseView = baseView;
        TOP_HEIGHT = baseView.getBottom();
        FILTER_BAR_HEIGHT = baseView.getMeasuredHeight();
        dialogThis = this;
        init();
        setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                RxBus.get().post(KEY_FILTER_DIALOG_DISMISS, dialogThis);
            }
        });
    }

    private void init() {
        View view = LayoutInflater.from(getContext()).inflate(getLayoutRes(), null);
        setContentView(view);
        Window window = getWindow();
        windowHeight = window.getWindowManager().getDefaultDisplay().getHeight();
        windowWidth = window.getWindowManager().getDefaultDisplay().getWidth();
        TOP_HEIGHT = baseView.getBottom();
        int realHeight = WindowUtil.getRealHeight(getContext());
        LogUtil.d("TOP_HEIGHT : realHeight = " + realHeight + ", windowHeight = " + windowHeight);
        windowHeight = realHeight > windowHeight ? realHeight : windowHeight;
        WindowManager.LayoutParams params = window.getAttributes();
        params.width = ActionBar.LayoutParams.MATCH_PARENT;
        params.height = windowHeight - TOP_HEIGHT;
        params.gravity = Gravity.BOTTOM;
        window.setAttributes(params);
        initView();
    }

    protected abstract int getLayoutRes();

    protected abstract void initView();

    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            LogUtil.d("onTouchEvent y " + event.getY());
            if (event.getY() < 0 && event.getY() > -FILTER_BAR_HEIGHT) {
                int position;
                if (event.getX() < windowWidth / 3) {
                    position = 0;
                } else if (event.getX() < windowWidth * 2 / 3) {
                    position = 1;
                } else {
                    position = 2;
                }
                RxBus.get().post(KEY_FILTER_BAR_ON_CLICK, position);
                dismiss();
                return true;
            }
        }
        return super.onTouchEvent(event);
    }

}
