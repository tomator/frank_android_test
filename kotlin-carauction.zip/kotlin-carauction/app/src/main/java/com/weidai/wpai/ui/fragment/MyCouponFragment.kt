package com.weidai.wpai.ui.fragment

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.Coupon
import com.weidai.wpai.http.param.SearchTradeVQO
import com.weidai.wpai.ui.activity.MyOrderActivity
import com.weidai.wpai.ui.adapter.MyCouponAdapter
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import kotlinx.android.synthetic.main.fragment_my_coupon.*
import kotlinx.android.synthetic.main.view_my_auction_null.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/19
 */
class MyCouponFragment : BaseFragment() {

    private var type = Coupon.STATUS_NOT_USE
    lateinit var adapter: MyCouponAdapter
    private var index = Bean.PAGE_INDEX

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            type = arguments.getInt(ARG_TYPE)
        }
    }

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_my_coupon, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        initRefresh()
        when (type) {
            Coupon.STATUS_NOT_USE -> toUseLL.visibility = View.VISIBLE
            Coupon.STATUS_ALREADY_USED -> toUseLL.visibility = View.GONE
            Coupon.STATUS_OVERDUE -> toUseLL.visibility = View.GONE
        }
        toUseTV.setOnClickListener {
            startActivity(Intent(context, MyOrderActivity::class.java)
                    .putExtra("position", 0))
        }
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(context)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(context))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(300)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200)
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        adapter = MyCouponAdapter(context, type)
        recyclerView.adapter = adapter
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        Client.getService().myCouponList(SearchTradeVQO(type, index, Bean.PAGE_SIZE))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<ListData<Coupon>>>(ptrFrame) {
                    override fun onSuccess(result: Result<ListData<Coupon>>) {
                        refreshView(refresh, result.data!!.data)
                    }

                    override fun onFailed() {
                        showContent(false)
                    }
                })
    }

    fun refreshView(refresh: Boolean, dataList: List<Coupon>? = null) {
        if (dataList == null || dataList.size == 0) {
            if (refresh) {
                showContent(false)
            }
        } else {
            showContent(true)
            if (refresh) {
                adapter.refreshDatas(dataList)
            } else {
                adapter.addDatas(dataList)
            }
            if (dataList.size >= Bean.PAGE_SIZE) {
                ptrFrame.mode = PtrFrameLayout.Mode.BOTH
                index++
            } else {
                ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
            }
        }
    }

    fun showContent(isShow: Boolean) {
        if (isShow) {
            recyclerView.visibility = View.VISIBLE
            auctionNullView.visibility = View.GONE
        } else {
            recyclerView.visibility = View.GONE
            auctionNullView.visibility = View.VISIBLE
            imageView.setImageResource(R.mipmap.ic_coupon_null)
            when (type) {
                Coupon.STATUS_NOT_USE -> textView.text = "暂无未使用优惠券"
                Coupon.STATUS_ALREADY_USED -> textView.text = "暂无已使用优惠券"
                Coupon.STATUS_OVERDUE -> textView.text = "暂无已失效优惠券"
            }
        }
    }

    companion object {
        private val ARG_TYPE = "ARG_TYPE"
        fun newInstance(type: Int): MyCouponFragment {
            val fragment = MyCouponFragment()
            val args = Bundle()
            args.putInt(ARG_TYPE, type)
            fragment.arguments = args
            return fragment
        }
    }
}
