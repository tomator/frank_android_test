package com.weidai.wpai.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.weidai.wpai.R;

public class TabView extends LinearLayout {

    private static final String TAG = "TabView";
    private static final float WEIGHT = 1.0f;
    private static final int WIDTH_ZERO = 0;
    private Context mContext;
    private OnCheckedListener mCheckedListener;
    private OnArrowDownListener mArrowDownListener;
    private CharSequence[] mContents;
    private int downPosition;
    private float textSize = 0;
    private float sideMargin = 0;

    public TabView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        setOrientation(LinearLayout.HORIZONTAL);
        initAttr(context, attrs);
        addTab(mContents);
    }

    private void initAttr(Context context, AttributeSet attrs) {
        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.TabView);
        mContents = typedArray.getTextArray(R.styleable.TabView_content);
        textSize = typedArray.getDimensionPixelSize(R.styleable.TabView_tabTextSize, 0);
        typedArray.recycle();
    }

    /**
     * 设置选项卡的内容
     *
     * @param resId
     */
    public void setContentView(int resId) {
        String[] contents = mContext.getResources().getStringArray(resId);
        addTab(contents);
    }

    /**
     * 设置index值的tab选项卡为选中状态。index要小于选项卡的数值，否者会数组越界
     *
     * @param index
     */
    public void setCheckViewByIndex(int index) {
        resetSelect();
        if (getChildCount() > 0 && index < getChildCount()) {
            getChildAt(index).findViewById(R.id.tv_content).setSelected(true);
            getChildAt(index).findViewById(R.id.bottom_line).setSelected(true);
        }
    }

    /**
     * 设置选项卡的内容
     */
    public void setContentView(String[] contents) {
        addTab(contents);
    }

    private void addTab(CharSequence[] contents) {
        if (contents == null || contents.length == 0)
            return;
        removeAllViews();
        int count = contents.length;
        for (int i = 0; i < count; i++) {
            final int index = i;
            View view = LayoutInflater.from(mContext).inflate(R.layout.view_tab_item, this, false);
            final TextView tvContent = (TextView) view.findViewById(R.id.tv_content);
            if (textSize > 0) {
                tvContent.setTextSize(TypedValue.COMPLEX_UNIT_PX, textSize);
            }
            final ImageView bottomLine = (ImageView) view.findViewById(R.id.bottom_line);
            tvContent.setText(contents[index]);
            view.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    if (mCheckedListener != null) {
                        mCheckedListener.checked(v, index);
                    }
                    resetSelect();
                    tvContent.setSelected(true);
                    bottomLine.setSelected(true);
                }
            });
            if (i == 0) {
                tvContent.setSelected(true);
                bottomLine.setSelected(true);
            }
            LinearLayout.LayoutParams layoutParams = (LayoutParams) bottomLine.getLayoutParams();
            layoutParams.width = (int) getTextViewLength(tvContent, tvContent.getText().toString());
            bottomLine.setLayoutParams(layoutParams);
            LayoutParams lp = new LayoutParams(WIDTH_ZERO, LayoutParams.MATCH_PARENT, WEIGHT);
            view.setLayoutParams(lp);
            addView(view);
        }
    }

    public static float getTextViewLength(TextView textView, String text) {
        TextPaint paint = textView.getPaint();
        float textLength = paint.measureText(text);
        return textLength;
    }

    private void resetSelect() {
        int count = getChildCount();
        for (int i = 0; i < count; i++) {
            getChildAt(i).findViewById(R.id.tv_content).setSelected(false);
            getChildAt(i).findViewById(R.id.bottom_line).setSelected(false);
        }
    }

    public void setOnCheckedLinstener(OnCheckedListener l) {
        mCheckedListener = l;
    }

    public interface OnCheckedListener {
        public void checked(View v, int index);
    }

    public interface OnArrowDownListener {
        public void clicked(View v, int index);
    }

    public String getCurrentTitle(int currentIndex) {
        if (mContents != null && mContents.length > 0 && currentIndex < mContents.length) {
            return (String) mContents[currentIndex];
        }
        return "";
    }

}
