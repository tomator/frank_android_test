package com.weidai.wpai.ui.fragment

import `in`.srain.cube.views.ptr.PtrDefaultHandler2
import `in`.srain.cube.views.ptr.PtrFrameLayout
import android.os.Build
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Bean
import com.weidai.wpai.http.base.ListData
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.SimpleAuctionBean
import com.weidai.wpai.ui.adapter.ProductListAdapter
import com.weidai.wpai.ui.view.AuctionToast
import com.weidai.wpai.ui.view.CustomGridLayoutManager
import com.weidai.wpai.ui.view.RefreshHelper
import com.weidai.wpai.ui.view.StatusBarCompat
import com.weidai.wpai.ui.view.ptr.CarRefreshHeader
import com.weidai.wpai.ui.view.ptr.DefaultFooter
import com.weidai.wpai.util.LogUtil
import kotlinx.android.synthetic.main.fragment_auction_center.*
import kotlinx.android.synthetic.main.view_auction_null.*
import rx.Subscription
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/8
 */
class AuctionCenterFragment : BaseFragment() {
    lateinit var carListAdapter: ProductListAdapter
    private var index = Bean.PAGE_INDEX
    private var isVisibleToUser: Boolean = false
    private var subscription: Subscription? = null
    private var lastLoadingTime: Long = 0

    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_auction_center, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val height = StatusBarCompat.getStatusBarHeight(activity)
            statusBar.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, height)
            statusBar.visibility = View.VISIBLE
        }
        navigationView.hideBack()
        navigationView.setTitle("竞拍中心")
        initRefresh()
    }

    override fun setUserVisibleHint(isVisibleToUser: Boolean) {
        super.setUserVisibleHint(isVisibleToUser)
        this.isVisibleToUser = isVisibleToUser
    }

    private fun initRefresh() {
        val refreshHeader = CarRefreshHeader(context)
        ptrFrame.headerView = refreshHeader
        ptrFrame.setFooterView(DefaultFooter(context))
        ptrFrame.addPtrUIHandler(refreshHeader)
        ptrFrame.disableWhenHorizontalMove(true)
        ptrFrame.setPtrHandler(object : PtrDefaultHandler2() {
            override fun onLoadMoreBegin(frame: PtrFrameLayout) {
                loadMore()
            }

            override fun onRefreshBegin(frame: PtrFrameLayout) {
                refresh()
            }

        })
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.setLoadingMinTime(200)
        ptrFrame.resistanceFooter = 1.0f
        ptrFrame.setDurationToCloseFooter(200) // footer will hide immediately when completed
        ptrFrame.isForceBackWhenComplete = true
        RefreshHelper.autoRefresh(ptrFrame)
        val linearLayoutManager = CustomGridLayoutManager(context,
                LinearLayoutManager.VERTICAL, false)
        recyclerView.layoutManager = linearLayoutManager
        carListAdapter = ProductListAdapter(this)
        recyclerView.adapter = carListAdapter
        auctionNullView.setOnClickListener {
            if (auctionNullView.isSelected) {
                RefreshHelper.autoRefresh(ptrFrame)
            }
        }
    }

    private fun refresh() {
        loadDatas(true)
    }

    private fun loadMore() {
        loadDatas(false)
    }

    private fun loadDatas(refresh: Boolean) {
        LogUtil.d("loadDatas ===== " + refresh)
        lastLoadingTime = System.currentTimeMillis()
        if (refresh) {
            index = Bean.PAGE_INDEX
        }
        val params = filterView.getParams()
        params.page = index
        subscription = Client.getService().getAuctionList(params)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<ListData<SimpleAuctionBean>>>(ptrFrame) {

                    override fun onSuccess(result: Result<ListData<SimpleAuctionBean>>) {
                        if (isVisibleToUser && refresh && result.data != null) {
                            AuctionToast(context, "共${result.data!!.total}辆车").show()
                        }
                        if (result.data!!.data!!.size == 0) {
                            onResultFailed()
                        } else {
                            onResult(refresh, result.data!!.data!!)
                        }

                    }

                    override fun onFailed() {
                        onResultFailed()
                    }
                })
    }

    fun onResult(refresh: Boolean, dataList: List<SimpleAuctionBean>) {
        if (refresh) {
            if (dataList.size == 0) {
                recyclerView.visibility = View.GONE
                auctionNullView.visibility = View.VISIBLE
            } else {
                recyclerView.visibility = View.VISIBLE
                auctionNullView.visibility = View.INVISIBLE
            }
            carListAdapter.refreshDatas(dataList)
        } else {
            carListAdapter.addDatas(dataList)
        }
        if (dataList.size >= Bean.PAGE_SIZE) {
            ptrFrame.mode = PtrFrameLayout.Mode.BOTH
            index++
        } else {
            ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        }
    }

    fun onResultFailed() {
        recyclerView.visibility = View.GONE
        auctionNullView.visibility = View.VISIBLE
        if (!App.instance.isNetWorkConnected()) {
            auctionNullView.isSelected = true
            nullTextView.text = "你的网络通信状态不佳~"
            tipsTV.visibility = View.VISIBLE
            nullImageView.setImageResource(R.mipmap.bg_no_network)
        } else {
            auctionNullView.isSelected = false
            nullTextView.text = "没有找到匹配的竞拍车辆\n请更换筛选条件"
            tipsTV.visibility = View.INVISIBLE
            nullImageView.setImageResource(R.mipmap.bg_auction_null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        subscription?.let {
            subscription!!.unsubscribe()
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_FILTER_CHANGED)))
    fun onFilterChanged(changed: Boolean?) {
        val interval = System.currentTimeMillis() - lastLoadingTime
        LogUtil.d(EventKey.TAG, "onFilterChanged $changed , $interval")
        if (subscription != null) {
            subscription!!.unsubscribe()
        }
        ptrFrame.mode = PtrFrameLayout.Mode.REFRESH
        ptrFrame.refreshComplete()
        if (interval < 3 * 1000) {
            loadDatas(true)
        } else {
            RefreshHelper.autoRefresh(ptrFrame)
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_AUCTION_COUNTDOWN_END)))
    fun onCountDownEnd(bool: Boolean?) {
        LogUtil.d(EventKey.TAG, "onCountDownEnd " + bool!!)
        refresh()
    }

}
