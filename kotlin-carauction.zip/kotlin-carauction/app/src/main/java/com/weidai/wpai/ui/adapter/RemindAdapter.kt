package com.weidai.wpai.ui.adapter

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.weidai.wpai.R
import com.weidai.wpai.common.ImageLoader
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.AuctionBean
import com.weidai.wpai.http.bean.SimpleAuctionBean
import com.weidai.wpai.ui.activity.AuctionActivity
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.DensityUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.view_my_remind_auction_item.view.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*


class RemindAdapter(val context: Context) : RecyclerView.Adapter<RemindAdapter.ViewHolder>() {
    private val dataList = ArrayList<SimpleAuctionBean>()

    fun refreshDatas(datas: List<SimpleAuctionBean>?) {
        dataList.clear()
        if (datas != null && datas.size > 0) {
            dataList.addAll(datas)
        }
        Handler().postDelayed({ notifyDataSetChanged() }, 200)
    }

    fun addDatas(datas: List<SimpleAuctionBean>) {
        if (datas.size > 0) {
            dataList.addAll(datas)
            notifyItemRangeInserted(dataList.size - datas.size, datas.size)
        }
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.view_my_remind_auction_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindData(dataList[position])
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var auctionNo: String? = null

        fun bindData(data: SimpleAuctionBean) {
            itemView.currentPriceTV.setCharacterList(FormatUtil.getMoneyChars())
            itemView.currentPriceTV.animationDuration = 800
            itemView.dateTV.text = DateUtil.format(DateUtil.parse(data.startTime), 6)
            ImageLoader.instance.displayResize(data.picPath, itemView.carIV,
                    DensityUtil.dip2px(120f), DensityUtil.dip2px(90f))
            itemView.titleTV.text = data.title
            var carInfo = ""
            if (data.regionName != null) {
                for (i in 0..data.regionName!!.size - 1) {
                    carInfo += data.regionName!![i]
                }
            }
            val formatYear = DateUtil.getYear(data.registerTime)
            if (!TextUtils.isEmpty(formatYear)) {
                carInfo = "$carInfo/${formatYear}上牌"
            }
            carInfo = "$carInfo/${FormatUtil.getWan00(data.mileage)}公里"
            itemView.descriptionTV.text = carInfo
            itemView.minPriceTV.text = FormatUtil.getWan00(data.startPrice)
            itemView.currentPriceTV.setText("")
            auctionNo = data.auctionNo
            if (data.auctionMode == AuctionBean.AUCTION_MODE_NORMAL) {
                itemView.hideFlagIV.visibility = View.INVISIBLE
            } else {
                itemView.hideFlagIV.visibility = View.VISIBLE
            }
            itemView.toDetailTV.setOnClickListener {
                AuctionActivity.gotoThis(context, data.auctionNo!!)
            }

            when (data.remindStatus) {
                0 -> {
                    itemView.statusTitleTV.setTextColor(Color.parseColor("#EB9604"))
                    itemView.statusTitleTV.text = "即将开始"
                    itemView.remindTV.visibility = View.VISIBLE
                    itemView.remindTV.setOnClickListener { remindCancel(data) }
                }
                1 -> {
                    itemView.statusTitleTV.setTextColor(Color.parseColor("#FD3D14"))
                    itemView.statusTitleTV.text = "竞拍中"
                    val price = if (data.curPrice > data.startPrice) data.curPrice else data.startPrice
                    if (data.auctionMode === AuctionBean.AUCTION_MODE_NORMAL) {
                        itemView.currentPriceTV.setText("（当前价" + FormatUtil.getWan00(price) + "）")
                    } else {
                        itemView.currentPriceTV.setText("")
                    }
                    itemView.remindTV.visibility = View.GONE
                }
            }
        }

    }

    fun remindCancel(data: SimpleAuctionBean) {
        var dialog = ProgressDialog(context)
        dialog.show()
        var subscribe = object : SimpleSubscriber<Result<*>>(dialog) {
            override fun onSuccess(result: Result<*>) {
                ToastUtil.show("您已取消开拍提醒")
                dataList.remove(data)
                notifyDataSetChanged()
            }
        }
        Client.getService().remindCancel(data.auctionNo)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscribe)
    }
}
