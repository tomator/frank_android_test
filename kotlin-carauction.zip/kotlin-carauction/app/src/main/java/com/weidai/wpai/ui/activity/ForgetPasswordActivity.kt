package com.weidai.wpai.ui.activity

import android.os.Bundle
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.param.PwdResetVQO
import com.weidai.wpai.http.param.SendMsgVQO
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.view.AuthcodeView
import com.weidai.wpai.util.ToastUtil
import com.weidai.wpai.util.ValidityUtils
import com.weidai.wpai.util.secret.PasswordUtil
import kotlinx.android.synthetic.main.activity_forget_password.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

class ForgetPasswordActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)
        navigationView.setTitle("忘记密码")
        authcodeView.setType(SendMsgVQO.TYPE_FORGET_LOGIN_PWD)
        authcodeView.setMode(AuthcodeView.MODE_IMAGE)
        phoneAET.setOnTextChange { input ->
            authcodeView.setPhoneNumber(input.toString())
            checkCommitEnable()
        }
        authcodeView.getAuthcodeAET().setOnTextChange { checkCommitEnable() }
        passwordAET.setOnTextChange { checkCommitEnable() }
        confirmBtn.setOnClickListener {
            if (confirmBtn.isSelected) {
                resetPassword()
            }
        }
    }

    private fun checkCommitEnable() {
        val phone = phoneAET.text.toString()
        val authcode = authcodeView.text.toString()
        val password = passwordAET.text.toString()
        confirmBtn.isSelected = ValidityUtils.checkPhone(phone)
                && ValidityUtils.checkAuthcode(authcode)
                && ValidityUtils.checkPassword(password)
    }

    private fun resetPassword() {
        val phone = phoneAET.text.toString()
        val authcode = authcodeView.text.toString()
        var password = passwordAET.text.toString()
        password = PasswordUtil.encode(password)
        val progressDialog = ProgressDialog(this)
        progressDialog.show()
        Client.getService().fastReset(PwdResetVQO(password, phone, authcode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<Boolean>>(progressDialog) {
                    override fun onSuccess(result: Result<Boolean>) {
                        super.onSuccess(result)
                        RxBus.get().post(EventKey.KEY_USER_PWD_RESET_SUCCESS, true)
                        ToastUtil.show("密码设置成功")
                        finish()
                    }
                })
    }
}
