package com.weidai.wpai.ui.evaluate.activity

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import com.bigkoo.pickerview.OptionsPickerView
import com.hwangjr.rxbus.RxBus
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.App
import com.weidai.wpai.R
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.component.cityPick.db.City
import com.weidai.wpai.db.DBManager
import com.weidai.wpai.db.EvaluateParam
import com.weidai.wpai.extensions.trimAll
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.CarInfoBean
import com.weidai.wpai.http.bean.EvaluateCar
import com.weidai.wpai.http.bean.EvaluateResult
import com.weidai.wpai.http.bean.VinResultBean
import com.weidai.wpai.http.param.SearchCodeVQO
import com.weidai.wpai.ui.activity.BaseActivity
import com.weidai.wpai.ui.dialog.ProgressDialog
import com.weidai.wpai.ui.evaluate.dialog.CarChooseDialog
import com.weidai.wpai.util.DateUtil
import com.weidai.wpai.util.FormatUtil
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ToastUtil
import kotlinx.android.synthetic.main.activity_evaluate.*
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import java.util.*
import kotlin.collections.ArrayList

class EvaluateActivity : BaseActivity() {

    var chooseCar: EvaluateCar? = null
    var chooseCity: City? = null
    var chooseDate: String? = null
    var chooseMileage: Double = -1.0
    var flagType = EvaluateCar.FLAG_MODEL
    var vinCode: String? = null
    var vinCodeSearching = false
    var carInfo: CarInfoBean? = null
    var enableVinCode: String? = null
    lateinit var dbManager: DBManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_evaluate)
        navigationView.setThemeColor(R.color.main_blue)
        navigationView.setTitle("车辆估价")
        var carInfo = intent.getSerializableExtra("CarInfoBean")
        if (carInfo == null) {
            chooseType(flagType)
        } else {
            this.carInfo = carInfo as CarInfoBean
            flagType = EvaluateCar.FLAG_VIN
            chooseType(flagType)
            initByCarInfo(carInfo)
        }
        typeModelTV.setOnClickListener { chooseType(EvaluateCar.FLAG_MODEL) }
        typeVinTV.setOnClickListener { chooseType(EvaluateCar.FLAG_VIN) }
        modelLL.setOnClickListener {
            App.instance.hideSoftInput(mileageET.windowToken)
            if (typeModelTV.isSelected) {
                startActivity(Intent(this, CarBrandActivity::class.java))
            }
        }
        registerLL.setOnClickListener {
            App.instance.hideSoftInput(mileageET.windowToken)
            onDatePicker()
        }
        cityLL.setOnClickListener {
            App.instance.hideSoftInput(mileageET.windowToken)
            startActivity(Intent(this, CityPickerActivity::class.java))
        }
        mileageET.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                if (TextUtils.isEmpty(s)) {
                    chooseMileage = 0.0
                } else {
                    chooseMileage = s.toString().toDouble()
                }
                checkoutEnable()
            }
        })
        submitTV.setOnClickListener {
            if (submitTV.isSelected) {
                requestEvluate()
            }
        }
        vinCodeAET.setOnTextChange { input ->
            modelLL.visibility = View.GONE
            clearCar()
            infoTV.isSelected = false
            infoTV.visibility = View.VISIBLE
            infoTV.isSelected = false
            infoTV.text = "已输入${input.length}/17位"
            var upperCase = input.toString().toUpperCase()
            if (!upperCase.equals(input.toString())) {
                vinCodeAET.text = upperCase
                vinCodeAET.edit.setSelection(upperCase.length)
            }
            if (input.length == 17) {
                checkVinCode(vinCodeAET.text.toString())
            }
        }
        vinCodeAET.edit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        vinCodeAET.edit.setOnKeyListener { v, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER) {
                App.instance.hideSoftInput(vinCodeAET.edit.windowToken)
                checkVinCode(vinCodeAET.text.toString())
            }
            false
        }
        navigationView.setNextText("估价记录", View.OnClickListener {
            startActivity(Intent(this@EvaluateActivity, EvaluateHistoryActivity::class.java))
        })

    }


    fun chooseType(type: Int) {
        flagType = type
        typeModelTV.isSelected = false
        typeVinTV.isSelected = false
        clearCar()
        vinCodeAET.text = ""
        if (type == EvaluateCar.FLAG_MODEL) {
            typeModelTV.isSelected = true
            modelIV.visibility = View.VISIBLE
            modelLL.visibility = View.VISIBLE
            vinCodeAET.visibility = View.GONE
            infoTV.visibility = View.GONE
        } else {
            typeVinTV.isSelected = true
            modelIV.visibility = View.GONE
            modelLL.visibility = View.GONE
            vinCodeAET.visibility = View.VISIBLE
            infoTV.visibility = View.VISIBLE
        }
        dbManager = DBManager(this)
    }

    fun initByCarInfo(carInfo: CarInfoBean) {
        vinCodeAET.text = carInfo.vin
        checkVinCode(carInfo.vin)
        if (carInfo.shortRegionName != null && carInfo.shortRegionName.size >= 2) {
            chooseCity = City()
            chooseCity!!.parentName = carInfo.shortRegionName[0]
            chooseCity!!.name = carInfo.shortRegionName[1]
            cityTV.text = "${chooseCity!!.name}"
        }
        if (!TextUtils.isEmpty(carInfo.registerTime)) {
            var dateLong = DateUtil.parse(carInfo.registerTime, 1)
            chooseDate = DateUtil.format(dateLong, 19)
            registerTV.text = DateUtil.format(dateLong, 20)
        }
        chooseMileage = carInfo.mileage / 10000
        mileageET.setText(FormatUtil.getDouble2(chooseMileage))
    }

    fun clearCar() {
        chooseCar = null
        modelTV.text = ""
        vinCode = null
        checkoutEnable()
        clearRegisterYear()
        chooseMileage = -1.0
        mileageET.setText("")
    }

    fun clearRegisterYear() {
        option1 = 0
        option2 = 0
        chooseDate = null
        registerTV.text = ""
        checkoutEnable()
    }

    fun checkoutEnable() {
        submitTV.isSelected = chooseMileage > 0
                && chooseCar != null
                && chooseCity != null
                && chooseDate != null
    }

    fun requestEvluate() {
        chooseCar!!.carCity = chooseCity!!.name
        chooseCar!!.provinceName = chooseCity!!.parentName
        chooseCar!!.mileage = chooseMileage.toString()
        chooseCar!!.ppDate = chooseDate
        chooseCar!!.flag = flagType
        var progressDialog = ProgressDialog(this)
        progressDialog.show()
        Client.getService().carEvaluate(chooseCar)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<EvaluateResult>>(progressDialog) {
                    override fun onSuccess(result: Result<EvaluateResult>) {
                        if (result.data != null) {
                            startActivity(Intent(this@EvaluateActivity, EvaluateResultActivity::class.java)
                                    .putExtra("evaluateResult", result.data)
                                    .putExtra("carInfo", chooseCar)
                                    .putExtra("vinCode", vinCode)
                                    .putExtra("enableVinCode", enableVinCode))
                            dbManager.saveEvaluateParam(EvaluateParam.create(vinCode,
                                    result.data!!, chooseCar!!, enableVinCode))
                        }
                    }
                })
    }

    var option1 = 0
    var option2 = 0
    fun onDatePicker() {
        if (chooseCar == null) {
            ToastUtil.show("请先选择车型")
            return
        } else {
            var years = ArrayList<String>()
            var monthss = ArrayList<List<String>>()
            var yearNow = Calendar.getInstance().get(Calendar.YEAR)
            var monthNow = Calendar.getInstance().get(Calendar.MONTH) + 1
            var startMin = chooseCar!!.minRegYear!!.toInt()
            var startMax = chooseCar!!.maxRegYear!!.toInt()
            for (year in startMin..startMax) {
                years.add("${year}年")
                var max = if (year == yearNow) monthNow else 12
                val months = (1..max).map { "${it}月" }
                monthss.add(months)
            }
            var pickerBuilder = OptionsPickerView.Builder(this, OptionsPickerView.OnOptionsSelectListener { options1, options2, options3, v ->
                registerTV.text = "${years[options1]}${monthss[options1][options2]}"
                option1 = options1
                option2 = options2
                chooseDate = "${years[options1]}-${monthss[options1][options2]}".replace("年", "").replace("月", "")
                checkoutEnable()
            })
            var picker = pickerBuilder.build()
            picker.setPicker(years, monthss)
            picker.show()
            picker.setSelectOptions(option1, option2)
        }
    }

    private fun checkVinCode(vinCode: String) {
        if (vinCodeSearching) {
            return
        }
        vinCodeSearching = true
        infoTV.visibility = View.VISIBLE
        infoTV.text = "正在查询中…"
        Client.getService().carGetByVin(vinCode)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<List<EvaluateCar>>>() {
                    override fun onSuccess(result: Result<List<EvaluateCar>>) {
                        vinCodeSearching = false
                        if (result.data == null || result.data!!.size == 0) {
                            infoTV.isSelected = true
                            infoTV.text = "您输入的VIN码不正确"
                        } else {
                            this@EvaluateActivity.vinCode = vinCode
                            vinCodeCanMaintance(vinCode)
                            showChooseDialog(result.data!!)
                            infoTV.visibility = View.GONE
                        }
                    }

                    override fun onFailed() {
                        vinCodeSearching = false
                        infoTV.isSelected = true
                        infoTV.text = "查询失败"
                    }
                })
    }

    fun vinCodeCanMaintance(vinCode: String) {
        Client.getService().checkvin(SearchCodeVQO(vinCode))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : SimpleSubscriber<Result<VinResultBean>>() {
                    override fun onSuccess(result: Result<VinResultBean>) {
                        if (result.data != null) {
                            enableVinCode = vinCode
                        }
                    }

                    override fun onFailed(result: Result<*>) {}
                })
    }

    var chooseDialog: CarChooseDialog? = null
    fun showChooseDialog(dataList: List<EvaluateCar>) {
        if (chooseDialog != null && chooseDialog!!.isShowing) {
            chooseDialog!!.cancel()
        }
        if (dataList.size == 1) {
            RxBus.get().post(EventKey.KEY_CHOOSE_CAR_EVALUATE, dataList[0])
        } else {
            carInfo?.let {
                dataList.forEach {
                    var style = carInfo!!.style
                    var modelDetail = it.modelDetail
                    if (!TextUtils.isEmpty(style) && !TextUtils.isEmpty(modelDetail)) {
                        style = style.trimAll().toUpperCase()
                        modelDetail = modelDetail.trimAll().toUpperCase()
                        if (modelDetail.contains(style)) {
                            RxBus.get().post(EventKey.KEY_CHOOSE_CAR_EVALUATE, it)
                            return
                        }
                    }
                }
            }
            chooseDialog = CarChooseDialog(this, dataList)
            if (this != null && !isFinishing) {
                chooseDialog!!.show()
            }
        }
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CITY)))
    fun onCityChoose(city: City) {
        LogUtil.d(EventKey.TAG, "onCityChoose " + city)
        when (city.type) {
            City.TYPE_CITY, City.TYPE_HOT, City.TYPE_LOCATION -> {
                chooseCity = city
                cityTV.text = "${city.name}"
            }
        }
        checkoutEnable()
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_CHOOSE_CAR_EVALUATE)))
    fun onCarChoose(evaluateCar: EvaluateCar) {
        LogUtil.d(EventKey.TAG, "onCarChoose " + evaluateCar)
        chooseCar = evaluateCar
        modelLL.visibility = View.VISIBLE
        modelTV.text = "${evaluateCar.modelName} ${evaluateCar.modelDetail}"
        checkoutEnable()
        if (carInfo == null) {
            clearRegisterYear()
        }
    }
}
