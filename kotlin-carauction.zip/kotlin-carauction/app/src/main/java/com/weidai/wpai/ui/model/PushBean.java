package com.weidai.wpai.ui.model;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/3
 */
public class PushBean {

    private String title;
    private String content;
    private String action;
    private String url;
    private String target;
    private int type;  // 1 系统 2 提醒
    private boolean alert;

    public static final int TYPE_NOTIFICATION = 1;
    public static final int TYPE_INNER = 2;

    @Override
    public String toString() {
        return "title = " + title + ", content = " + content + ", type = " + type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public boolean isAlert() {
        return alert;
    }

    public void setAlert(boolean alert) {
        this.alert = alert;
    }
}
