package com.weidai.wpai.http.bean

import java.io.Serializable

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/8/15
 */

/**
 * status：一般/良好/优秀
gpjEvalPrice：公平价
car300EvalPrice：车300
normalEvalPrice：车况一般对应估价
goodEvalPrice：车况良好对应估价
excEvalPrice：车况优秀对应估价
carPriceNext：未来四年估价趋势
carPriceNext1
carPriceNext2
carPriceNext3
carPriceNext4
vicinalProvincesPrice： 附近省份价格
省份名称：价格
transactionRecords：交易记录
 */
data class EvaluateResult(var status: String,
                          var normalEvalPrice: String,
                          var goodEvalPrice: String,
                          var excEvalPrice: String,
                          var gpjEvalPrice: String,
                          var car300EvalPrice: String,
                          var carPriceNext: CarPriceNext,
                          var vicinalProvincesPrice: LinkedHashMap<String, String>,
                          var transactionRecords: List<TransactionRecords>) : Serializable

data class TransactionRecords(var typeName: String,
                              var id: String,
                              var tranDate: String,
                              var mileage: String,
                              var detailModelSlug: String,
                              var provName: String,
                              var cityName: String,
                              var ppDate: String,
                              var tranType: String,
                              var tranCharge: String) : Serializable

data class CarPriceNext(var carPriceNext1: String,
                        var carPriceNext2: String,
                        var carPriceNext3: String,
                        var carPriceNext4: String) : Serializable