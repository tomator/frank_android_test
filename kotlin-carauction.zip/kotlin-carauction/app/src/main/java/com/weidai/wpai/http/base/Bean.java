package com.weidai.wpai.http.base;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/8
 */
public interface Bean {

    public static final int PAGE_SIZE = 10;
    public static final int PAGE_INDEX = 1;

    /**
     * 状态 1竞拍中、2即将开始、3结束'
     */
//    public static final int PRODUCT_STATUS_AUCTIONING = 1;
//    public static final int PRODUCT_STATUS_ABOUT_TO_AUCTION = 2;
//    public static final int PRODUCT_STATUS_OVER = 3;


}
