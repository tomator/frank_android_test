package com.weidai.wpai.ui.activity

import android.content.Intent
import android.os.Bundle
import com.hwangjr.rxbus.annotation.Subscribe
import com.hwangjr.rxbus.annotation.Tag
import com.weidai.wpai.R
import com.weidai.wpai.common.StaticPage
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.param.BankCardVQO
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.ValidityUtils
import kotlinx.android.synthetic.main.activity_bind_card.*

class BindCardActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bind_card)
        navigationView.setTitle("绑定银行卡")
        realNameAET.setOnTextChange { checkCommitEnable() }
        idCardAET.setOnTextChange { checkCommitEnable() }
        cardAET.setOnTextChange { checkCommitEnable() }
        phoneAET.setOnTextChange { checkCommitEnable() }
        nextStepTV.setOnClickListener {
            if (nextStepTV.isSelected) {
                nextStep()
            }
        }
        protocolBtn.setOnClickListener { WPWebActivty.openStaticPage(this, StaticPage.deal_register) }
        cardInfoIV.setOnClickListener { WPWebActivty.openStaticPage(this, StaticPage.deal_bank) }
    }

    private fun checkCommitEnable() {
        val realname = realNameAET.text.toString()
        val idCard = idCardAET.text.toString()
        val bankCard = cardAET.text.toString()
        val phone = phoneAET.text.toString()
        nextStepTV.isSelected = ValidityUtils.checkPhone(phone)
                && ValidityUtils.checkRealname(realname)
                && ValidityUtils.checkBankCard(bankCard)
                && ValidityUtils.checkIdCard(idCard)
    }

    private fun nextStep() {
        val realname = realNameAET.text.toString()
        val idCard = idCardAET.text.toString()
        val bankCard = cardAET.text.toString()
        val phone = phoneAET.text.toString()
        val bankCardVQO = BankCardVQO()
        bankCardVQO.bankAccountName = realname
        bankCardVQO.bankAccountNo = bankCard
        bankCardVQO.idNo = idCard
        bankCardVQO.mobile = phone
        startActivity(Intent(this, PhoneAuthActivity::class.java)
                .putExtra("BankCardVQO", bankCardVQO))
    }

    @Subscribe(tags = arrayOf(Tag(EventKey.KEY_USER_BIND_CARD_SUCCESS)))
    fun onBindCard(success: Boolean?) {
        LogUtil.d(EventKey.TAG, "onBindCard " + success)
        finish()
    }
}
