package com.weidai.wpai.http;

/**
 * Author  : Jiang Zhongyuan
 * Date    : 17/6/12
 */
public class Remote {

}
