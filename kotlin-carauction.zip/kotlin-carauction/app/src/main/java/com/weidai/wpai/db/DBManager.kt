package com.weidai.wpai.db

import android.content.ContentValues
import android.content.Context

class DBManager(val context: Context) {
    internal var dbOpenHelper: DBOpenHelper = DBOpenHelper(context)

    fun getEvaluateParams(limit: Int = 5): List<EvaluateParam> {
        val db = dbOpenHelper.readableDatabase
        val sql = "select * from ${EvaluateParam.TABLE_NAME} order by rowid desc limit $limit"
        val cursor = db.rawQuery(sql, null)
        val result = ArrayList<EvaluateParam>()
        while (cursor.moveToNext()) {
            val vinCode = cursor.getString(cursor.getColumnIndex(EvaluateParam.VIN_CODE))
            val evaluateResult = cursor.getString(cursor.getColumnIndex(EvaluateParam.EVALUATE_RESULT))
            val carInfo = cursor.getString(cursor.getColumnIndex(EvaluateParam.CAR_INFO))
            val enableVinCode = cursor.getString(cursor.getColumnIndex(EvaluateParam.ENABLE_VIN_CODE))
            val param = EvaluateParam(vinCode, evaluateResult, carInfo, enableVinCode)
            result.add(param)
        }
        cursor.close()
        db.close()
        return result
    }

    fun saveEvaluateParam(evaluateParam: EvaluateParam): Boolean {
        val db = dbOpenHelper.writableDatabase
        try {
            var deleteSql = "delete from ${EvaluateParam.TABLE_NAME} where ${EvaluateParam.VIN_CODE} = '${evaluateParam.vinCode}'"
            db.execSQL(deleteSql)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            val values = ContentValues()
            values.put(EvaluateParam.VIN_CODE, evaluateParam.vinCode)
            values.put(EvaluateParam.EVALUATE_RESULT, evaluateParam.evaluateResult)
            values.put(EvaluateParam.CAR_INFO, evaluateParam.carInfo)
            values.put(EvaluateParam.ENABLE_VIN_CODE, evaluateParam.enableVinCode)
            db.insert(EvaluateParam.TABLE_NAME, null, values)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        } finally {
            db.close()
        }
    }
}
