package com.weidai.wpai.component

import android.content.Context
import android.content.Intent
import android.text.TextUtils
import com.hwangjr.rxbus.RxBus
import com.weidai.wpai.App
import com.weidai.wpai.common.EventKey
import com.weidai.wpai.http.Client
import com.weidai.wpai.http.SimpleSubscriber
import com.weidai.wpai.http.base.Result
import com.weidai.wpai.http.bean.BalanceBean
import com.weidai.wpai.http.bean.BankCardBean
import com.weidai.wpai.http.bean.UserInfoBean
import com.weidai.wpai.ui.activity.BindCardActivity
import com.weidai.wpai.ui.activity.LoginActivity
import com.weidai.wpai.ui.activity.PayPwdSetActivity
import com.weidai.wpai.ui.activity.RechargeActivity
import com.weidai.wpai.ui.model.User
import com.weidai.wpai.util.LogUtil
import com.weidai.wpai.util.preferences.SpfUtils
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers

/**
 * Created by bici on 16/4/25.
 */
class UserManager private constructor() {

    private object Holder {
        val INSTANCE = UserManager()
    }

    companion object {
        val instance: UserManager by lazy { Holder.INSTANCE }
    }

    var user = SpfUtils.getInstance().user
    val userMobile: String?
        get() = user.mobileNo
    val isUserLogin: Boolean
        get() {
//            val token = SpfUtils.getInstance().getString(SpfKey.COOKIE_WPAI_TOKEN, null)
//            val code = SpfUtils.getInstance().getString(SpfKey.COOKIE_WPAI_CODE, null)
            if (
//            TextUtils.isEmpty(token)
//                    || TextUtils.isEmpty(code)
//                    ||
                    TextUtils.isEmpty(user.mobileNo)) {
                return false
            }
            return true
        }

    init {
        refresh()
    }

    fun refresh() {
        user = SpfUtils.getInstance().user
    }

    fun saveUserInfo(userInfo: UserInfoBean?) {
        if (userInfo != null) {
            SpfUtils.getInstance().saveUserInfo(userInfo!!)
            refresh()
        }
    }

    fun turn2Login() {
        turn2LoginActivity()
        cleanUserInfo()
    }

    fun cleanUserInfo() {
        SpfUtils.getInstance().clearUserInfo()
        refresh()
        RxBus.get().post(EventKey.KEY_USER_CLEAR_INFO, true)
    }

    fun turn2LoginActivity() {
        val currentActivity = App.instance.currentActivity
        if (currentActivity != null && currentActivity !is LoginActivity) {
            currentActivity.startActivity(Intent(currentActivity, LoginActivity::class.java))
        }
    }

    fun toBindCard(context: Context) {
        context.startActivity(Intent(context, BindCardActivity::class.java))
    }

    fun toRecharge(context: Context) {
        context.startActivity(Intent(context, RechargeActivity::class.java))
    }

    fun toSetPayPwd(context: Context) {
        if (!hasPayPwd()) {
            context.startActivity(Intent(context, PayPwdSetActivity::class.java))
        }
    }

    fun hasPayPwd(): Boolean {
        return user.hasPayPwd()
    }

    fun hasBindCard(): Boolean {
        return !TextUtils.isEmpty(user.bindCardNo)
    }

    fun setPayPwd(hasPayPwd: Boolean) {
        if (hasPayPwd) {
            user.hasPayPwd = User.PAY_PWD_SETTED
        } else {
            user.hasPayPwd = "0"
        }
        user.save()
    }

    fun saveBindCrad(cardNo: String?) {
        user.bindCardNo = cardNo
        user.save()
    }

    fun reqeustBindCardInfo(showLogin: Boolean = false, subscriber: Subscriber<Result<BankCardBean>> = object : SimpleSubscriber<Result<BankCardBean>>(showLogin) {
        override fun onSuccess(result: Result<BankCardBean>) {
            super.onSuccess(result)
            saveBindCrad(result.data!!.bankAccountNo)
            RxBus.get().post(EventKey.KEY_USER_GET_CARD_INFO, result.data!!)
            LogUtil.d(EventKey.TAG, "post KEY_USER_GET_CARD_INFO " + result.data!!)
        }

        override fun onFailed(result: Result<*>) {

        }
    }) {
        Client.getService().bindCard
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber)
    }

    fun reqeustUserBalance(subscriber: Subscriber<Result<BalanceBean>> = object : SimpleSubscriber<Result<BalanceBean>>() {
        override fun onSuccess(result: Result<BalanceBean>) {
            super.onSuccess(result)
            RxBus.get().post(EventKey.KEY_USER_GET_BALANCE, result.data!!)
            LogUtil.d(EventKey.TAG, "post KEY_USER_GET_BALANCE " + result.data!!)
        }
    }) {
        Client.getService().balance
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber)
    }


}
