package com.weidai.wpai.ui.dialog;

import android.content.Context;

/**
 * Created by bici on 16/5/5.
 */
public class ProgressDialog {
    private android.app.ProgressDialog progressDialog;

    public ProgressDialog(Context context) {
        this(context, "数据加载中...");
    }

    public ProgressDialog(Context context, String message) {
        progressDialog = new android.app.ProgressDialog(context);
        progressDialog.setProgressStyle(android.app.ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(message);
        progressDialog.setIndeterminate(false);
        progressDialog.setCancelable(true);
        progressDialog.setCanceledOnTouchOutside(false);
    }

    public void setMessage(String message) {
        progressDialog.setMessage(message);
    }

    public void setCancelable(boolean cancelable) {
        progressDialog.setCancelable(cancelable);
    }

    public void setCanceledOnTouchOutside(boolean canceledOnTouchOutside) {
        progressDialog.setCanceledOnTouchOutside(canceledOnTouchOutside);
    }

    public ProgressDialog show() {
        if (progressDialog.getContext() != null
                && !progressDialog.isShowing()) {
            progressDialog.show();
        }
        return this;
    }

    public void dismiss() {
        if (progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }
}
