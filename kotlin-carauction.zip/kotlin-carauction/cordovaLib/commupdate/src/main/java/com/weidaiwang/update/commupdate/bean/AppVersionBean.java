package com.weidaiwang.update.commupdate.bean;

/**
 * Describe:
 * User: 月月鸟
 * Date: 2017-05-17
 */
public class AppVersionBean {
    private String m;
    private int r;
    private ApkInfo d;
    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public ApkInfo getD() {
        return d;
    }

    public void setD(ApkInfo d) {
        this.d = d;
    }

    public class ApkInfo {
        private String downloadUrl;//渠道下载地址

        private int maxVersion;//最大版本

        private int minVersion;//最小版本

        private String versionInfo;//最新版本说明



        public String getDownloadUrl() {
            return downloadUrl;
        }

        public void setDownloadUrl(String downloadUrl) {
            this.downloadUrl = downloadUrl;
        }

        public int getMaxVersion() {
            return maxVersion;
        }

        public void setMaxVersion(int maxVersion) {
            this.maxVersion = maxVersion;
        }

        public int getMinVersion() {
            return minVersion;
        }

        public void setMinVersion(int minVersion) {
            this.minVersion = minVersion;
        }

        public String getVersionInfo() {
            return versionInfo;
        }

        public void setVersionInfo(String versionInfo) {
            this.versionInfo = versionInfo;
        }

        public int isForceUpdate(int versionCode) {
            if(versionCode>=minVersion && versionCode<maxVersion){
                return 1;//选择更新
            }else if (versionCode<minVersion){
                return 2;//强制更新
            }else{
                return 3;//不更新
            }
        }
    }

}
