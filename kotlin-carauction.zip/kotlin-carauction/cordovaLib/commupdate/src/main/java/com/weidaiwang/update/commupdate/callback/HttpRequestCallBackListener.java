package com.weidaiwang.update.commupdate.callback;

/**
 * Describe:
 * User: 月月鸟
 * Date: 2017-05-17
 */
public interface HttpRequestCallBackListener {
    public void success();
}
