package com.weidaiwang.update.commupdate.bean;

/**
 * Describe:
 * User: 月月鸟
 * Date: 2017-05-25
 */
public class HtmlVersionBean {

    /**
     * d : {"updateTime":"2017-05-25 13:13:58","versionCode":"10","versionName":"2.0.0"}
     * r : 1
     */

    private DBean d;
    private String r;

    public DBean getD() {
        return d;
    }

    public void setD(DBean d) {
        this.d = d;
    }

    public String getR() {
        return r;
    }

    public void setR(String r) {
        this.r = r;
    }

    public static class DBean {
        /**
         * updateTime : 2017-05-25 13:13:58
         * versionCode : 10
         * versionName : 2.0.0
         */

        private String updateTime;
        private int versionCode;
        private String versionName;

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public int getVersionCode() {
            return versionCode;
        }

        public void setVersionCode(int versionCode) {
            this.versionCode = versionCode;
        }

        public String getVersionName() {
            return versionName;
        }

        public void setVersionName(String versionName) {
            this.versionName = versionName;
        }
    }
}
