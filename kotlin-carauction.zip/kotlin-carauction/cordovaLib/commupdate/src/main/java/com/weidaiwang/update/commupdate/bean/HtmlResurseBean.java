package com.weidaiwang.update.commupdate.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Describe:
 * User: 月月鸟
 * Date: 2017-05-17
 */
public class HtmlResurseBean {
    private ArrayList<ResurseBean> dl = new ArrayList<>();

    public ArrayList<ResurseBean> getDl() {
        return dl;
    }

    public void setDl(ArrayList<ResurseBean> dl) {
        this.dl = dl;
    }

    public class ResurseBean{
        private String md5;
        private String path;

        public String getMd5() {
            return md5;
        }

        public void setMd5(String md5) {
            this.md5 = md5;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }
    }
}
